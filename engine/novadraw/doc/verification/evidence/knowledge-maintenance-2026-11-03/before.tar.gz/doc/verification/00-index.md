# 验证与审计

类型：`documentation-index`

本目录保存人读的验证方法和历史结论，不定义架构或里程碑状态。

| 目录 | 内容 | 入口 |
|---|---|---|
| `reference/` | 外部参考源码基线与纠错依据 | [索引](reference/00-index.md) |
| `reviews/` | 阶段审计和实现验证报告 | [索引](reviews/00-index.md) |
| `manual/` | 窗口、交互和视觉验收步骤 | [索引](manual/00-index.md) |
| `plans/` | 设计矩阵、实施门禁及已完成切片的回归矩阵 | [索引](plans/00-index.md) |
| `performance/` | 测量方法与指定环境的历史基线 | [索引](performance/00-index.md) |
| `checklists/` | 开发与验证检查清单 | [审计整改执行总清单](checklists/audit-remediation-execution.md)、[渲染管线](checklists/rendering-pipeline.md) |

## 工作流

- [审计—收口持续闭环工作流](audit-remediation-workflow.md)：定义 Discover → Triage →
  Backlog → Design → Execute → Verify → Close 单链条，以及"审计中又产生审计"
  的挂起规则。

## 自动化入口

跨工具 suite 与直接 Cargo 门禁见
[`../../verification/README.md`](../../tests/README.md)。

```bash
cargo xtask list
cargo xtask docs
cargo xtask verify <suite-id>
```

单个测试直接使用 Cargo；平台和人工验收使用对应手册中的直接命令。Review 只引用稳定
suite ID 或精确 test target 和执行结果，不复制冗余别名。

## 证据边界

- `reviews/` 保存可阅读的结论，不冒充当前设计 SSOT。
- `manual/` 只补充窗口、GPU、浏览器和输入设备体验。
- `target/verification/` 保存可重建的本地运行产物，不提交 Git。
- [`../../verification/evidence/`](evidence/README.md) 保存需要随审计
  提交的日志、JSON、探针源码和分组报告。
- 编译后的探针和其他二进制生成物不得进入 `doc/` 或 `doc/verification/evidence/`。

发现不一致时，先回到 `design/`、ADR 或 parity ledger 确定合理契约，再调整实现和
验证；历史报告不覆盖后续设计修订。
