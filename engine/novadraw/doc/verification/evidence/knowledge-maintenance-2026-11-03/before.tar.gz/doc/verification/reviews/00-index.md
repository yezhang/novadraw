# Review Index

类型：`documentation-index`

本目录保存已完成审计和阶段验证的结论。报告是对应快照的历史证据，不覆盖当前
`design/`、ADR、parity ledger 或 roadmap。

## 文档表达与写作

| 日期 | 报告 |
|---|---|
| 2026-11-02 | [E04-A 开放吸附协议首段验证（实施中）](p2-e04-a-implementation-2026-11-02.md) |
| 2026-11-02 | [ADR-058 修订 2 设计复核通过（建议接受，未授权实施）](adr-058-revision-2-review-2026-11-02.md) |
| 2026-11-02 | [ADR-058 修订 2：七项评审回应与文档自审（待复核）](adr-058-revision-2-response-2026-11-02.md) |
| 2026-11-02 | [ADR-058 修订 1 评审意见（待回应与复核）](adr-058-revision-1-review-2026-11-02.md) |
| 2026-11-02 | [E04 开放吸附依赖核验与修订 1（待评审）](adr-058-dependency-and-design-review-2026-11-02.md) |
| 2026-10-30 | [Logic 预设、相对折点与路由切换](gef-logic-routing-2026-10-30.md) |
| 2026-10-30 | [Zoom 类图图标对齐修正](zoom-icon-alignment-2026-10-30.md) |
| 2026-10-29 | [方案与评审文档表达审查及中文写作技能建议](document-writing-audit-2026-10-29.md) |

## 应用与宿主验证

| 日期 | 报告 |
|---|---|
| 2026-11-03 | [有限富文本技术提案在 Novadraw 中的适用性分析](bounded-rich-text-proposal-assessment-2026-11-03.md) |
| 2026-11-03 | [TextFlowLarge 独立研究应用：实施与验证](textflow-large-app-implementation-2026-11-03.md) |

## Core 架构与迁移

| 日期 | 报告 |
|---|---|
| 2026-11-03 | [FR-01 同一只读作用域准备输入复用](flow-runtime-input-reuse-2026-11-03.md) |
| 2026-11-03 | [Flow／Runtime 重复捕获与组装分析（实施前证据）](flow-runtime-repeat-work-analysis-2026-11-03.md) |
| 2026-11-03 | [ADR-059 B1：分解后第二字符缺字准入](text-stages-b1-decomposition-miss-2026-11-03.md) |
| 2026-11-03 | [ADR-059 B1：共享规范化内核准入与普通输出／成本验证](text-stages-b1-normalizer-kernel-2026-11-03.md) |
| 2026-11-03 | [ADR-059 B1：dotted-circle 输出与同步准入及最终验证](text-stages-b1-dotted-circle-kernel-2026-11-03.md) |
| 2026-11-03 | [ADR-059 B1：grapheme 合并与反向分组准入、输出与成本记录](text-stages-b1-grapheme-kernel-2026-11-03.md) |
| 2026-11-02 | [ADR-059 B1：ASCII 从右向左塑形准入](text-stages-b1-rtl-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：已映射 Unicode 字母与空格准入](text-stages-b1-simple-unicode-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：GDEF 字形分类与属性查询准入](text-stages-b1-gdef-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：已映射一般字符的属性准入](text-stages-b1-general-scalar-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：缺字与一对一规范化准入](text-stages-b1-singleton-normalization-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：缺字空格与不换行连字符准入](text-stages-b1-space-fallback-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：GPOS 配对定位准入](text-stages-b1-gpos-pair-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：GPOS 单字形定位准入](text-stages-b1-gpos-single-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：Harfrust 输入 buffer 准入（冷构造与 shaping 待完成）](text-stages-b1-buffer-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：规范化坐标与条件选择准入](text-stages-b1-instance-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：用户坐标归一化准入（avar2 与冷构造待完成）](text-stages-b1-variation-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：冷缓存目录、cmap 与 mark digest 准入（lookup／AAT 展开待完成）](text-stages-b1-cold-cache-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：LookupInfo 与子表缓存准入（AAT／计划／shaping 待完成）](text-stages-b1-lookup-cache-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：空 AAT 缓存的表头准入（非空 AAT／计划／shaping 待完成）](text-stages-b1-aat-headers-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：无布局表的 ShapePlan 集合与排序准入](text-stages-b1-plan-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：Shaper 借用字体表与坐标扫描配置准入](text-stages-b1-configuration-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：GSUB／GPOS 查询、变体 feature 与 lookup 收集准入](text-stages-b1-plan-layout-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B1：私有语言标签的扫描与计划存储准入](text-stages-b1-private-language-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B：候选断行准入与上游普通入口对照（分析与适配未完成）](text-stages-b-line-breaking-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B：模板复制与对齐的操作前准入](text-stages-b-operations-2026-11-02.md) |
| 2026-11-02 | [ADR-059 B：Parley 只读存储补丁已获批接入（适配未完成）](text-stages-b-storage-patch-2026-11-02.md) |
| 2026-11-02 | [ADR-059 A：统一文字阶段协议与实例资产登记](text-stages-a-implementation-2026-11-02.md) |
| 2026-11-02 | [ADR-059 修订 2 最终复核通过并接受（实施待授权）](adr-059-revision-2-review-2026-11-02.md) |
| 2026-11-02 | [ADR-059 修订 2：F01–F03 复核回应（待复核）](adr-059-revision-2-response-2026-11-02.md) |
| 2026-11-02 | [ADR-059 修订 1 复核意见（缓存查询顺序与错误规则待补清）](adr-059-revision-1-review-2026-11-02.md) |
| 2026-11-02 | [ADR-059 修订 1：R01–R06 设计回应（待复核）](adr-059-revision-1-response-2026-11-02.md) |
| 2026-11-02 | [ADR-059 分阶段文字引擎草案评审（建议修订后批准）](adr-059-draft-review-2026-11-02.md) |
| 2026-11-02 | [文字宽度复用隔离可行性与完整输出对照](text-width-reuse-feasibility-2026-11-02.md) |
| 2026-11-02 | [精确文字缓存查找优化与匹配 CPU 对照](text-cache-optimization-2026-11-02.md) |
| 2026-11-02 | [当前 Core Rust 能力状态复核](core-capability-status-2026-11-02.md) |
| 2026-11-02 | [S09-C Connections 注册准入与单入口迁移](p2-s09-c-implementation-2026-11-02.md) |
| 2026-11-02 | [S09-D Editor 扩展错误与 panic 诊断（最终门禁待补验）](p2-s09-d-implementation-2026-11-02.md) |
| 2026-10-30 | [S09-B Observations／Inspector 生命周期](p2-s09-b-implementation-2026-10-30.md) |
| 2026-10-30 | [S09-A Animation 服务结果与成本验证](p2-s09-a-implementation-2026-10-30.md) |
| 2026-10-30 | [ADR-057 修订 3 设计复核通过](adr-057-revision-3-review-2026-10-30.md) |
| 2026-10-30 | [ADR-057 修订 3 复核回应](adr-057-revision-3-response-2026-10-30.md) |
| 2026-10-30 | [ADR-057 修订 2 复核（待补清）](adr-057-revision-2-review-2026-10-30.md) |
| 2026-10-30 | [ADR-057 修订 2 审阅回应](adr-057-revision-2-response-2026-10-30.md) |
| 2026-10-30 | [ADR-057 修订 1 审阅意见](adr-057-revision-1-review-2026-10-30.md) |
| 2026-10-30 | [S09 现状盘点与设计复核](p2-s09-design-inventory-2026-10-30.md) |
| 2026-10-30 | [Zoom 图标按文字指标对齐](zoom-typographic-alignment-2026-10-30.md) |
| 2026-10-29 | [布局样例的鼠标窗口验收](official-layout-native-mouse-2026-10-29.md) |
| 2026-10-29 | [ScrollPane 与 Zoom 窗口验收](scroll-zoom-native-window-2026-10-29.md) |
| 2026-10-29 | [Logic 首个可运行切片](gef-logic-first-slice-2026-10-29.md) |
| 2026-10-29 | [三种布局的真实窗口 resize 与屏幕恢复](official-layout-native-window-2026-10-29.md) |
| 2026-10-29 | [S09 与开放吸附设计自审（待用户评审）](s09-and-snapping-design-review-2026-10-29.md) |
| 2026-10-29 | [S08-D 整批回归、渲染与成本关闭](p2-s08-d-completion-2026-10-29.md) |
| 2026-10-29 | [S08-C Detached 几何与外部指标准入](p2-s08-c-implementation-2026-10-29.md) |
| 2026-10-29 | [S08-B Border 受检构造与消费者验收](p2-s08-b-implementation-2026-10-29.md) |
| 2026-10-29 | [S08-A 受检样式、公共边界与成本验证](p2-s08-a-implementation-2026-10-29.md) |
| 2026-10-29 | [ADR-056 设计复核与下一批边界](adr-056-design-review-2026-10-29.md) |
| 2026-10-29 | [ADR-055 契约续验与同步成本复核](adr-055-followup-2026-10-29.md) |
| 2026-10-29 | [ADR-055 容器编辑实施验证](adr-055-implementation-2026-10-29.md) |
| 2026-10-29 | [Shapes Inspector 布局分析](shapes-inspector-layout-analysis-2026-10-29.md) |
| 2026-10-29 | [S08 输入不变量设计与检查记录](p2-s08-design-record-2026-10-29.md) |
| 2026-10-29 | [ADR-055 容器编辑草案首轮评审](adr-055-draft-review-2026-10-29.md) |
| 2026-10-29 | [颜色文本解析拒绝非法输入](core-color-text-input-2026-10-29.md) |
| 2026-10-28 | [Shapes 编辑器剩余功能与 SH-01～SH-10 自动验证](shapes-editor-implementation-2026-10-28.md) |
| 2026-10-28 | [Xilem / Masonry 上游依赖重新评估](xilem-masonry-upstream-reassessment-2026-10-28.md) |
| 2026-10-28 | [wasm_rust 遗留交付文件迁移](wasm-rust-file-migration-2026-10-28.md) |
| 2026-10-28 | [Masonry Native 首帧与 resize 续验](masonry-native-first-frame-followup-2026-10-28.md) |
| 2026-10-28 | [Masonry / Xilem 画布与 Shapes 首批消费者](masonry-xilem-canvas-implementation-2026-10-28.md) |
| 2026-10-28 | [长文本滚动与 resize 首批实施](long-text-scroll-resize-implementation-2026-10-28.md) |
| 2026-10-28 | [GEF 样例接入的 Scene 输出实施](gef-scene-target-implementation-2026-10-28.md) |
| 2026-10-27 | [布局与 Caret 消费者核验](official-layout-caret-consumers-2026-10-27.md) |
| 2026-10-27 | [矩形分边描边的平齐自由端](shape-free-end-butt-2026-10-27.md) |
| 2026-10-27 | [逐角圆角与矩形分边描边](independent-shape-corners-2026-10-27.md) |
| 2026-08-23 | [核心渲染管线](core-pipeline-2026-08-23.md) |
| 2026-08-29 | [文档与源码一致性](design-code-audit-2026-08-29.md) |
| 2026-09-08 | [Draw2D 核心能力差异](draw2d-core-capability-audit-2026-09-08.md) |
| 2026-09-08 | [长期架构与可扩展性](architecture-sustainability-review-2026-09-08.md) |
| 2026-09-08 | [D3 Runtime mutation](d3-runtime-mutation-2026-09-08.md) |
| 2026-09-08 | [D3 Runtime listener](d3-runtime-listener-2026-09-08.md) |
| 2026-09-09 | [D4 审计校准](d4-audit-calibration-2026-09-09.md) |
| 2026-09-09 | [D4 派生状态收敛](d4-derived-state-convergence-2026-09-09.md) |
| 2026-09-09 | [D4 资源因果与 Backend Session](d4-resource-causality-and-backend-session-2026-09-09.md) |
| 2026-09-10 | [ADR-001 至 ADR-013 审计](adr-audit-2026-09-10.md) |
| 2026-09-10 | [ADR-014 首批实现门禁](adr014-implementation-gate-2026-09-10.md) |
| 2026-09-10 | [ADR-014 D4.4](adr014-d4.4-increment-2026-09-10.md) |
| 2026-09-10 | [ADR-014 D4.5 性能](adr014-d4.5-performance-2026-09-10.md) |
| 2026-09-10 | [ADR-014 D4.6 收口](adr014-d4.6-completion-2026-09-10.md) |
| 2026-09-13 | [Draw2D Core 1.0 最终审计](draw2d-core-1.0-final-audit-2026-09-13.md) |
| 2026-09-16 | [Draw2D / GEF 全量语义映射](draw2d-gef-semantic-mapping-2026-09-16.md) |
| 2026-09-16 | [Draw2D / GEF 语义差异报告](draw2d-gef-semantic-differences-2026-09-16.md) |
| 2026-09-16 | [Draw2D / GEF 迁移实施方案](draw2d-gef-migration-plan-2026-09-16.md) |
| 2026-09-20 | [Draw2D / GEF 核心语义后续审计](draw2d-gef-core-semantic-follow-up-audit-2026-09-20.md) |
| 2026-09-22 | [Core 公开 API 语义与命名审计](core-public-api-audit-2026-09-22.md) |
| 2026-09-28 | [引擎能力与 API 稳定化评估](engine-capability-assessment-2026-09-28.md) |
| 2026-09-29 | [Crate 边界与发布结构审计](crate-boundary-audit-2026-09-29.md) |
| 2026-09-29 | [P2-T02 Text Interaction Geometry](p2-text-interaction-2026-09-29.md) |
| 2026-09-30 | [项目目标、设计与实现一致性审计](goal-design-code-audit-2026-09-30.md) |
| 2026-10-01 | [GA-4 模块与扩展表面](ga4-module-extension-completion-2026-10-01.md) |
| 2026-10-01 | [GA-5 文档与门禁](ga5-documentation-gate-completion-2026-10-01.md) |
| 2026-10-01 | [GA-6 目标矩阵审计](ga6-goal-matrix-audit-2026-10-01.md) |
| 2026-10-05 | [UML 复杂样例扩展能力](uml-extension-capability-2026-10-05.md) |
| 2026-10-05 | [P2-G02 统一文字与 Graphics](p2-g02-text-graphics-evidence.md) |
| 2026-10-06 | [P2-M01 Animation 架构评审](p2-m01-animation-architecture-review.md) |
| 2026-10-06 | [P2-M01A Clock / Timeline 实现](p2-m01a-animation-evidence.md) |
| 2026-10-06 | [P2-M01B Presentation / Damage 实现](p2-m01b-animation-presentation-evidence.md) |
| 2026-10-07 | [P2-M01C 领域消费者实现](p2-m01c-animation-consumer-evidence.md) |
| 2026-10-07 | [框架公共 API 命名、语义与职责复审](framework-public-api-follow-up-audit-2026-10-07.md) |
| 2026-10-06 | [公共 API 统一迁移](public-api-unification-completion-2026-10-06.md) |
| 2026-10-08 | [P2-F02 Figure Capability 实现](p2-f02-figure-capability-completion-2026-10-08.md) |
| 2026-10-08 | [TC-13 / TC-14 公开表面与热路径日志收口](tc13-tc14-api-surface-hot-path-completion-2026-10-08.md) |
| 2026-10-08 | [TC-04 类型化属性身份收口](tc04-typed-property-identity-completion-2026-10-08.md) |
| 2026-10-09 | [API 与架构 Review](api-architecture-review-2026-10-09.md) |
| 2026-10-09 | [P2-S02 显式领域导入与 Crate Root 收口](p2-s02-explicit-domain-imports-completion-2026-10-09.md) |
| 2026-10-10 | [P2-S03 Runtime 子系统 Facade 与统一 Figure Mutation](p2-s03-runtime-facade-completion-2026-10-10.md) |
| 2026-10-12 | [P2-S04 Editor Tool / Request / Policy / Handle 开放协议](p2-s04-editor-open-protocol-completion-2026-10-10.md) |
| 2026-10-12 | [图形框架文档时效与架构边界审查](framework-documentation-and-architecture-review-2026-10-12.md) |
| 2026-10-12 | [P2-S05 深层布局与文字 Presentation 收敛](p2-s05-deep-layout-presentation-completion-2026-10-12.md) |
| 2026-10-12 | [图形框架五项架构契约修订](framework-architecture-contract-revision-2026-10-12.md) |
| 2026-10-13 | [ADR-036 Context 阶段权限投影与 Query 命名](adr-036-context-phase-authority-completion-2026-10-13.md) |
| 2026-10-14 | [P2-S06 投影失败隔离与批量校验机制必要性](p2-s06-mechanism-necessity-2026-10-14.md) |
| 2026-10-14 | [路线图与待办校准复核](roadmap-calibration-2026-10-14.md) |
| 2026-10-14 | [ADR-037 草案首轮评审](adr-037-draft-review-2026-10-14.md) |
| 2026-10-15 | [ADR-037 修订 1 复核](adr-037-revision-1-review-2026-10-15.md) |
| 2026-10-15 | [P2-S06 实施证据](p2-s06-implementation-evidence-2026-10-15.md) |
| 2026-10-15 | [P2-S06 剩余验收复核](p2-s06-remaining-evidence-review-2026-10-15.md) |
| 2026-10-15 | [P2-S06 失败隔离关闭记录](p2-s06-failure-isolation-completion-2026-10-15.md) |
| 2026-10-15 | [P2-S07 查询设计与当前反例盘点（草案）](p2-s07-query-design-inventory-2026-10-15.md) |
| 2026-10-15 | [ADR-038 草案评审](adr-038-draft-review-2026-10-15.md) |
| 2026-10-16 | [ADR-038 修订 1 复核](adr-038-revision-1-review-2026-10-16.md) |
| 2026-10-16 | [P2-S07 布局查询实施证据](p2-s07-layout-query-evidence-2026-10-16.md) |
| 2026-10-16 | [P2-S07 坐标与 Route 查询实施证据](p2-s07-coordinate-route-query-evidence-2026-10-16.md) |
| 2026-10-16 | [P2-S07 Tree 与 Stable 查询实施证据](p2-s07-tree-query-evidence-2026-10-16.md) |
| 2026-10-16 | [P2-S07 查询身份与失败语义完成核验](p2-s07-query-identity-completion-2026-10-16.md) |
| 2026-10-16 | [xtask 命令体系价值评估](xtask-command-system-value-assessment-2026-10-16.md) |
| 2026-10-16 | [suites 配置与单元测试的职责边界](suite-configuration-and-unit-test-boundary-2026-10-16.md) |
| 2026-10-19 | [全量文档知识修正](documentation-knowledge-revision-2026-10-19.md) |
| 2026-10-19 | [Draw2D 样例与 API 组合性分析](draw2d-example-api-ergonomics-2026-10-19.md) |
| 2026-10-22 | [ADR-043 草案审核意见](adr-043-draft-review-2026-10-22.md) |
| 2026-10-22 | [图投影 preparation 增量评审](graph-projection-preparation-review-2026-10-22.md) |
| 2026-10-23 | [K07 共享视图与宿主背景方案评审](k07-shared-scene-view-background-review-2026-10-23.md) |
| 2026-10-23 | [K07 方案修订 2 响应（待复核）](k07-shared-scene-view-background-revision-2026-10-23.md) |
| 2026-10-23 | [K07 修订 2 复核（暂不通过）](k07-shared-scene-view-background-revision-2-review-2026-10-23.md) |
| 2026-10-23 | [K07 修订 3 响应（待复核）](k07-shared-scene-view-background-revision-3-response-2026-10-23.md) |
| 2026-10-23 | [K07 修订 3 设计复核通过](k07-shared-scene-view-background-revision-3-review-2026-10-23.md) |
| 2026-10-23 | [K07-1 场景捕获与订阅交接](k07-1-scene-capture-evidence-2026-10-23.md) |
| 2026-10-24 | [Tree 表现几何方案与 Rust 实现评审（待修订）](tree-layout-presentation-review-2026-10-24.md) |
| 2026-10-24 | [Tree 修订 2 复核（暂不通过）](tree-layout-presentation-revision-2-review-2026-10-24.md) |
| 2026-10-24 | [Tree 修订 3 设计复核通过](tree-layout-presentation-revision-3-review-2026-10-24.md) |
| 2026-10-26 | [项目代码质量评审](code-quality-review-2026-10-26.md) |
| 2026-10-27 | [长文本性能方案评审（方向有条件通过，待修订）](long-text-performance-proposal-review-2026-10-27.md) |
| 2026-10-27 | [长文本修订 2 首批设计复核通过](long-text-performance-revision-2-review-2026-10-27.md) |
| 2026-10-27 | [文本增量排版方案审计意见（待修订复核）](long-text-incremental-layout-review-2026-10-27.md) |
| 2026-10-28 | [长文本滚动与 resize 方案评审（待修订复核）](long-text-scroll-resize-review-2026-10-28.md) |

## 专题核验

以下报告保留各自快照与限制，不能根据标题把剩余平台证据推定为完成。

| 日期 | 报告 |
|---|---|
| 2026-09-29 | [Direct Edit Session](p2-direct-text-edit-session-2026-09-29.md) |
| 2026-09-29 | [Text Input Bridge](p2-text-input-bridge-2026-09-29.md) |
| 2026-10-01 | [GA-3 四平台资格](ga3-platform-qualification-2026-10-01.md) |
| 2026-10-05 | [Graphics 与像素证据](p2-g01-graphics-evidence.md) |
| 2026-10-08 | [临时概念与长期演进审计](temporary-concept-design-audit-2026-10-08.md) |
| 2026-10-08 | [RenderBackend Failure](tc12-render-backend-failure-completion-2026-10-08.md) |
| 2026-10-09 | [Graphics Cutover](tc01-graphics-cutover-completion-2026-10-09.md) |
| 2026-10-09 | [Viewer 编辑与驱动](tc07-viewer-edit-boundary-completion-2026-10-09.md) |
| 2026-10-09 | [ResourceProvider](tc11-resource-provider-completion-2026-10-09.md) |
| 2026-10-16 | [Draw2D 官方示例对等审计](draw2d-official-examples-parity-2026-10-16.md) |
| 2026-10-26 | [官方样例剩余能力](draw2d-official-examples-remaining-audit-2026-10-26.md) |
| 2026-10-26 | [逐操作 AA 可行性实验](shape-aa-feasibility-2026-10-26.md) |
| 2026-10-26 | [逐操作 AA 实施与成本](per-operation-antialias-implementation-2026-10-26.md) |
| 2026-10-26 | [官方样例逐项功能复核](draw2d-official-examples-functional-audit-2026-10-26.md) |
| 2026-10-26 | [官方样例能力补充实施](official-example-capability-increment-2026-10-26.md) |
| 2026-10-27 | [官方样例 Core 增量实施](official-example-core-increment-2026-10-27.md) |
| 2026-10-28 | [Print、Zoom 与 UML 系统字体采用](official-system-fonts-2026-10-28.md) |
| 2026-10-26 | [TextFlowLarge 打开耗时与优化方向](textflow-large-performance-analysis-2026-10-26.md) |
| 2026-10-27 | [长文本优化首批实施与性能证据](long-text-performance-implementation-2026-10-27.md) |

## 平台与产品验收

| 日期 | 报告 |
|---|---|
| 2026-09-10 | [M10.5 Tooltip 与 Accessibility](m10.5-tooltip-accessibility-2026-09-10.md) |
| 2026-09-12 | [macOS Live Resize](macos-live-resize-transaction-2026-09-12.md) |
| 2026-09-12 | [M1-M8 人工验收](m1-m8-manual-acceptance-2026-09-12.md) |
| 2026-09-13 | [M10 Web 等价](m10-web-equivalence-2026-09-13.md) |
| 2026-09-30 | [Web EditContext 集成验证](web-edit-context-capability-2026-09-30.md) |

## Editor

- [E03 容器编辑组合输入与成本拆分续验](editor-container-combinations-2026-11-02.md)：
  Web 46 个检查点和阶段成本通过；Native 系统 DnD 与跨显示器仍未验收。
- [E03 容器编辑故障与平台输入补验](editor-container-followup-2026-10-30.md)：
  隔离计数器注入、Web DPR 1／2 与 Native 输入；完整 E03 验收仍未关闭。

| 日期 | 报告 |
|---|---|
| 2026-10-29 | [ADR-055 修订 2 设计复核通过](adr-055-revision-2-review-2026-10-29.md) |
| 2026-10-29 | [ADR-055 修订 1 复核（暂不通过）](adr-055-revision-1-review-2026-10-29.md) |
| 2026-10-29 | [ADR-055 容器编辑与父坐标草案评审（待修订复核）](adr-055-draft-review-2026-10-29.md) |
| 2026-10-28 | [Masonry 无 vendor 上游迁移](masonry-upstream-migration-2026-10-28.md) |
| 2026-09-13 | [GEF / Editor 启动就绪](gef-readiness-analysis-2026-09-13.md) |
| 2026-09-13 | [G1 Model 与 Command](g1-model-command-completion-2026-09-13.md) |
| 2026-09-13 | [G2 Viewer 投影](g2-viewer-projection-completion-2026-09-13.md) |
| 2026-09-13 | [G3 Selection 与 Targeting](g3-selection-targeting-behavior-2026-09-13.md) |
| 2026-09-14 | [G4 编辑闭环](g4-editing-loop-behavior-2026-09-14.md) |
| 2026-09-14 | [G5.1 Connection Projection](g5-connection-projection-design-2026-09-14.md) |
| 2026-09-14 | [G5.2 Connection Creation](g5-connection-creation-behavior-2026-09-14.md) |
| 2026-09-15 | [G5.3 Connection Reconnect](g5-connection-reconnect-behavior-2026-09-15.md) |
| 2026-09-15 | [G5.4 Connection Bendpoint](g5-connection-bendpoint-behavior-2026-09-15.md) |
| 2026-09-15 | [G5.5 Viewport Auto-expose](g5-viewport-autoexpose-behavior-2026-09-15.md) |
| 2026-09-15 | [Connection 扩展边界整改](connection-extensibility-correction-2026-09-15.md) |
| 2026-09-16 | [Draw2D / GEF 语义审计整改状态](draw2d-gef-semantic-remediation-2026-09-16.md) |

- [B1 通用语言映射准入](text-stages-b1-general-language-2026-11-02.md)：
  有序规则、主语言表与逐操作拒绝；脚本回调及实际 shaping 继续实施。
- [B1 脚本专用规划回调准入](text-stages-b1-script-callbacks-2026-11-02.md)：
  Arabic／Syriac／Hangul 共享回调、可失败存储与上游完整输出对照；
  实际 shaping 和 buffer 恢复继续实施。
- [B1 非扩张塑形准入与 buffer 恢复](text-stages-b1-shaping-2026-11-02.md)：
  LTR ASCII 实际 pipeline、逐点拒绝恢复与初始化数组成本；
  复杂 shaping 和 Parley 编排继续实施。
- [B1 单字形替换操作前准入](text-stages-b1-single-substitution-2026-11-02.md)：
  GSUB SingleSubst、完整 lookup 冷缓存与实际访问计费；
  上游四配置完整输出、拒绝恢复和冷／热成本已验证。
- [B1 多字形替换增长与访问准入](text-stages-b1-multiple-substitution-2026-11-02.md)：
  sequence 长度、双数组增长和前缀复制准入；
  八矩阵四配置、拒绝恢复、成本与 Core／Wasm 定向门禁通过。
- [B1 连字匹配存储与重复访问准入](text-stages-b1-ligature-substitution-2026-11-02.md)：
  匹配位置 inline／spill、组件求和边界及重复 cluster 扫描；
  九矩阵四配置、拒绝恢复、成本及 Core／Wasm 定向门禁通过。
- [B1 上下文匹配、移动与嵌套单字形替换准入](text-stages-b1-context-substitution-2026-11-02.md)：
  十矩阵四配置完整输出、各 203 项依赖与 60 项消费者通过；
  成本及 Core／Wasm 定向门禁通过，B1 与默认启用未关闭。
- [B1 上下文匹配位置的堆存储与备份准入](text-stages-b1-context-spill-2026-11-02.md)：
  零 flags 单字形叶子的 Format 3 范围扩展至 64，匹配与备份先准入；
  完整输出、定向消费者、成本与跨目标门禁通过，B1 与默认启用保持未关闭。
- [B1 GPOS 单字形定位准入](text-stages-b1-gpos-single-2026-11-02.md)：
  零 flags 标量值、前置替换扩容与精确拒绝恢复；
  十二矩阵四配置、消费者、成本和跨目标门禁通过，默认启用保持未关闭。
- [B1 GPOS 配对定位准入](text-stages-b1-gpos-pair-2026-11-02.md)：
  两种 PairPos 的查表、class、安全标记与矩阵边界先准入；
  原始格式保留位反例补齐，十三矩阵四配置、消费者、成本与跨目标门禁通过；
  B1 和默认启用保持未关闭。

- [B1 ASCII 从右向左塑形准入](text-stages-b1-rtl-2026-11-02.md)：
  保存目标方向，原生方向反转、镜像查询和最终反转先计费；
  十四矩阵四配置、消费者、成本与跨目标门禁通过，
  B1 与默认启用保持未关闭。

完整语义审计的固定基线见
[`../reference/draw2d-gef-semantic-baseline-2026-09-16.md`](../reference/draw2d-gef-semantic-baseline-2026-09-16.md)，
原始分组报告、日志和结构化结果见
[`../../../verification/evidence/`](../evidence/README.md)。
P1 关闭进度见
[`draw2d-gef-semantic-remediation-2026-09-16.md`](draw2d-gef-semantic-remediation-2026-09-16.md)。
