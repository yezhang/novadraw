# Editor 框架架构

类型：`normative-design`

规范效力：`accepted`；依据 ADR-015 及后续 ADR-032/034/037。

本文件定义 `novadraw-editor` 的目标架构。GEF Classic 源码事实见
[`../../reference/gef/core-principles.md`](../../reference/gef/core-principles.md)，
采用与差异见 [`../../parity/gef/api-coverage.md`](../../parity/gef/api-coverage.md)，
实施状态见 [`../../roadmap/editor/00-index.md`](../../roadmap/editor/00-index.md)。

G5.1 ConnectionPart 投影的规范细化见
[`g5-connection-projection.md`](g5-connection-projection.md)。

## 1. 目标与边界

Editor 框架负责把应用模型、Novadraw Figure 和用户编辑行为连接成可撤销的事务：

```text
Model notification
       |
       v
EditPart tree -> FigureTree / Runtime -> Render
       ^
       |
Tool -> Request -> EditPolicy -> Command -> CommandStack -> Model
```

Editor 不负责：

- Figure 的绘制、布局、坐标、命中、damage 或资源生命周期；
- 具体业务文档 schema；
- winit、DOM、AppKit 或 Vello；
- 把任意业务模型强制装入一个框架对象层次；
- 复刻 Eclipse Workbench、JFace、Palette 或 TreeViewer。

## 2. 核心不变量

1. 模型是持久化事实源，Figure 是可重建视图。
2. EditPart 是模型与 Figure 的控制器，不是第二份业务模型。
3. Command 修改模型，不直接修改 EditPart 或 Figure。
4. 模型通知驱动视图刷新；Command 执行后不能手工伪造视图结果。
5. EditPart topology、Figure topology 和模型 containment 可以对应，但不共享身份。
6. selection 属于 Viewer；pressed/hover/capture 属于对应输入状态机。
7. feedback 必须在命令执行前清除或转为稳定模型结果。
8. 任何删除都必须同步清理 selection、focus、registry、policy、feedback 和订阅。

## 3. 身份与所有权

### 3.1 身份域

```text
EditorDomain
├── CommandStack
├── active Tool
└── Viewer*
    ├── EditorNamespace
    ├── PartTree<EditPartId>
    ├── model_registry: ModelId -> EditPartId
    ├── visual_registry: FigureId -> VisualOwner
    ├── SelectionModel<EditPartId>
    ├── Runtime<FigureId>
    └── ZoomManager
```

`VisualOwner` 至少区分：

- `Part(EditPartId)`；
- `Handle(HandleId)`；
- `Feedback(FeedbackId)`；
- 不参与 Editor targeting 的普通 Figure。

命中 Figure 后，Viewer 沿 Figure ancestor 链查找首个已注册 visual owner。该规则保留
GEF compound Figure/content pane 的语义，不要求每个内部 Figure 都注册 EditPart。

### 3.2 ModelId

框架不定义全局业务 ID 类型。应用 adapter 提供稳定、可比较且可哈希的 ModelId。
ModelId 不得使用借用地址、`Rc` 地址或临时 arena index 作为持久身份。

### 3.3 EditPartId

EditPartId 使用 editor namespace + generational key。删除后旧 ID 必须失效；跨 Viewer
或跨 EditorDomain 误用必须结构化拒绝。

## 4. 模型适配

首版使用应用定义的 adapter，而不是 `Box<dyn Any>` 模型仓库：

```rust
pub trait ModelAdapter {
    type ModelId: Copy + Eq + Hash + Debug + 'static;
    type Event;
    type Error: Error + 'static;

    fn root(&self) -> Self::ModelId;
    fn revision(&self) -> ModelRevision;
    fn children(&self, model: Self::ModelId) -> Result<Vec<Self::ModelId>, Self::Error>;
    fn drain_events(&mut self) -> Vec<ModelEvent<Self::ModelId, Self::Event>>;
}
```

这是概念接口。对象安全、借用和通知形态由 G1/G2 的真实模型用例固定。框架需要支持：

- 初始模型投影；
- 有序 child 增删与重排；
- 属性变化刷新；
- source/target connection 关系；
- 批量通知和稳定 revision；
- 保存/加载后以新运行时身份重建。

G2 只投影 containment。Connection 的 source/target 双向发现必须与 connection layer、
Connection Runtime binding 和单 connection part 去重一起在 G5 引入，不能提前挂到
临时父 Figure。

Viewer 只公开 adapter 的只读视图。应用模型变化分为两个入口：

- Editor 命令由 crate 内部 `ViewerEditSession` 取得短期模型写权限；
- 非 history 变化通过 `synchronize_model` 的非逃逸 callback 提交，或由共享 adapter
  在外部发布后调用 `synchronize`。

两个入口最终都必须校验 revision、drain 通知并刷新投影。不得重新公开 `model_mut`
或要求调用者手工拼接“修改模型后 refresh”。

## 5. EditPart

### 5.1 PartNode 与行为分离

采用与 FigureNode/Figure 相同的 Rust 迁移原则：

```text
PartNode
├── parent / children
├── model_id
├── figure_id
├── lifecycle / selection state
├── installed policy roles
└── Box<dyn EditPartBehavior>
```

PartTree 统一维护 topology、注册和生命周期；具体 EditPartBehavior 只表达差异行为：

- 创建 Figure；
- 指定 content pane；
- 枚举 model children 和 model connections；
- 刷新 visual；
- 安装 policy；
- 注册/注销模型观察。

不复制 Java 的宽 `EditPart` 接口和默认空方法。

### 5.2 生命周期

稳定顺序：

```text
factory creates behavior
-> bind model
-> create Figure
-> attach PartNode and Figure
-> register model/visual mappings
-> install policies
-> initial refresh
-> activate subscriptions
```

移除顺序：

```text
erase feedback
-> remove selection/focus
-> deactivate subscriptions and policies
-> recursively unregister descendants/connections
-> dispose Figure subtree
-> retire EditPartId
```

Undo 重建新的 EditPart/Figure；Command 不保存旧运行时句柄。

## 6. Viewer

Viewer 是一个编辑视图的组合根，负责：

- contents 和 RootEditPart；
- PartFactory；
- PartTree 生命周期；
- model/visual registry；
- selection 和 EditPart focus；
- targeting；
- Runtime 与 root layer 组合；
- root scalable/viewport 对应的长期 ZoomManager；
- 把归一化输入交给输入仲裁器。

RootEditPart 不对应业务模型，默认建立：

```text
root layered pane
├── viewport layer
│   └── viewport
│       └── scalable layers
│           ├── grid layer
│           ├── printable layers
│           │   ├── primary layer
│           │   └── connection layer
│           └── scaled feedback layer
├── feedback layer               # 不随内容缩放或滚动
└── handle layer                 # 不随内容缩放或滚动
```

首版可以不实现 grid/guide，但 layer key 和缩放域必须从开始就明确。

Viewer 构造 root layers 后创建并长期持有一个 `ZoomManager`，绑定同一组 root
scalable pane 与 Viewport。zoom levels、scroll policy 和未来 listener 都属于该
manager 的 Viewer 生命周期状态，不能在每次 zoom 操作中临时重建。Viewer 可以暴露
只读 manager 查询及受控配置方法，但不得提供 `zoom_manager_mut()` 或绕过 Runtime
mutation facade 直接修改 scale / view location。

平台宿主通过短生命周期 `ViewerDrive` 驱动 frame submission、backend session、
surface resize、time、Figure gesture/focus 和必要资源注册。`ViewerDrive` 不暴露
Runtime、FigureTree、模型、registry 或 Editor 事务状态；对应方法不得同时保留在
`GraphicalViewer` 上形成双入口。

## 7. Selection 与 Focus

SelectionModel 保存有序 EditPartId 列表：

- 空视觉选择对外可投影为 contents part；
- 最后一个元素是 primary selection；
- append、replace、toggle、remove 和 clear 都产生 typed delta；
- 删除或失活自动 reconcile；
- selection visual 由 policy/feedback layer 生成。

EditPart focus 与 Figure keyboard focus 是不同状态。Viewer 可以在明确场景同步二者，
但不能将一个状态别名成另一个。

## 8. Request 与 EditPolicy

Request 是不可直接修改模型的交互意图。每个 request family 由实现
`RequestProtocol<A>` 的 marker、`RequestKey<R>`、typed payload 和 typed
contribution 组成。公共调用只接受匹配的 marker/payload 组合；`Any` 与 downcast
只存在于私有 registry。

首批 typed request：

- `SelectionRequest`；
- `ChangeBoundsRequest`；
- `CreateRequest`；
- `DeleteRequest`；
- `CreateConnectionRequest`；
- `ReconnectRequest`；
- `DirectTextEditRequest`（P2-E02）。

`RequestMetadata` 统一保存 source parts 和 interaction revision。入口域位置、增量、
modifier 与 target candidate 属于具体 payload。禁止使用闭合 request enum 或无约束
`HashMap<String, Any>` 作为公共协议。

EditPolicy 通过 `PolicyKey<S>` 安装到 PartNode，并在安装时通过
`PolicyHandlerBuilder` 注册 typed handler。内置 slot 只是预定义 marker，外部 slot
使用完全相同的注册路径。Policy 可以：

- 判断是否理解 Request；
- 返回 target part；
- 贡献 Command；
- 创建、更新和清除 source/target feedback。

target 解析与贡献聚合是两个阶段：

1. 对每个 Request source，把该 Part 视为候选，按稳定 slot 顺序取首个非空 target；
2. 校验 target 属于当前 Viewer、仍 active 且绑定模型；
3. 保留 Request 中的原始 source 身份，在 target Part 的 policies 上聚合 Command 和
   feedback；
4. 多个 source 指向同一 target 时只聚合一次；target 不递归重定向。

foreign、retired 或无模型 target 必须结构化拒绝，不能退回 source，也不能把 target
仅当作“是否理解”的布尔值。feedback owner 使用解析后的 target，以便删除或失活时
按真实归属清理。

多个 Command contribution 的组合顺序必须确定；显式拒绝与“无贡献”必须区分。
不存在 handler 即表示无贡献，不再调用独立的 `understands`。

Tool 统一实现 object-safe `Tool<A>`，`EditorDomain` 只持有 `Box<dyn Tool<A>>`。
Tool 通过窄 `ToolContext` 分派 typed request、访问目标与提交命令；callback 返回的
`ToolDirective` 只控制继续、释放 capture 或停用，不列举业务 Tool。Handle 使用
`HandleActionProtocol` 和 typed payload，action 到 Tool 的 factory 可由外部注册。

## 9. Command 与 CommandStack

Command 只操作应用模型：

```text
prepare/can_execute
-> execute
-> push undo history
-> model notification
-> EditPart refresh
```

必须定义：

- execute、undo、redo 的结构化错误；
- CompoundCommand 的执行和逆序 undo；
- 新 execute 清空 redo；
- undo limit 与 dispose；
- save location 和 dirty；
- 失败是否进入 history；
- observer 通知时序。

首版不承诺对任意应用副作用做自动回滚。若 CompoundCommand 需要原子性，应由模型
事务或 prepared command 明确提供，不能假设逐条 `undo` 永远成功。

Command 返回普通 operation error 时，必须保证模型和 Command 保持调用前状态；
无法保证时必须返回显式 unknown-state error。CompoundCommand 会补偿已成功的前缀，
但补偿失败、unknown-state error 或扩展 panic 都会使 CommandStack faulted。Faulted
stack 保持 dirty 并拒绝继续编辑、flush 或标记保存点，由 Host 重建模型与 Editor。
Command 析构不得 panic；history trim/flush 不承诺恢复任意析构副作用。

EditorDomain 的 execute、undo 和 redo 必须在 `ViewerEditSession` 中完成：

```text
synchronize pending external notifications
-> CommandStack operation with a short model borrow
-> success: validate notifications and synchronize projection
-> recoverable rejection: prove no observable revision change
-> unknown state or panic: fault CommandStack and Viewer
```

CommandStack 的 `has_undo/has_redo` 是不执行扩展代码的纯 history 查询。
`check_undo/check_redo` 才调用 Command capability，并以 `Result<bool, _>` 区分明确拒绝
与扩展 panic。实际 undo/redo 仍在操作点重新检查，不能依赖较早的 UI 探测结果。

## 10. Tool 与输入仲裁

Tool 是 EditorDomain 级状态机，同一 domain 同时只有一个 active Tool。Viewer 提供
当前输入来源和 targeting 服务。

输入仲裁必须明确：

1. 平台输入归一化；
2. Figure-native widget 优先处理；
3. Figure 已消费或建立 capture 时，不进入 Tool；
4. 否则 active Tool 接收事件；
5. Tool 在一次 gesture 内固定 tracker/source，并持续更新 target；
6. release/cancel 清理 feedback 和 capture；
7. 执行 Command 前先清除临时视觉。

`runtime.input()` 的 dispatch 入口通过平台无关的 `DispatchOutcome` 返回 target、handled
与 dispatch 后 capture；Editor 不得在 app 层根据 hover 或 repaint 猜测消费结果。

### 10.1 Direct Text Edit

P2-E02 在既有 Request/Policy/Command 链路上增加单一 direct-edit session：

```text
DirectTextEditRequest
-> feature descriptor + source revision
-> transient draft / text selection / composition
-> DirectEditPolicy builds model Command
-> CommandStack
-> model notification refresh
```

草稿、caret、selection 和 IME composition 属于 Editor session；TextFlow Core 只提供
immutable layout 上的位置与几何查询；Native/Web adapter 只桥接平台输入和候选窗。
Viewer selection 与 session 内 text selection 不共享状态。完整契约见
[`p2-direct-text-edit.md`](p2-direct-text-edit.md)。

## 11. 扩展点

- `ModelAdapter`：业务模型与通知；
- `EditPartFactory`：模型到 controller；
- `EditPartBehavior`：visual 与 refresh；
- `EditPolicy`：可组合编辑能力；
- `Command`：业务变更；
- `Tool` / tracker：输入解释；
- `SelectionPolicy`：选择规则；
- `RootLayerFactory`：root layer 组合；
- `DirectEditPolicy`：feature snapshot、draft feedback 与模型 Command；
- `ClipboardAdapter`、`Serializer`：后续产品集成。

## 12. 失败模式

公共操作至少区分：

- foreign editor/viewer/part/figure identity；
- unknown or retired model/part/visual；
- duplicate model or visual registration；
- inconsistent PartTree/FigureTree relation；
- unsupported request；
- command rejected/failed；
- rejected command changed the observable model revision；
- model notification gap or stale revision；
- feedback cleanup failure；
- input capture conflict；
- editor faulted。

发生结构一致性破坏或扩展 panic 后，Editor 进入 faulted；不得只清理 updating 标志后
继续接受命令。

[ADR-037](../../adr/adr-037-editor-incremental-failure-isolation.md)进一步规定：
新建 Part 子树或 Connection 失败时，按实际取得资源和生命周期进度清理；
不回滚完整 synchronize 的成功前缀，也不撤销成功的模型命令或 history。
Overlay 在写入前校验完整输入批次。Core fault 后停止普通 mutation，保留结构退休
与未完成 callback 的事实，沿既有宿主退出协议隔离旧 Runtime。
Viewer fault 阻止新帧准备；Runtime 健康时仍可结清已有 submission。

## 13. 验证入口

[ADR-055](../../adr/adr-055-container-editing-protocol.md)补充容器编辑：
`container` 领域拥有固定批次、当前父域候选、统一资格与受检计划。
Viewer 提供实际 content pane 映射及排除源视觉子树的 Core 命中；
ToolContext 提供公开 begin/candidate/resolve/show/submit 服务，
移动与创建 Tool 复用这些服务。布局策略通过关联 Payload/Request/Plan 接入，
模型命令仍经 ViewerEditSession 提交，换父与 undo/redo 按稳定 ModelId 恢复完整
selection/primary/focus。来源 revision 或 policy generation 变化取消手势；
视口变化重新投影，提交前再次校验；清理失败阻止构造命令。

- Headless：模型投影、生命周期、registry、selection、command history；
- Contract：targeting、policy contribution、feedback cleanup、input arbitration；
- Native/Web：create/move/delete/reconnect、zoom/scroll、keyboard；
- Recovery：保存/加载、Runtime 重建、undo 后新 EditPart 身份；
- P2 direct edit：文本几何、session、IME replay、Native/Web 输入等价；
- Accessibility：稳定模型语义与 Figure snapshot 的组合，后置到基础编辑闭环之后。
