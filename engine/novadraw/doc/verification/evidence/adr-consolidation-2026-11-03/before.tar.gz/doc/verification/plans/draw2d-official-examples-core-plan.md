# 官方示例 Core 实施计划

类型：`verification`

日期：2026-10-19

状态：Canvas 功能已实现，逐入口和平台验收继续；2026-11-02 按当前 Rust 能力复核。

## 当前能力状态

能力归属：Core 负责图形、布局、文字、输入和共享场景协议；backend／platform
负责设备覆盖、字体来源与呈现；样例负责场景编排。
当前 25 个入口均可运行，catalog 保持 17 个 complete、8 个 in_progress。
入口状态与 Core 能力状态分别记录，不能从未验收的入口推断 Core 尚未实现。
逐项源码和证据见[本轮能力复核](../reviews/core-capability-status-2026-11-02.md)。

| 能力 | 当前实现 | 尚未完成的边界 |
|---|---|---|
| Grid／Flow／Toolbar 与文字约束重测 | 已实现；已有 Rust、retained 像素与 macOS 窗口证据 | 其他平台像素及完整呈现验收 |
| owner-aware Locator、visibility graph 路由 | 已实现，连接和 UML 已消费 | 跨 viewport Connection 是独立未实施 delta |
| 五部件 ScrollBar、共享 RangeModel、repeat | 已实现 | 完整主题、滚轮／cursor 与跨平台输入验收 |
| structured flow、真实 inline Figure、继承方向、caret／selection | 已实现，六个文字入口已有契约证据 | Large 性能目标和部分跨平台栅格验收 |
| Directed／Compound 图布局、Tree 表现动画 | 已实现，批准切片已验证 | 通用动画的 M01-D 平台验收仍保留 |
| capture／SceneView／Thumbnail 与透明宿主背景 | 已实现，K07 六片完成 | Web 背景、跨显示器 DPI 与原生 runner 验收 |
| 逐操作图形／文字 AA、低 miter、SVG 密度、跨字体下划线 | 已实现，ADR-047／049／050 已有契约与 GPU 证据 | 通用设备 hairline 未实现；Cocoa 零宽映射不等于设备 hairline |
| Canvas 图文输出 | 已实现 | P2-O01 通用打印／导出目标未实施，SWT 打印作业不在本计划 |
| 精确段落缓存与共享 glyph IR | 已实现 | 默认原生 glyph 的安全可见输出、宽度分阶段复用和整体性能目标未闭合 |

本轮按用户要求推进文字优化，先保持 ADR-051 的完整请求、引擎身份、revision、
预算和发布合同，优化既有精确缓存查找。新 shaping／换行阶段协议、worker、
渐进几何和原生覆盖能力另行评审，不以实现内部优化代替其验收。

## 目标与边界

实现全部 25 个官方示例中 Canvas 内的 Draw2D 能力，包括进行中、未移植和阻塞入口。
官方源码只作为只读语义参考；本项目不编写、修改、编译或运行 Java 验证代码。
不建设 SWT 原生控件的 Novadraw 替代体系，不以原生 Text/Combo/Scale/Group、
Shell pack 或打印对话框的复刻作为引擎毕业条件。

Canvas 内由 Draw2D Figure 实现的 Label、ScrollBar、ScrollPane、FlowPage、
MultiLineLabel、Connection、布局和边框仍在范围内。Canvas 外的控制面板可以
使用宿主已有控件或临时示例工具，工具只驱动场景参数；临时面板不定义 Core API，
也不作为原生控件对等证据。窗口、字体、DPI、输入、surface 和背景源只保留
LightweightSystem 所需的宿主适配，不把整个 SWT 产品栈纳入项目。

Core 负责 Figure 树、几何、测量/布局、输入分发、资源、连接和稳定更新；
扩展实现负责可替换算法与 Draw2D Figure 组件；backend/platform 负责栅格与宿主服务。
示例控制器持有选中目标、配对关系和临时高亮/追加状态。不新增 GEF/Editor 依赖。
当前执行队列只在 [P2 backlog](../../roadmap/p2-delta-backlog.md) 维护。
Grid、Flow、Toolbar 和 Tree 的宿主控制面板接入与验证见
[egui 控制面板](draw2d-egui-panel.md)。

## 本次撤销与保留

撤销本轮新增的 Java 探针、运行脚本、Java 生成基线、反射菜单验证和上游运行门禁。
撤销 SWT 原生控件桥接、原生面板完整复刻和真实打印作业作为本计划目标。
既有第三方参考源码不修改，也不删除；历史 Git 提交可追溯，工作树不再保留这些探针。

保留符合 Canvas 语义的 Core 修复：完整子树/回执、资源准入、contents 替换、
Connection binding、Grid span/grab、measurement hints、Flow/Toolbar 轴向测量、
整数分配和布局失效。验证改为 Rust 外部契约、Canvas 场景、Render IR 与受影响平台
运行测试。移除 Java 依赖后，不再用此前 Java 基线组数作为现行验收结论。

## 分批能力与退出条件

K/H 编号沿用已有任务身份，收窄其定义；不创建新 M/G 编号。
每批按只读源码契约 → 定向实现核对 → Rust 失败反例 → 修复 → 消费者 → 验证推进。
新重大公共契约继续先做 ADR 评审。内置/外部能力共用相同公开扩展模型。

| 步骤 | Canvas 能力与消费者 | 退出条件 |
|---|---|---|
| K00 | 25 入口的 Figure/helper/resource 与可达行为清单 | 本地清单与 catalog 一致；区分 Draw2D Figure 和宿主控件，不要求 Java 运行 |
| K01 | 动态 subtree、回执、资源、scene replacement、Connection binding、style/cursor | 拒绝不发布虚假身份；FIFO、重入、panic、释放有 Rust 契约；Tree/Grid/连接消费 |
| K02 | Grid/Flow/Toolbar、tree、border、measurement hints、坐标与 damage | Rust 验证 hints、span/grab、size/reset、insets、换行、旧新 damage；不改受保护递归主循环 |
| K03 | owner-aware Locator 与官方 visibility 路由扩展 | ConnectionAndAnchor/UML 的 child measurement 与四象限；Obstruction 的路径/障碍/配对生命周期 |
| K04 | Draw2D Figure 组件的 ScrollBar 五 children、range、repeat、取消 | Zoom/Path/ScrollPane 的可替换 Figure 组件和共享 range；SWT Scale/Text/Combo 不纳入 |
| K05 | styled/nested flow、fragment、block 方向、FlowBorder、真实 inline Figure | 六个 text 入口和 Path/UML 的结构、baseline、几何、mutation、hit/selection 与绘制 |
| K06 | Directed/Compound 算法、tree contour 与 presentation 动画 | Rust fixture 输入、算法不变量、geometry 输出及 Figure 投影；不复制 Java 静态状态或反射菜单 |
| K07 | live snapshot、range/source/view、背景输入与资源 epoch | Thumbnail 实时比例投影、Bidi shared range、透明 Canvas 背景输入、释放和失效 |
| K08 | Graphics/IR/backend 的 AA、hairline、低 miter、dash/alpha、SVG、文字装饰 | Canvas 表达能力或明确受检错误；结构化拒绝不等于功能完成，缺能力仍要推进实现 |
| K09 | PrintExample 的 Canvas Figure 树与通用图形输出消费 | 图文、连接、资源和 transform/clip 可输出；Printer/Dialog/job 不属于本计划 |
| H01 | LightweightSystem 宿主适配 | Canvas resize、DPI/font、平台输入、focus、surface/窗口生命周期；不建设原生控件库 |
| H02 | backend 栅格、资源及合成 | Render IR 完整消费、surface repair、背景/alpha、失效和 late completion |
| H03 | 原真实打印平台任务 | 从本计划退出；未来有独立产品需求再规划 |
| H04 | Canvas 结构、行为、资源与视觉验收 | 逐入口记录通过范围，不以测试数代替全部 Canvas 功能完成 |

## 历次实施与验收范围

以下保留各批次当时的推进记录。当前能力以本页开头和 P2 backlog 为准；
后续实施已替代早期的“待 K05／K06／K07／K08”描述。

K01 已完成多个通用切片并接入 Tree、Grid 与 ConnectionAndAnchor，仍有后续消费者
依赖 K03/K05/K06。K02 已修复 Grid span/grab、最小测量和整数居中；
当前 Flow/Toolbar 的 hint 传递、二次测量、整数收缩、overflow 对齐与 Grid hints
已修复，正在改用独立 Rust 契约验证。K02 未完成，真实文字换行、size/reset、
owner border 和复杂布局边界继续推进。
K03 首批修复普通 Locator child 使用旧 bounds 尺寸的问题，改为统一受检 preferred
measurement；非法测量报告 ChildMeasurementFailed，拒绝路由发布并可恢复，
外部 Figure 与内置图元共用路径。2026-10-21 已按
[owner 标签定位](../../design/architecture/connection-owner-locator.md)接入 owner quadrant、
child-size 输入与开放 child bounds placement，官方 UML 使用 ConnectionEndpointLocator，
既有 EndpointLocator 切线偏移保持不变。Obstruction 已按
[ADR-040](../../adr/adr-040-group-route-solving.md)实现组求解与 visibility/shared corner，
完成外部消费者、真实输入和 Native 四阶段截图；workspace 最终门禁通过。
K03 的其他示例验收继续保留。

2026-10-21 补齐 Locator child 测量失效：此前只修改 preferred size 时，端点几何
不变，路由不会重新提交，导致连接标签停留在旧尺寸。现在绑定追踪普通 child 的
layout generation，尺寸覆盖、重置与文字测量变化会触发同一受检路由批次；
提交后确认新 generation，避免定位本身导致反复路由。Decoration 通过已有 capability
识别，其边界来自 route orientation，不参与 preferred 测量失效。
Rust 契约覆盖尺寸变化、重置、不变值、测量失败后的自动恢复与失败稳定；
UMLClassDiagram 覆盖只修改连接文字且类和路由不动时的重新测量与居中。

2026-10-21 K04 的通用 ScrollBar 按
[ScrollBar 设计](../../design/architecture/scrollbar-and-figure-activity.md)接入 Zoom 和 ScrollPane。
五个普通 Figure 部件、custom thumb minimum、RangeModel 替换、横纵布局、
250ms/40ms 连发与取消通过外部 Rust 契约；Zoom 原公式及 Native 截图通过。
Path/MultiLineLabel 的消费者待 K05/K08，不关闭 K04 整批。

K05 已按用户批准的
[ADR-042](../../adr/adr-042-structured-flow-layout.md)进入实施。
styled 引擎、原子 preparation、开放贡献 registry、结构化 flow 快照、
真实 inline Figure 与 fragment border 已有独立契约测试。
普通 page/block Border、公开 flow 服务与独立替代文字引擎已补齐。
反馈失败闭环、完整边框度量与六个 text 入口已补齐。
六个 Native 截图已检查；示例测试覆盖来源更新、光标命中、焦点键盘滚动、
共享范围与窄窗口真实 Figure 混排。下一步按依赖推进 K06、K07/K08；
K00/H04 随每批维护。
每个入口有 [Canvas 收口清单](../../../crates/novadraw/examples/native/draw2d-official-examples/completion-contracts.tsv)，
只登记 Canvas 内的结构、行为和失败/资源需求。

2026-10-22 Path 从 blocked 转为 in_progress：ScrollBar 与缩放使用已有 Core
组件，旋转闭合路径、两次文字绘制、UTF-8 selection clip 和蓝色下划线接入
普通 FigurePreparation。BorderLayout 修复显式 Center 被不存在的边带挤占；
保留既有无约束布局的兼容路径。Rust 验证中心区、旋转几何、两次文字/选字
绘制与真实按钮缩放，Native 检查最小/最大截图。SchemeBorder 与字体指标驱动
的下划线仍待 K08，当前静态示例装饰不代表通用文字装饰 API 已完成。

2026-10-22 K06 的 Directed/Compound 图布局部分已按
[ADR-043](../../adr/adr-043-directed-compound-graph-layout.md)与
[preparation 增量](../../design/architecture/graph-projection-preparation.md)接入 Core。
默认与外部算法共用独立请求、typed registry 和统一 Figure/Connection adapter；
候选测量、快照身份与整组发布通过外部契约。两个官方图入口的 52 个方向组合、
真实菜单切换、字体资源及 Native 四幅代表性截图已验收，入口标为 complete。
证据见 [实施记录](../evidence/adr043/implementation.md)。
K06 的 tree contour 与 presentation 动画保留原状态；K07/K08 继续按依赖推进。

2026-10-23 继续补充官方样例：ConnectionAndAnchor 接入已有 owner-aware Locator
并使用真实标题测量；Tree 的 PageNode 增加选中渐变及选择恢复验证；PrintExample
加入 Canvas 图文、Button、连接和原始 ICO。Core SchemeBorder 与字体下划线指标
按[增量契约](../../design/architecture/official-example-border-output-increment.md)实施，
Path/Zoom 消费同一普通 Border；Path 去掉固定像素下划线，Zoom 加载原始 SVG。
K07、K06 动画和 K08 AA/动态 SVG 重栅格化继续保留，混合字体装饰尚未提供。
本批收口 ConnectionAndAnchor、Path、SimpleTree，当前 14/25 complete、22/25 可运行；
Print 的字体替代仍明确保留。图像和验证见
[交付证据](../evidence/official-examples-2026-10-23/implementation.md)。

2026-10-23 后续工作见
[剩余清单](draw2d-official-examples-next-slices-2026-10-23.md)。
K02 的 Grid Native 入口已接入逻辑视口 resize，跨列 grab/fill 的缩小、放大和恢复
有真实 Shape 回归；Toolbar 的方向/stretch/收缩/恢复也有 geometry 验证。
ScrollPane 的 ScrollBar 五部件能力已实现，剩余项修订为主题与完整视觉验收。
三个布局入口仍保留 in_progress。K07 的
[共享视图与背景设计](../../design/architecture/shared-scene-view-background-proposal.md)
已形成待评审草案，尚未进入实现。

2026-10-26 K06 的 Tree 表现几何按 ADR-046 落地：普通 Viewport、默认关闭的
Use Animation、真实 bounds 收拢、Normal/Hanging 同源线条、当前采样反向与输入接管。
`animation.tree` 已通过 Core/Viewport/Tree 契约及 Native GPU retained-partial 像素验证；
中间帧和最终清理帧明确断言 Partial。TreeExample 在目录中改为 complete，当前
17/25 complete；完整门禁和 surface present 限制见
[实施复核](../reviews/tree-layout-presentation-implementation-2026-10-26.md)。
该结果不关闭 AA、混合字体装饰或其余未完成入口。

## 全计划完成判定

25 个入口都具备独立 Canvas 实现；Canvas 功能清单没有未移植或阻塞项；
Figure composition、算法、输入、测量、绘制、资源和退出有 Rust 验证或场景证据。
原生控制面板是否等同 SWT 不影响 Canvas 完成判定。声明支持的平台只按实际验证
范围报告，不把尚未验证的平台标为通过。

完整源码需求见 [全入口矩阵](draw2d-official-examples-remaining-contracts.md)。
矩阵中的 SWT 描述只说明上游环境，不自动构成本项目建设任务；与本计划冲突时，
以用户最新 Canvas 范围及本计划为准。
