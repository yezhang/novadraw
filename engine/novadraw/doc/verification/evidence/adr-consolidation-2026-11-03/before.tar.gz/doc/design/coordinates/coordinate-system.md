# Novadraw 坐标与变换契约

类型：`normative-design`

本文是 Novadraw 二维坐标、变换、命中和 damage 投影的 SSOT。Draw2D 的参考事实见
`doc/reference/draw2d/figure/tree-coordinates.md`。

## 1. 设计选择

Novadraw 保留 Draw2D 的核心行为：

- 坐标转换沿 Figure 父链组合；
- parent/child 转换必须双向；
- insets、scroll 和 scale 都是坐标协议的一部分；
- paint、hit-test、事件点和 damage 使用同一转换来源。

Novadraw 不复制 Draw2D 的物理存储方式。所有节点统一采用：

> `bounds` 存储在 parent content domain 中，节点自身在 local border-box domain 中绘制。

因此移动 parent 不改写后代 bounds，只使后代的 world transform 和 projected bounds
失效。

## 2. 坐标域

### 2.1 Physical Surface Domain

窗口表面或 canvas backing store 的物理像素。只允许出现在 PlatformHost 和
RenderBackend 边界。

### 2.2 Logical Surface Domain

设备无关的根逻辑坐标，也是平台输入进入 Runtime 后的 entry domain：

```text
logical = physical / scale_factor
physical = logical * scale_factor
```

### 2.3 Parent Content Domain

节点的 `bounds` 所属坐标域。原点是 parent client area 的左上角，并包含 parent 为
children 声明的 scroll、scale 或其他二维 child transform。

### 2.4 Node Local Domain

节点自身绘制和精确命中的坐标域：

```text
local border box = Rect(0, 0, bounds.width, bounds.height)
local client box = local border box inset by insets
```

Figure 不需要知道自己在父树中的绝对位置。

### 2.5 Child Content Domain

children bounds 所属域。它由当前节点的 client origin 和 `child_transform` 定义。
普通容器的 child transform 是 identity；Viewport、ScalablePane 等容器可以提供
scroll 或 scale。

## 3. 边变换

对节点 `N`，定义：

```text
node_local_to_parent_content(N)
    = Translate(N.bounds.origin) * N.local_transform

child_content_to_node_local(N)
    = Translate(N.insets.left, N.insets.top) * N.child_transform
```

完整的 child 到 parent 映射为：

```text
child_local
→ child node placement
→ parent child-content transform
→ parent local
→ parent placement
```

实现可以缓存组合矩阵，但所有消费者必须从同一 edge-transform 协议取得结果。

矩阵使用列向量语义。向已有 parent/world 变换追加 local 变换时必须执行：

```text
world = parent_world * local
```

对应 API 为 `parent_world.post_concat(local)`。不得使用
`local * parent_world`，否则父层 scale/rotation 会与子节点 placement 以错误顺序组合。

## 4. Affine2D

二维核心使用显式仿射变换：

```rust
pub struct Affine2D {
    // [a c tx]
    // [b d ty]
    // [0 0  1]
    coefficients: [f64; 6],
}
```

它支持：

- translate；
- scale；
- rotate；
- skew；
- composition；
- inverse；
- point、vector、rect 和 path 变换。

矩阵组合顺序必须由 API 文档定义，不能依赖调用者猜测。建议使用命名：

```text
then_translate
then_scale
pre_concat
post_concat
map_point
```

并通过非交换变换测试锁定语义。

## 5. World Transform

```text
local_to_surface(id)
    = compose every edge transform from id to root

surface_to_local(id)
    = inverse(local_to_surface(id))
```

缓存至少带有 topology/transform generation。以下变化必须使相关缓存失效：

- bounds origin；
- insets；
- child transform；
- ancestor reparent；
- viewport origin；
- scale；
- visual transform 变化。

任意 FigureId 的坐标查询先校验 owner namespace 与 live slot。三个正向入口返回
`Result<Affine2D, CoordinateQueryError>`；两个逆向入口返回
`Result<Option<Affine2D>, CoordinateQueryError>`。`Ok(None)` 仅表示有限输入在数学上
奇异，foreign/unknown/retired ID 返回身份错误。

非有限输入、逆结果不可表示、数值计算失败和正向组合溢出分别保留结构化原因及
失败 FigureId。求逆按 f64 输入系数的精确值判定奇异，不使用固定 epsilon；
行列式中间乘法溢出或下溢不能成为不可逆结论。内部受检计算与公开
`Affine2D::inverse` 的旧 Option getter 分开；本切片不重构公开 geometry API。
完整合同见 [ADR-038](../../adr/adr-038-query-identity-and-failure-semantics.md)。

## 6. Bounds

`NodeState.bounds` 是 parent content domain 中的布局矩形：

- origin 由 parent layout 或显式操作确定；
- size 参与 layout、client area 和默认 hit-test；
- bounds 不是 world-space AABB；
- bounds 不包含 shadow、blur 等视觉外扩；
- bounds 不因 ancestor 移动而被批量改写。

另外定义：

```text
layout_bounds     // parent content domain
local_border_box  // node local domain
visual_bounds     // local effects 后的可见范围
projected_bounds  // logical surface domain 中的保守 AABB
```

这些概念不能共用一个含义模糊的 rectangle。

### 6.1 旧场景导入边界

FigureTree 只接受 parent-local bounds，不提供旧坐标模式或运行时迁移入口。需要读取
旧版“相对最近坐标根的绝对 bounds”数据时，导入器必须先在引擎外完成版本识别和
坐标归一化，再构造 FigureTree。

转换必须使用旧数据版本明确声明的坐标根，不能根据场景内容推断。迁移后的节点只
保存 parent-local bounds，后续 paint、hit-test、event 和 damage 均走统一
Affine2D 链。

## 7. Client Area 与 Insets

```text
client_box = Rect(0, 0, width, height).inset(insets)
```

client box 同时用于：

- LayoutManager 的默认可用区域；
- children paint 的默认 clip；
- hit-test 是否继续下降到 children；
- scroll/viewport 的可视范围。

上述用途存在两个明确坐标表示：

- node-local client box 保留 `(left, top)` 原点，供 paint、clip 与 hit-test 使用；
- `LayoutSceneQuery::container_bounds` 返回 child-content 域的可用区
  `Rect(0, 0, layout_width, layout_height)`。先从当前 bounds 扣除物理 insets，
  再经过容器的 `layout_constraints` 转为布局域，与子节点测量共用同一协议。
  普通容器尺寸等于 client 尺寸；均匀缩放容器尺寸等于 client 尺寸除以 scale。

parent 的 `child_transform` 负责把 child-content 原点映射到 node-local client box，
因此 inset 只能在该变换中应用一次，不能再写入 child bounds。Viewport 的滚动原点与
Scalable Figure 的 scale 仍由各自 child transform 和专用布局协议处理，不改变
`container_bounds` 的零原点契约。

自定义 child clipping policy 可以放宽默认裁剪，但必须同时定义 paint 和 hit-test
行为，不能只修改其中一条路径。

Freeform 容器使用 `ChildClippingStrategy::OverflowVisible`：

- 继承进入容器的 effective ancestor clip；
- 不再与当前容器的 client box 相交；
- parent 到该 child 的 paint edge 不再追加 child presentation bounds clip；
- paint children、hit-test descent 和 damage projection 共用该 effective clip；
- 最近的普通 clipping ancestor 或 Viewport 仍可截断内容。

该策略只改变 child overflow，不使当前 Figure 自身越过 ancestor clip，也不允许
命中不可逆 transform 分支。

## 8. Paint

每个节点的绘制按以下顺序应用坐标：

```text
push
→ concat node_local_to_parent
→ paint Figure in local coordinates
→ clip local client box
→ concat child_content_to_node_local
→ paint children
→ restore child state
→ paint border/foreground
→ pop
```

Figure 自身只使用 local coordinates。具体后端可以把 `Affine2D` 转换为 `Mat3`、
`Mat4` 或后端原生 affine。

## 9. Hit-test

从 logical surface point 开始：

```text
root
→ inverse edge transform into node local
→ visible / policy-aware branch containment
→ inverse child-content transform
→ children in reverse Z-order
→ self participation / local hit-shape
→ deepest eligible target
```

规则：

- invisible 节点及其默认可见子树不参与；
- disabled 节点不能成为默认输入 target，但其可见 children 可按容器策略继续搜索；
- Figure 精确 hit-test 接收 node local point；
- 不可逆 transform 的分支不可命中；
- event callback 接收 target local point，并保留原始 logical surface point。

## 10. 几何变更与 Damage

`set_bounds` 必须原子处理：

```text
old_projected_visual_bounds
→ change bounds once
→ invalidate transform cache
→ new_projected_visual_bounds
→ damage union(old, new)
→ one geometry notification
```

resize 还会使自身或 parent layout 失效。移动不能产生额外的 resize/move 重复通知。

局部 dirty region 的传播：

```text
local dirty
→ expand by stroke/filter/effect
→ map through local-to-surface
→ intersect effective ancestor clips
→ conservative logical-surface AABB
```

旋转或投影后的矩形必须取保守 AABB，不能只变换左上和右下两个点。

## 11. Viewport、Scroll 与 Scale

Viewport 的状态：

```text
viewport local client box
origin: content coordinate visible at viewport top-left
scale: owned by scalable content/pane
```

典型映射：

```text
viewport_point = (content_point - origin) * scale
content_point = viewport_point / scale + origin
```

该映射实现为 child transform，不在 hit-test、event 或 damage 中建立专用全局捷径。

RangeModel 是 scroll origin 的唯一真源；ScalablePane 是 scale 的唯一真源。
ZoomManager 只协调二者，不建立第二份状态。

## 12. DPI

Runtime、Figure、LayoutManager 和 InputEvent 统一使用 logical units。只有两个边界处理
physical pixels：

- PlatformInputAdapter：physical input 到 logical input；
- RenderBackend：logical submission 到 physical surface。

scale factor 变化必须作为 surface transaction 处理，不能在不同事件路径中各自换算。

## 13. 2.5D Projective Composition

2.5D 是二维 layout 之后的视觉合成：

```text
2D local geometry
→ Affine2D world transform
→ Projective3D visual transform
→ surface projection
```

它不改变二维 layout bounds。每个 projective effect 必须声明：

- projected visual bounds 的计算；
- clip 是投影前还是投影后；
- hit-test 是否支持从 screen point 逆投影；
- 矩阵不可逆或 `w <= 0` 时的处理；
- backend 不支持时的 fallback。

仅需视觉效果时，默认可将 hit-test 保持在二维布局几何上；若产品要求“看到哪里点到
哪里”，则 capability 必须提供投影命中。

## 14. 真正 3D

真正 3D 不复用二维 `Point/Rect/LayoutManager`：

```text
Scene3D
├── Vec3 / Transform3D
├── Bounds3D
├── Camera / Projection
├── RayHitTest
├── FrustumCulling
└── Depth / Material / Lighting
```

Scene3D 可通过以下方式接入：

- 3D viewport Figure；
- 离屏 texture；
- 独立 render layer；
- 与二维 overlay 的显式坐标桥。

这让新增 3D 数学和渲染能力不要求修改所有二维 Figure、布局和事件 API。

## 15. 数值与失败规则

- 几何输入必须有限；
- size 不得为负；
- inverse 失败必须显式返回；
- scale factor 必须有限且大于零；
- 极大坐标的裁剪和 AABB 计算不得溢出；
- 浮点比较使用领域容差，不把容差写成散落的 magic number；
- projective transform 的 near-plane 和 `w` 规则由合成协议统一定义。

## 宿主背景使用帧内位置

`host::BackgroundFrameInput` 由 Host 显式提供 surface、`surface/position/dpi`
独立版本和 `host_to_canvas` 仿射变换。背景 coverage 与 drawing 使用宿主逻辑坐标；
Runtime 先裁剪到 Canvas surface，再应用 `host_to_canvas` 和宿主 coverage，
随后在同一帧绘制 Canvas。此变换不乘 Canvas 内容 Viewport 的 origin 或 scale。

Host 移动 Canvas 时提升 position 版本并重新提供背景候选；
滚动 Figure 内容只改变 Figure 坐标，不改变背景输入。surface extent 或 DPI
改变必须提升相应版本。旧候选输入与当前输入或帧 surface 不匹配时，
`prepare_submission` 返回 `HostBackground(InputMismatch)`，保留 pending work。
输入版本不允许倒退，变换必须通过现有受检 inverse；帧录制继续进行设备数值检查。
`RenderSubmission::background_input` 是该帧冻结的输入记录，后端不得补算新位置。

## 16. 验证契约

至少覆盖：

1. 多层 translation/scale/rotation 的往返；
2. bounds 始终保持 parent-local；
3. parent 移动不改写 descendants bounds；
4. paint、hit-test、event point 和 damage 使用同一变换；
5. insets 同时影响 layout、clip 和 child descent；
6. viewport/scale 嵌套；
7. 不可逆 transform；
8. old/new projected damage；
9. DPI 改变；
10. projective effect 的 bounds、clip 和可选命中；
11. 10,000 层边界下的明确行为。
