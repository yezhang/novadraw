# 产品交付清单

类型：`roadmap`

> 本文档承载每个 draw2d 核心 milestone 下要交付的**产品策略层清单**（具体图元数、布局数、边框数等）。
>
> **编号约定**：本文统一使用 `M1-M10`，并与 `doc/parity/draw2d/api-coverage.md` 中的 milestone 映射保持一致。
> **完成判据**：API 语义覆盖（`doc/parity/draw2d/api-coverage.md`）+ 产品层清单（本文）+ Demo 验证（`demo-matrix.md`）三者齐过。

M1-M10 已完成，本文保留其交付范围，不是当前待办队列。Draw2D 风格名称表示行为
对照，不保证同名 Rust 签名；当前公开路径以公共 API 契约与 API snapshot 为准。
后续工作与状态见 [P2 backlog](p2-delta-backlog.md)。测试数量不作为交付目标。

## 与 milestone 的挂接关系

| Milestone | 标题（协议层） | 本文章节 | 产品策略要点 |
|------|----------------|----------|--------------|
| M1 | 几何与 Graphics 基础 | [§M1](#m1-几何与-graphics-基础) | 几何类型 + Graphics 状态栈 |
| M2 | Figure 树与盒模型 | [§M2](#m2-figure-树与盒模型) | active core Figure + 三段式 paint |
| M3 | 绘制遍历与裁剪闭环 | [§M3](#m3-绘制遍历与裁剪闭环) | 嵌套裁剪 + paint/hit-test 一致性 |
| M4 | 坐标域与变换闭环 | [§M4](#m4-坐标域与变换闭环) | translate* 协议 + 入口域降域 |
| M5 | Layout + Validation + UpdateManager | [§M5](#m5-layout--validation--updatemanager) | 6 布局 + 两阶段事务 |
| M6 | 事件分发与交互状态机 | [§M6](#m6-事件分发与交互状态机) | 输入状态机 + 端口 |
| M7 | 通知语义分层 | [§M7](#m7-通知语义分层) | 七类 listener + UpdateListener |
| M8 | Viewport / Scroll / Zoom | [§M8](#m8-viewport--scroll--zoom) | ScrollPane + RangeModel |
| M9 | Connection / Anchor / Router | [§M9](#m9-connection--anchor--router) | 连线 + 5 anchor + 3 router |
| M10 | 常用 Figure 与文本/控件 | [§M10](#m10-常用-figure-与文本控件) | 6 边框 + 文本 + Tooltip + Accessible 基础 |

---

## M1 几何与 Graphics 基础

**协议层要求**：见 `doc/parity/draw2d/api-coverage.md` 中 M1 相关 family。本文只列产品层清单。

### 几何类型清单

- `Point`
- `Vec2`
- `Rectangle`
- `Dimension`
- `Insets`
- `PointList`
- `Affine2D`
- `Precision`

### Graphics API 清单

- 状态栈：`pushState` / `popState` / `restoreState`
- 变换：`translate` / `scale` / `rotate`
- 裁剪：`clipRect` / `setClip`
- 填充/描边：`fillRectangle` / `drawRectangle` / `fillOval` / `drawOval` / `fillPolygon` / `drawPolygon` / `fillPath` / `drawPath`
- 文本：`drawText` / `drawString`
- 图像：`drawImage`
- 属性：`setForegroundColor` / `setBackgroundColor` / `setLineWidth` / `setLineStyle` / `setAlpha`

---

## M2 Figure 树与盒模型

**协议层要求**：见 `doc/parity/draw2d/api-coverage.md` 中 M2 相关 family（A1/A2/A3/A5）。本节只列产品层清单。

### Active core Figure

- `RootFigure`
- `RectangleFigure`
- 测试 mock Figure

M2 只以 active surface 验证通用 Figure 机制。`EllipseFigure`、
`RoundedRectangleFigure`、`PolylineFigure`、`PolygonFigure` 和
`TriangleFigure` 的 reusable surface 验收归入 M10。

### 三段式 paint 协议

- `paint_figure` / `paint_client_area` / `paint_border`
- 顺序：`paintFigure → paintClientArea(含子) → paintBorder`

### Figure / FigureNode / FigureTree 角色

- `Figure` trait：具体图形的绘制、内在尺寸、精确命中和可选能力
- `FigureNode`：组合 `NodeState`、`LayoutState` 与 `Box<dyn Figure>`
- `FigureTree`：通过 `SlotMap<FigureId, FigureNode>` 维护拓扑和 Z-order
- `InteractionState`：独立维护 pointer、capture、hover、focus 和 gesture session

---

## M3 绘制遍历与裁剪闭环

**协议层要求**：见 `doc/parity/draw2d/api-coverage.md` 中 M3 相关 family。本节只列产品层清单。

### 渲染主循环

- `render_recursive.rs`（递归实现）
- 迭代渲染历史 POC 已归档到 git tag `archive/render-iterative-poc-20260617`
- 当前阶段不交付 I 键运行时切换或递归/迭代等价门禁

### 裁剪策略

- 父 `clientArea` 裁剪
- 子 `bounds` 裁剪
- `optimizeClip` 优化路径

---

## M4 坐标域与变换闭环

**协议层要求**：见 `doc/parity/draw2d/api-coverage.md` 中 M4 相关 family（A4）。本节只列产品层清单。

### 协议 API

- `useLocalCoordinates` / `isCoordinateSystem`
- `translateToParent` / `translateFromParent`
- `translateToAbsolute` / `translateToRelative`
- `SceneDispatchContext`（入口域 → target/source 域降域）

---

## M5 Layout + Validation + UpdateManager

**协议层要求**：见 `doc/parity/draw2d/api-coverage.md` 中 M5 相关 family（A6/A7/A8）。本节只列产品层清单。

### LayoutManager 实现（6 个）

| 布局 | g2 对应 | 用途 |
|------|---------|------|
| `FlowLayout` | `FlowLayout` | 水平/垂直流式排列（验证基线） |
| `BorderLayout` | `BorderLayout` | 5 区（N/S/E/W/Center） |
| `GridLayout` | `GridLayout` | 网格 |
| `ToolbarLayout` | `ToolbarLayout` | 工具栏单行/单列 |
| `XYLayout` | `XYLayout` | 显式坐标布局 |
| `StackLayout` | `StackLayout` | 层叠（占满父） |

### 约束系统

- `LayoutConstraint` trait
- Builder detached 配置与 mounted FigureMut 的受检约束修改
- 原子 indexed + constraint child add 为已完成 P2-S01，不扩写 M5 原始范围

### UpdateManager 能力

- 区域失效 / clip 失效 / 整图失效
- repaint coalescing
- damage repair 全图元覆盖
- 1k+ Figure stress

---

## M6 事件分发与交互状态机

**协议层要求**：见 `doc/parity/draw2d/api-coverage.md` 中 M6 相关 family（A9）。本节只列产品层清单。

### 输入分发状态

- `mouseTarget` / `cursorTarget` / `hoverSource` / `focusOwner` / `capture`

### 事件端口

- `MouseListener` / `MouseMotionListener` / `MouseWheelListener`
- `KeyListener` / `FocusListener`
- hit-test 全图元覆盖（含 Ellipse 精确命中）

---

## M7 通知语义分层

**协议层要求**：见 `doc/parity/draw2d/api-coverage.md` 中 M7 相关 family。本节只列产品层清单。

### 七类 listener（不允许压扁成单一总线）

1. `FigureListener` —— 几何变化（`figureMoved`）
2. `CoordinateListener` —— 坐标域变化（`coordinateSystemChanged`）
3. `PropertyChangeListener` —— 通用属性变化
4. `AncestorListener` —— 祖先链变化
5. `LayoutListener` —— 布局生命周期 hook
6. Input listeners —— 输入分发末端 hook（与 M6 共享）
7. `ActionListener` —— button-like action 发生事实（由 M10.4 提供首个产品消费者）

### UpdateListener（挂 UpdateManager，不挂 Figure）

- `notifyValidating()`
- `notifyPainting(damage, dirty_regions)`

---

## M8 Viewport / Scroll / Zoom

**协议层要求**：见 `doc/parity/draw2d/api-coverage.md` 中 M8 相关 family。本节只列产品层清单。

### Viewport 体系

- `Viewport` Figure（坐标系节点）
- `ScrollPane` 容器
- `RangeModel` 抽象
- `ScrollBar` 模型（H+V）：单次 press step、track page、thumb drag；按住 repeat
  firing 随 P2 widget scheduler 延后
- 鼠标滚轮

### Scalable 能力

- 标准 Scale capability 与 scale model；通过统一 registry/query/mutation 接入
- `ScalableLayeredPane`
- Zoom transform 集成

### 收口要求

- M8 已完成；新 viewport 缺口登记独立 P2 delta，不重开 M2/M8。
- Draw2D 的 Viewport/ScrollPane 属于 M8；GEF 的 `AutoexposeHelper` 依赖
  EditPart/Tool 拖拽生命周期，不进入 draw2d 核心 M8。

---

## M9 Connection / Anchor / Router

**协议层要求**：见 `doc/parity/draw2d/api-coverage.md` 中 M9 相关 family。本节只列产品层清单。

### Connection 图形

- `Connection`
- `PolylineConnection`

### Anchor 实现（5 个）

| Anchor | g2 对应 |
|--------|---------|
| `ChopboxAnchor` | `ChopboxAnchor` |
| `EllipseAnchor` | `EllipseAnchor` |
| `RoundedRectangleAnchor` | `RoundedRectangleAnchor` |
| `LabelAnchor` | `LabelAnchor` |
| `XYAnchor` | `XYAnchor` |

### Router 实现（3 个，简化版）

| Router | g2 对应 | 说明 |
|--------|---------|------|
| `BendpointConnectionRouter` | `BendpointConnectionRouter` | 用户折点 |
| `ManhattanConnectionRouter` | `ManhattanConnectionRouter` | 直角路由 |
| `FanRouter` | `FanRouter` | 多线分散 |

`ShortestPathConnectionRouter` 已作为 Core 1.0 之后的 P2-C02 delta 完成，不改写
M9 原始“三种 Router”交付范围。实现与验证状态见
[`p2-delta-backlog.md`](p2-delta-backlog.md#p2-c02-障碍感知-shortest-path-router)。

### 装饰与层

- Decorations（箭头等）
- `ConnectionLayer`

---

## M10 常用 Figure 与文本/控件

**协议层要求**：见 `doc/parity/draw2d/api-coverage.md` 中 M10 相关 family。本节只列产品层清单。

M10.1 不重新设计 M1 Graphics 基础契约。状态栈、坐标、裁剪和现有基础绘制命令保持
冻结；本批次只收口 reusable Shape 与 Border 产品面。只有现有 path/command 无法
正确表达具体 Figure 时，才允许增加经契约证明所需的最小 Graphics primitive。

### Reusable Figure surface

- `RectangleFigure` 作为 active baseline 复查
- `EllipseFigure`
- `RoundedRectangleFigure`
- `PolylineFigure`
- `PolygonFigure`
- `TriangleFigure`

这些 Figure 的 paint、hit-test、border、style 和更新协议属于已验收的 M10 基线；
类型数量与导出本身不替代行为证据。

### Border 实现（M10 共 6 个）

| Border | g2 对应 | 交付阶段 |
|--------|---------|---------|
| `LineBorder` | `LineBorder` | M10.1 |
| `MarginBorder` | `MarginBorder` | M10.1 |
| `CompoundBorder` | `CompoundBorder` | M10.1 |
| `EtchedBorder` | `EtchedBorder` | M10.1 |
| `BevelBorder` | `BevelBorder` | M10.1 |
| `TitleBarBorder` | `TitleBarBorder` | M10.2 |

`TitleBarBorder` 仍属于 M10 产品范围，但因 insets、preferred size 和 paint 均依赖
字体测量，随 M10.2 文本与 Label 一并交付，不进入 M10.1。

Focus 类边框属于后续能力候选，需证明组合价值后登记，不追加为 M10 未完成项。

### 文本 + 图像

- `Label`（Parley 默认布局引擎 + backend-neutral Glyph IR，见 ADR-007）
- 文本布局 + 截断 + align
- `ImageFigure`
- 字体管理
- 文本与边框布局交互

### 控件类 Figure

- Button-like / Toggle-like

### Tooltip + Accessibility 基础

- Runtime-owned Tooltip（悬停延迟、show/replace/hide、超时与边界 placement）
- engine-owned accessibility Snapshot/Delta（name、role、state、bounds、children、focus）
- focus/default action 受控回流；不实现完整 ARIA 或原生 AT provider

---

## 边界声明

### 本文不持有的内容

- API 语义覆盖（在 `doc/parity/draw2d/api-coverage.md`）
- 细粒度验证项（在相关测试与 `demo-matrix.md`）
- Demo 名称与验证策略（在 `demo-matrix.md`）

### 不在 draw2d 核心的能力（明确排除）

以下能力**不挂在 M1-M10 任何 milestone 下**，按当前路线图边界明确排除：

- EditPart / EditPolicy / Tool / Command / Request / Viewer
- Palette / Selection provider
- Undo-redo command stack
- "节点编辑器毕业 demo"（创建/拖拽/连接/删除节点）—— 这是 GEF 层能力，详见 `demo-matrix.md` 附录"GEF 层早期探索"

这些能力已经进入独立 [`doc/roadmap/editor/`](editor/00-index.md)，继续与
Draw2D M1-M10 隔离。
