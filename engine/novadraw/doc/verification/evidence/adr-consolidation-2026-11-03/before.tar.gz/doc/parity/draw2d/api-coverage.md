# Draw2D API 语义覆盖清单

类型：`parity-contract`

本文档记录 draw2d API 到 Novadraw 的语义覆盖关系，用作架构设计、功能迭代和验收补充的覆盖账本。

Draw2D 源码事实基线：eclipse/gef-classic commit `4463d9d0c`（2026-01-01）。
Novadraw 覆盖状态随本仓库演进单独更新。

它不是 Java API 迁移待办，也不是进度管理或任务编排文件。
当前增量及执行顺序见 [P2 backlog](../../roadmap/p2-delta-backlog.md)；
已完成 Core 基线见 [M1–M10](../../roadmap/00-index.md)。

## 使用原则

- 先记录 draw2d 的语义契约，再记录 Novadraw 的合理变体。
- 不按方法名机械照搬；同一组协作 API 可以合并为一个 API family。
- 每个 family 必须能落到验证方式：contract test、probe、demo 或视觉断言。
- P0 family 优先进入 M1-M10 核心契约；P1 作为能力补齐；P2 和 GEF 层只保留对照，不进入当前 draw2d core 主线。

## Figure Surface 分层

为先验证框架核心机制，当前 Figure 能力分为 active surface 与 deferred surface：

| Surface | 当前类型 | 里程碑归属 | 门禁规则 |
|---|---|---|---|
| Core mechanism | `RootFigure`, `RectangleFigure`, 测试 mock Figure | M1-M5 | 通用 Figure 机制和 API 语义必须完整覆盖 |
| Deferred viewport | `ViewportFigure` | M8 | 保留代码与导出，M8 前不计入 M1-M5 完成门禁 |
| Deferred builtin figures | `EllipseFigure`, `RoundedRectangleFigure`, `PolylineFigure`, `PolygonFigure`, `TriangleFigure` | M10 | 保留代码与导出，M10 前不计入 M1-M5 完成门禁 |

这不是删除能力，也不是降低通用机制要求。规则是：当前 milestone 只对 active surface
判定完成；当 deferred Figure 被纳入对应 milestone 时，必须补齐与 active surface
等价的协议覆盖和测试证据，不能只由 `RectangleFigure` 代表。

## 记录模板

```yaml
- family: figure.geometry.bounds
  priority: P0
  draw2d_apis:
    - IFigure#getBounds
    - IFigure#setBounds
    - IFigure#translate
  semantic_contract:
    - bounds 是 Figure 本地坐标域的外框
    - bounds 改变影响 paint、hit-test、layout、dirty region
  novadraw_variant:
    owner: Bounded / FigureTree
    graph_access: FigureId
    difference_reason: Novadraw 使用 ID 引用树；bounds 通过 Bounded trait 访问，FigureNode 只提供只读运行时视图
  coverage:
    status: unknown
    milestone: M2
    probes:
      - bounds_change_repaints_old_and_new_region
      - child_absolute_position_changes_after_parent_move
```

## 覆盖矩阵

| 优先级 | API 家族 | draw2d 代表 API | Novadraw 对照方向 | 覆盖检查点 |
|---|---|---|---|---|
| P0 | Figure 树结构 | `IFigure.add/remove/getChildren/getParent/setParent` | `FigureTree` / `FigureId` 树 | 父子关系、顺序、删除、重挂载、逆序遍历 |
| P0 | Figure 生命周期 | `addNotify/removeNotify` | 节点挂载/卸载 hook | 子树 attach/detach、资源初始化、事件解绑 |
| P0 | Bounds 几何 | `getBounds/setBounds/getLocation/setLocation/getSize/setSize/translate` | `Bounded` / `FigureTree` bounds API | bounds 改变后的 repaint、layout invalidation、子坐标影响 |
| P0 | ClientArea / Insets | `getClientArea/getInsets` | border-inset 后的内容区 | paint clip、layout area、hit-test descent 共用同一 inset 逻辑 |
| P0 | Paint 主协议 | `paint(Graphics)` | `runtime.frames().prepare_submission` / 内部递归 traversal + `Figure::paint(PaintContext, bounds)` | 背景、border、client area、children paint 顺序与绘制失败传播 |
| P0 | Graphics 绘制上下文 | `Graphics.draw*/fill*/clip*/translate/pushState/popState` | `Graphics` / `PaintContext` / Vello backend | 状态栈、clip、坐标平移、线宽、颜色、文本、路径 |
| P0 | 坐标转换 | `translateToAbsolute/Relative/Parent/FromParent` | graph 坐标域转换 API | parent/local/root 坐标互转、嵌套偏移、clip 下命中 |
| P0 | Hit-test | `containsPoint/findFigureAt/findMouseEventTargetAt` | hit-test traversal | 可见性、启用状态、逆 child 顺序、client area、event target |
| P0 | 可见性 / 启用 | `isVisible/setVisible/isShowing/isEnabled/setEnabled` | Figure 状态位 | hidden 不绘制、不命中；disabled 事件策略 |
| P0 | Border | `Border.getInsets/paint/isOpaque/getPreferredSize` | `Border` trait / border registry | inset 影响 client area；border 绘制顺序；opaque 背景语义 |
| P0 | LayoutManager | `layout/getPreferredSize/getMinimumSize/setConstraint/invalidate` | `LayoutManager` trait | layout area、child constraint、preferred/min size、缓存失效 |
| P0 | Validation | `invalidate/invalidateTree/revalidate/validate` | update/validation pipeline | 自下而上失效、自上而下 validate、重复失效合并 |
| P0 | Damage / Repaint | `repaint/intersects/getUpdateManager` | dirty region / render invalidation | dirty region 合并、局部重绘、bounds 外裁剪 |
| P0 | UpdateManager | `addInvalidFigure/addDirtyRegion/performValidation/performUpdate` | 两阶段更新调度 | Validation -> Damage Repair 顺序、批处理、root update |
| P1 | Figure 属性 | `foreground/background/font/cursor/tooltip/opaque` | style/state storage | 本地属性、继承属性、opaque 背景、tooltip 查询 |
| P1 | 监听器系统 | `FigureListener/AncestorListener/CoordinateListener/LayoutListener/PropertyChangeListener/ActionListener` | event/listener hooks | bounds 变化、ancestor 变化、layout 生命周期、属性变更、控件 action |
| P1 | 输入事件 | `MouseListener/MouseMotionListener/MouseWheelListener/KeyListener/FocusListener` | engine event dispatch | target/source 点转换、capture、hover、drag、wheel、key |
| P1 | EventDispatcher | `SWTEventDispatcher/EventDispatcher` | 平台输入适配 + 引擎分发 | apps 只适配平台事件，引擎负责命中和派发 |
| P1 | Focus | `requestFocus/hasFocus/isFocusTraversable` | focus manager | focus owner、tab traversal、focus gained/lost |
| P1 | ClippingStrategy | `getClippingStrategy/setClippingStrategy` | child clip policy | 子节点是否被 parent/client area 裁剪，可替换策略 |
| P1 | 基础 Figure 类型 | `Figure/Label/ImageFigure/RectangleFigure/Ellipse` | builtin figures | 基础图元、文本、图片、容器 figure |
| P1 | SWT 宿主控件 | `FigureCanvas/LightweightSystem` | app/host integration | `FigureCanvas` 是承载 Draw2D 的 SWT Canvas，不是 Figure 子类 |
| P1 | 几何 Primitive | `Rectangle/Point/Dimension/Insets/PointList/Precision*` | `novadraw::geometry` | 整数/浮点策略、包含/相交/扩张/平移 |
| P1 | 具体布局 | `XYLayout/StackLayout/BorderLayout/GridLayout/FlowLayout/ToolbarLayout` | layout implementations | 绝对布局、栈布局、边界布局、网格、流式、工具栏 |
| P1 | Freeform / Layer | `Layer/FreeformLayer/FreeformLayout/FreeformViewport` | 大画布/自由坐标层 | 负坐标、内容范围、root/layer 分层 |
| P1 | Viewport / Scroll | `Viewport/ScrollPane/ScrollBar/RangeModel` | 视口组件，当前可延后 | viewport clip、scroll offset、content extent |
| P1 | Connection | `Connection/PolylineConnection` | edge figure / connection figure | source/target、point list、重路由、连接子 figure |
| P1 | Anchor | `ConnectionAnchor/ChopboxAnchor/EllipseAnchor/XYAnchor` | anchor trait | owner bounds 变化触发连接重算、参考点计算 |
| P1 | Router | `ConnectionRouter/Manhattan/Bendpoint/ShortestPath` | router trait | route 输入输出、constraint、invalidate/remove |
| P1 | Locator | `Locator/ConnectionLocator/EndpointLocator/MidpointLocator` | decoration/label placement | 在线段、端点、相对 bounds 上定位 child |
| P1 | Widget 辅助 | `Button/Clickable/Toggle` | 基础交互 Figure | action、selected、pressed、rollover、focus |
| P1 | Accessibility bridge | `Accessible/AccessibilityDispatcher` | engine snapshot + platform bridge | name、role、state、bounds、children、focus、action |
| P2 | 文本 Flow | `FlowFigure/TextFlow/ParagraphTextLayout` | 富文本/段落布局 | inline/block flow、换行、文本测量 |
| P2 | 完整 Widget Toolkit | `ButtonGroup/CheckBox/RadioButton/Slider`、repeat firing | 可选控件库 | 不污染核心 draw2d 协议 |
| P2 | 图布局 | `DirectedGraphLayout/CompoundDirectedGraphLayout` | 后续自动布局能力 | DAG/复合图布局，可作为独立算法模块 |
| P2 | 打印 / 缩放 Graphics | `PrinterGraphics/ScaledGraphics` | backend adapter | 缩放代理、打印目标、非主线渲染后端 |
| P2 | 动画 / 表现过渡 | `Animation/Animator/LayoutAnimator/RoutingAnimator` | Runtime-owned Timeline/Track + Presentation Plane | 可选时钟、before/after snapshot、布局/路由/属性/持续效果 |
| GEF 层 | Viewer 映射 | `EditPartViewer.findObjectAt` | 编辑器层，不进 draw2d core | Figure 到 app object / EditPart 映射 |
| GEF 层 | Request / Tool | `Request/SelectionRequest/LocationRequest` | 编辑器交互层 | selection、drag、create、reconnect 请求 |
| GEF 层 | EditPolicy / Command | `EditPolicy/getCommand` | 后续 GEF-like 层 | 命令生成、交互策略，不属于 M1-M10 核心 |

## API Family ID 约定

下列 ID 用于稳定引用本文档中的 API family。后续设计、实现、测试和验收说明应优先使用这些 ID，避免同一语义被重复命名。

| Family ID | 对应 API 家族 | 语义边界 |
|---|---|---|
| `geometry.primitives` | 几何 Primitive | Point、Vec2、Dimension、Rectangle、Insets、PointList、Affine2D 等平台无关几何 |
| `graphics.context` | Graphics 绘制上下文 | draw/fill、clip、translate、scale、state stack、颜色、线型、文本、图片 |
| `figure.tree` | Figure 树结构 | parent/children、child order、reparent、remove、树拓扑不变量 |
| `figure.lifecycle` | Figure 生命周期 | attach/detach、addNotify/removeNotify、资源与监听解绑边界 |
| `figure.geometry.bounds` | Bounds 几何 | bounds、location、size、translate 及其对 paint/layout/hit-test 的影响 |
| `figure.box.client_area` | ClientArea / Insets | border inset 后的内容区，paint/layout/hit-test 共享盒模型 |
| `figure.visibility.enabled` | 可见性 / 启用 | visible/showing/enabled 对 paint、hit-test、event target 的影响 |
| `figure.properties` | Figure 属性 | foreground/background/font/cursor/tooltip/opaque 等本地或继承属性 |
| `paint.protocol` | Paint 主协议 | paintFigure、paintClientArea/children、paintBorder 的顺序和坐标域 |
| `border.protocol` | Border | insets、preferred size、opaque、paint 及其对 client area 的影响 |
| `clipping.strategy` | ClippingStrategy | parent/client area/child bounds 裁剪策略 |
| `coordinate.conversion` | 坐标转换 | parent/local/root/absolute/relative 坐标域转换 |
| `hit_test.search` | Hit-test | containsPoint、findFigureAt、findMouseEventTargetAt、TreeSearch |
| `event.point_reduction` | 事件点降域 | 平台或 root 坐标事件点转换为 target Figure 本地坐标 |
| `event.dispatcher` | EventDispatcher | 平台输入适配之后的引擎层 target 查找、capture、focus、hover 状态机 |
| `event.input_listeners` | 输入事件监听 | mouse、motion、wheel、key、focus listener 与 Figure callback |
| `event.focus` | Focus | focus owner、focus traversal、focus gained/lost |
| `layout.manager` | LayoutManager | layout、constraint、preferred/min size、invalidate；maximum size 属于 IFigure |
| `layout.graph` | 有向图与复合图布局 | 独立图请求、尺寸与包含约束、typed 算法/结果能力、完整路径及 Figure/Connection 投影 |
| `validation.protocol` | Validation | invalidate、invalidateTree、revalidate、validate、validation root |
| `update_manager.two_phase` | UpdateManager | Validation -> Damage Repair 两阶段更新事务 |
| `damage.repaint` | Damage / Repaint | repaint、dirty region、intersects、damage parent-chain 映射 |
| `frame.preparation` | Frame preparation | 稳定派生状态、validation、damage、resource 与 in-flight submission 的因果边界 |
| `animation.timeline` | Animation timeline | 单调时钟、Track、Motion、Trigger、Composition、中断与确定性采样 |
| `animation.presentation` | Presentation Plane | committed/presentation 分离、temporary visual、表现 damage 与交互几何策略 |
| `runtime.identity` | Runtime 身份域 | 公开 handle 的 Runtime 归属与跨 Runtime 误用拒绝 |
| `resource.lifecycle` | Resource 生命周期 | Pending/Ready/Failed/Removed、revision、提交顺序与 retry 恢复 |
| `render.backend_session` | Backend session | backend 建立/重建、Ready 资源快照与完整场景恢复 |
| `notification.figure` | Figure 通知 | Figure moved / bounds changed 等对象状态通知 |
| `notification.coordinate` | Coordinate 通知 | coordinate root 或坐标系统变化通知 |
| `notification.property` | Property 通知 | property change 语义 |
| `notification.action` | Action 通知 | button-like action 发生事实与稳定 revision |
| `notification.ancestor` | Ancestor 通知 | parent-chain add/remove/move 通知 |
| `notification.layout_update` | Layout / Update 通知 | layout lifecycle、validating、painting phase 通知 |
| `accessibility.bridge` | Accessibility 桥接 | engine-owned accessibility snapshot/delta 与平台 adapter |
| `viewport.scroll_zoom` | Viewport / Scroll / Zoom | viewport、scroll pane、range model、zoom transform、content clip |
| `layer.freeform` | Freeform / Layer | Layer、FreeformLayer、自由坐标内容范围 |
| `connection.figure` | Connection | Connection、PolylineConnection、point list、connection layer |
| `connection.anchor` | Anchor | source/target anchor、owner bounds 变化、reference point |
| `connection.router` | Router | routing constraint、route/invalidate/remove、Manhattan/Bendpoint 等 router |
| `connection.locator` | Locator | connection labels、decorations、endpoint/midpoint placement |
| `builtin.figures` | 基础 Figure 类型 | rectangle、ellipse、rounded rectangle、polygon、polyline、label、image |
| `text.flow` | 文本 Flow | FlowFigure、TextFlow、ParagraphTextLayout、基础文本测量与换行 |
| `text.interaction` | 文本交互几何 | document position、caret placement、point hit-test、selection geometry |
| `widgets.basic` | Widget 辅助 | button-like、toggle-like、clickable 等基础交互 figure |

## Milestone 到 API 语义映射

本文只提供人工可读的阶段映射，用于理解不同能力组之间的语义依赖；具体交付节奏以当前开发计划为准。

| Milestone | 主 API 语义 | 次级关联 | 推进时必须检查 |
|---|---|---|---|
| M1 几何与 Graphics 基础 | `geometry.primitives`, `graphics.context` | `paint.protocol`, `clipping.strategy` | 几何平台无关性、Graphics 状态栈、clip/transform 组合 |
| M2 Figure 树与盒模型 | `figure.tree`, `figure.lifecycle`, `figure.geometry.bounds`, `figure.box.client_area`, `figure.visibility.enabled` | `hit_test.search`, `coordinate.conversion`, `notification.ancestor` | active surface 的 parent/child 不变量、z-order、bounds/clientArea/visible/enabled 一致性 |
| M3 绘制遍历与裁剪闭环 | `paint.protocol`, `graphics.context`, `clipping.strategy`, `border.protocol`, `hit_test.search` | `figure.box.client_area`, `coordinate.conversion`, `damage.repaint` | active surface 的 paint 顺序、clientArea clip、border 顺序、paint 与 hit-test 可见性一致 |
| M4 坐标域与变换闭环 | `coordinate.conversion`, `figure.box.client_area`, `event.point_reduction` | `hit_test.search`, `damage.repaint`, `viewport.scroll_zoom` | local/parent/absolute/relative 往返、事件点降域、dirty rect parent-chain 映射 |
| M5 Layout + Validation + UpdateManager | `layout.manager`, `validation.protocol`, `update_manager.two_phase`, `damage.repaint` | `figure.geometry.bounds`, `figure.box.client_area`, `notification.layout_update` | layout constraint、preferred/min/max size、Validation 先于 Damage Repair、dirty region 合并 |
| M6 事件分发与交互状态机 | `event.dispatcher`, `event.input_listeners`, `event.focus`, `hit_test.search`, `event.point_reduction` | `coordinate.conversion`, `figure.visibility.enabled` | target 查找、capture、hover/enter/exit、focus、target-domain event |
| M7 通知语义分层 | `notification.figure`, `notification.coordinate`, `notification.property`, `notification.ancestor`, `notification.layout_update` | `figure.lifecycle`, `validation.protocol`, `update_manager.two_phase` | Figure/Coordinate/Property/Ancestor/Input/Update 通知不混层 |
| M8 Viewport / Scroll / Zoom | `viewport.scroll_zoom`, `clipping.strategy`, `coordinate.conversion`, `hit_test.search` | `damage.repaint`, `update_manager.two_phase`, `layer.freeform` | viewport 作为 Figure 树语义参与 paint、hit-test、坐标转换和 damage repair |
| M9 Connection / Anchor / Router | `connection.figure`, `connection.anchor`, `connection.router`, `connection.locator` | `coordinate.conversion`, `damage.repaint`, `notification.ancestor`, `hit_test.search` | anchor 端点、router point list、node movement reroute、connection damage/hit-test |
| M10 常用 Figure 与文本/控件 | `builtin.figures`, `border.protocol`, `text.flow`, `widgets.basic`, `notification.action`, `accessibility.bridge` | `layout.manager`, `event.input_listeners`, `figure.properties` | deferred builtin Figure 升级为完整 reusable surface；具体 Figure 只能消费核心协议，不引入特例 |

Core 1.0 后的 P2 delta 使用同一组稳定 Family ID，不发明平行语义：

| P2 Delta | 主 API 语义 | 当前状态 | 完成后提升 |
|---|---|---|---|
| P2-C01 | `builtin.figures`, `connection.figure`, `connection.locator` | `complete` | PointList miter bounds、rotatable polygon/polyline decoration 与 endpoint locator 已验证 |
| P2-C02 | `connection.router` | `complete` | ShortestPath obstacle snapshot、确定性批量路由与增量失效 verified |
| P2-F01 | `builtin.figures` | `complete` | ScalablePolygonFigure template-to-bounds 几何 verified |
| P2-F03 | `builtin.figures`, `border.protocol`, `hit_test.search` | `complete` | ADR-052 本项目扩展：逐角圆角与矩形分边颜色；Core 契约、Native GPU、布局缓存及最终门禁见[证据](../../verification/reviews/independent-shape-corners-2026-10-27.md) |
| P2-T01 | `text.flow` | `complete` | 只读 paragraph/fragment/wrap/bidi TextFlow verified |
| P2-T02 | `text.interaction` | `complete` | immutable layout 的 position/caret/selection/movement geometry verified |
| P2-G02 | `graphics.context`, `text.flow`, `text.interaction`, `paint.protocol`, `damage.repaint`, `render.backend_session` | `complete` | 统一测量/绘制、默认与可替换 glyph 轮廓链路及外部消费者已验证 |
| P2-M01 | `animation.timeline`, `animation.presentation`, `frame.preparation`, `damage.repaint` | `in_progress` | ADR-026 已接受；M01-A/B complete，当前推进 M01-C 领域消费者 |
| P2-S09 | `animation.timeline`, `animation.presentation`, `frame.preparation`；`notification.figure`, `notification.coordinate`, `notification.ancestor`, `notification.property`, `notification.action`, `notification.layout_update` | `in_progress` | ADR-057 已接受；[S09-A](../../verification/reviews/p2-s09-a-implementation-2026-10-30.md)和 [S09-B](../../verification/reviews/p2-s09-b-implementation-2026-10-30.md)实现及自动门禁已完成；B 统一 listener 准入／注销、持久发布游标与无 GPU 通知结清，Inspector poison／恢复属本地与宿主合同；成本仅覆盖实测容量；C／D 待实施，不关闭 M01 平台剩余验收 |
| P2-L01 | `layout.graph`, `layout.manager`, `connection.anchor`, `connection.router`, `frame.preparation` | `complete` | ADR-043 与 preparation 增量已实施；默认/外部算法、52 个官方组合、真实菜单与 Native 验收、最终门禁见[证据](../../verification/evidence/adr043/implementation.md) |

P2-G02 不改变以下已验证基线行的完成记录。新 Graphics facade 必须继续保持
文本度量/绘制同源、图文有序合成、字体资源 revision 与失败发布合同；
自研 fragment shader 的曲线预处理格式属于 backend 扩展，不冒充 Draw2D 的现有 API。

## 长期能力分母与处置

本节是“能力对等或超过 Draw2D”的长期分母。M1-M10 `complete` 只表示对应交付切片完成，
不表示本表所有能力已完成。处置状态使用以下稳定词汇：

- `adopted`：保留 Draw2D 可观察行为，使用 Rust API 表达；
- `adapted`：保留行为目标，但所有权、失败或调度协议按 Novadraw 调整；
- `substituted`：由可证明等价的组合能力替代，不增加同名 API；
- `pending`：属于长期目标，已有正式 delta，尚未完成；
- `rejected`：明确不进入目标，必须记录现代替代方案与理由。

| 能力 ID | Draw2D 能力 | 目标归属 | 处置 | Novadraw 公开入口或目标入口 | 验证 suite / delta | 差异理由或退出条件 |
|---|---|---|---|---|---|---|
| `CAP-FIGURE-TREE` | Figure tree、bounds、paint、hit-test | GOAL-CAP/EXT | `adapted` | `FigureTreeBuilder`、`FigureTree`、Runtime scoped mutable facade | M2-M6 suites | arena + generational ID 替代 Java 对象引用 |
| `CAP-UPDATE` | Validation / Damage Repair | GOAL-CAP/PERF | `adapted` | `Runtime::prepare_*`、`FigureMut::{revalidate,repaint}` | `core.runtime`、GA-2 | Runtime 是唯一驱动边界；仍需真实工作量基线 |
| `CAP-LAYOUT` | LayoutManager 与具体布局 | GOAL-CAP/EXT | `adopted` | `LayoutManager`、`LayoutSceneQuery`、`LayoutOutput` | M5 contracts | 输出先预检再发布，不允许 manager 持有树 |
| `CAP-COORDINATES` | absolute/relative/parent 坐标转换 | GOAL-CAP | `adapted` | `FigureTree::*_transform` | M4 contracts | 返回纯变换，失败不静默修改输入 |
| `CAP-EVENTS` | dispatcher、capture、focus、listeners | GOAL-CAP/PORT | `adapted` | `Runtime::dispatch_*`、平台 input adapter | M6/M7 suites、GA-3 | 平台只规范化输入；状态机位于 Core |
| `CAP-GRAPHICS-CORE` | state、transform、rect/path/text/image | GOAL-CAP | `adopted` | `Graphics` / `PaintContext` + `CommandRecorder` | M1、M10、P2-R02、TC-01 | Render IR 必须被启用 backend 完整消费或拒绝；内部 recorder 不公开 |
| `CAP-GRAPHICS-ADVANCED` | path clip、gradient、custom dash/miter | GOAL-CAP | `adapted` | `PaintContext` + Paint/StrokeStyle/ClipPath + backend-neutral Render IR 已实现；逐操作 AA 与低 miter 已落地 | [P2-G01 证据](../../verification/reviews/p2-g01-graphics-evidence.md)、[当前能力复核](../../verification/reviews/core-capability-status-2026-11-02.md) | Core/Vello 与 Native/Web 像素已验证；P2-G01 的 surface 局部修复及完整平台验收仍需闭合；通用设备 hairline 未实现 |
| `CAP-GRAPHICS-XOR` | XOR graphics | GOAL-CAP | `rejected` | 交互用途替代：retained feedback layer | [P2-G01 契约](../../design/rendering/p2-g01-graphics-extension.md) | 不承诺设备 XOR 像素语义；反馈用途替代需独立验证，不以 Difference blend 冒充等价 |
| `CAP-TREE-ATOMIC-ADD` | `add(child,constraint,index)` | GOAL-CAP/EXT | `adapted` | `FigureTreeBuilder::insert_child_with_constraint`、`ContainerMut::insert_with_constraint` | `core.p2-s01-child-insertion` / P2-S01 | 新 owned Figure 一次预检 admission、constraint、order 与 publication；Result 失败不发布节点，已有 Figure 移动仍用 reparent |
| `CAP-ANIMATION` | Animation、Animator、LayoutAnimator、RoutingAnimator | GOAL-CAP/EXT/PERF | `adapted` | Runtime-owned Timeline／typed Track／Presentation Plane、真实几何派生与容量预留已实现 | P2-M01 A/B/C、ADR-046、`animation.tree`；[当前能力复核](../../verification/reviews/core-capability-status-2026-11-02.md) | Core 与 Tree 批次已实现；M01-D 平台／呈现验收仍保留，不复制静态全局状态、阻塞 run loop 或逐帧 source mutation |
| `CAP-CLIPPING-EXT` | replaceable/multi-rect clipping | GOAL-CAP/EXT | `pending` | 目标：受控 clipping provider | P2-C03 | 先闭合跨 viewport Connection 可见性真实用例 |
| `CAP-CONNECTION` | Connection/Anchor/Router/Locator | GOAL-CAP/EXT | `adapted` | `connection` module + Runtime registries | M9、P2-C01/C02 | 策略纯计算，Runtime 原子提交 route batch |
| `CAP-TEXT-FLOW` | FlowPage/TextFlow/ParagraphTextLayout | GOAL-CAP/EXT | `adapted` | `TextFlowFigure`、`TextLayoutEngine`、`figure::flow` | P2-T01/T02/T03 complete（ADR-042） | styled request、来源快照、开放 inline/block、四侧 FlowBorder、外部 root 与独立替代引擎、失败恢复与六个官方入口已验证；UTF-8/affinity 和显式选择绘制作为合理变体 |
| `CAP-WIDGETS` | Clickable/Button/Toggle 与完整 widget family | GOAL-CAP | `pending` | `ClickableFigure`、`ButtonFigure`、`ToggleFigure` 与五部件 ScrollBar／共享 range／repeat 已实现 | M10.4 complete、ADR-041；P2-W01 deferred | 已实现子集不等于完整 family；ButtonGroup／radio／slider 等继续独立评审 |
| `CAP-GRAPH-LAYOUT` | Directed/CompoundDirectedGraphLayout | GOAL-CAP/EXT | `adapted` | `layout::graph` 独立模型、typed registry、GraphProjection/Anchor/Router | P2-L01、[ADR-043](../../adr/adr-043-directed-compound-graph-layout.md) | 独立图与 FigureTree 分开；默认/外部算法共用投影，52 个组合、候选测量/整体发布/失败恢复、真实菜单及 Native 四幅截图已验证，不承诺平台字体逐像素一致 |
| `CAP-PRINT-EXPORT` | PrinterGraphics / ScaledGraphics | GOAL-CAP/PORT | `pending` | 目标：输出目标与 scale adapter | P2-O01 | 不把 SWT Printer 类型引入 Core |
| `CAP-SHARED-SCENE` | `parts.Thumbnail` source / update / deactivate | GOAL-CAP/EXT | `adapted` | `scene::RuntimeScenes`、typed capture/dependency/view policy、owned `SceneSnapshot`、只读 `SceneViewHandle` 与有界交接 | K07、ADR-044 | K07-1/2 提供捕获、终止与结构准入；K07-3 提供目标导入和 view 契约；K07-4 官方活源拖拽、overview resize 与 Native 图像已验收 |
| `CAP-ACCESSIBILITY` | Accessible / dispatcher / actions | GOAL-CAP/PORT | `pending` | Core snapshot/action；Web/Native provider | M10.5 complete；P2-A01 pending | Core 语义完成不等于原生 AT provider 完成 |
| `CAP-LIVE-UNMOUNT` | remove 后由应用保活并再次挂载 | GOAL-EXT | `pending` | 目标待 ADR | P2-LC01 | 先定义所有权、ID、扫描参与和退出路径 |
| `CAP-PLATFORM-HOST` | LightweightSystem / FigureCanvas | GOAL-PORT/EXT | `adapted` | `PlatformHost` + winit/web package | GA-3 | 不复制 SWT control；逐平台验证实际生命周期 |

长期能力的执行状态只在
[`doc/roadmap/p2-delta-backlog.md`](../../roadmap/p2-delta-backlog.md) 维护。
平台支持声明只在
[`doc/roadmap/platform-support-matrix.md`](../../roadmap/platform-support-matrix.md) 维护。

## 方法级 API 跟踪矩阵

本节记录从 draw2d 源码抽取的方法级 API 语义，用于后续把 family 级覆盖拆成可执行的
architecture delta、contract test 和产品入口检查。它不是要求逐方法照搬 Java API；Novadraw
可以使用 trait、`FigureId`、图 API、上下文对象或命令对象表达等价语义。

校准规则：

- 如果本项目已有合理 public API 命名，优先记录实际 Rust 名称和导出路径。
- 如果本项目尚未声明 API，而本文档已有合理 family 命名，则继续使用本文档 family 名称作为目标契约名。
- 状态只描述当前外部可达 public API 与语义闭环，不把私有 helper、TODO/no-op 或未来草案记为已完成。

状态含义：

- `verified`：已有 public API、实现路径和测试或 milestone 完成证据。
- `partial`：已有骨架或部分实现，但语义闭环、测试、导出或产品入口不完整。
- `missing`：没有可定位的 Novadraw public API。
- `deferred`：已有代码或设计方向，但按 Figure Surface 分层暂不计入当前 milestone 门禁。

### M1 Graphics / Geometry

| Family ID | Draw2D 方法级 API | Novadraw 实际 / 目标 API | 状态 | 后续跟踪 |
|---|---|---|---|---|
| `graphics.context` | `Graphics.pushState/popState/restoreState` | `PaintContext::{push_state,pop_state,restore_state}` | verified | state floor 防止 Figure 弹出调用方状态；TC-01 外部 consumer 已验证 |
| `graphics.context` | `Graphics.clipRect/setClip/getClip`; `clipPath` | `PaintContext::{clip_rect,clip_path}`，ClipPath/FillRule 覆盖可恢复的矩形/路径交集 | partial | Figure 只能收窄 clip，不能 reset ancestor clip；getClip 查询 convenience 继续延后 |
| `graphics.context` | `Graphics.translate/scale/rotate/shear`; `getAbsoluteScale` | `PaintContext::{concat_transform,rotate_degrees,set_transform}`；`Affine2D` 表达平移、缩放与 shear | partial | transform 语义已验证；状态查询 convenience 明确延后 |
| `graphics.context` | `drawLine/drawRectangle/drawOval/drawPolygon/drawPolyline/drawPath` | `PaintContext::{stroke_line,stroke_rect,stroke_ellipse,stroke_polyline,stroke_path}` + 独立 `Path` | verified | M1 状态栈与 M10.1 reusable Figure 已覆盖实际消费路径 |
| `graphics.context` | `fillRectangle/fillOval/fillPolygon/fillPath/fillGradient` | `PaintContext::{fill_rect,fill_ellipse,fill_path}` + `set_fill_paint(Paint)` | verified | P2-G01 统一 solid/linear gradient，Native/Web DPI 1/2 像素和 alpha/状态恢复验证 |
| `graphics.context` | `drawRoundRectangle/fillRoundRectangle` | `RoundedRectangleFigure` 通过通用 path + stroke/fill 等价表达，不增加 convenience primitive | verified | 除非出现新的跨 Figure 复用证据，否则不机械增加同名 API |
| `graphics.context` | `drawString/drawText/drawTextLayout/fillText/getFont/getFontMetrics/setFont` | raw-string API 已删除；`Graphics` 负责字体/测量，`PaintContext::{fill_text,stroke_text}` 只消费已准备 `TextLayout` | verified | M10.2 backend-neutral layout metadata、字体 revision 与 Vello glyph adapter 已覆盖 |
| `graphics.context` | `drawImage(...)` | `PaintContext::{draw_image,draw_image_region}` 消费 `ImageResourceRef`；source 使用图像物理像素域，destination 使用逻辑坐标域 | verified | `core.image-source-rectangle` 覆盖完整/局部 source、结构化失败、Vello 仿射映射与 destination clip |
| `graphics.context` | `setAlpha/setAntialias/setLineDash/setLineCap/setLineJoin/setLineMiterLimit/setXORMode` | `PaintContext::set_stroke_style(StrokeStyle)` 统一 width/cap/join/dash/offset/miter，`set_opacity(graphics::Opacity)` 安装受检值 | partial | custom dash/offset/miter 已贯通 IR 与实际 bounds；XOR 拒绝；AA 已接入 Vello；ADR-049 低 miter 与 Cocoa 样例零宽映射有 CPU/GPU 证据；S08-A 在 Opacity 构造时区分非有限与越界，见[实施记录](../../verification/reviews/p2-s08-a-implementation-2026-10-29.md)；通用设备 hairline 保持独立 |
| `graphics.context` | `setAntialias/setTextAntialias` | `PaintContext::{set_antialias,set_text_antialias}` + `graphics::AntialiasMode`；状态栈保存，draw payload 冻结 | partial | `render.antialias` 验证独立文字提示、恢复、两级准入、SceneView 及 Native 离屏中心采样；Web 编译通过，浏览器像素与窗口呈现待发布准备验收 |
| `geometry.primitives` | `Point/Dimension/Rectangle/Insets/PointList/Precision*` | `novadraw::geometry::{Point,Vec2,Dimension,Rectangle,Insets,PointList,Affine2D,Precision}`；位置与向量类型分离，统一使用 f64 精度 | verified | M1/M4/M9/M10 已覆盖点向量运算、变换与 point-list 消费路径 |

Draw2D 证据入口：`Graphics.java`、`SWTGraphics.java`、`ScaledGraphics.java`、`PrinterGraphics.java`。

### M2 Figure Tree / Box Model

| Family ID | Draw2D 方法级 API | Novadraw 实际 / 目标 API | 状态 | 后续跟踪 |
|---|---|---|---|---|
| `figure.tree` | `IFigure.add(IFigure)` | 构建期 `FigureTreeBuilder::{set_contents,add_child}` 均返回 `Result`；运行期 `Runtime::set_contents` 与 `Runtime::container(parent)?.add(...)` | verified | 接纳前统一拒绝非有限/负尺寸 initial bounds；保持 child order、single/layer admission、no-cycle 与 10,000 层深度门禁 |
| `figure.tree` | `add(IFigure,int)`, `add(IFigure,Object,int)` | `FigureTreeBuilder::{insert_child,insert_child_with_constraint}`、`ContainerMut::{insert,insert_with_constraint}`；已有 child 使用 reorder/reparent | verified | P2-S01 suite 验证 0..=len、外部 typed constraint、原子拒绝、一次通知与 lifecycle；无 null ID 或分步 add/set/reorder |
| `figure.tree` | `remove(IFigure)`, `removeAll()`, `getParent()`, `setParent(IFigure)` | `ContainerMut::remove`、`FigureMut::reparent`、`Runtime::dispose_subtree` 与 `FigureTree::parent_id`；remove 释放 arena slot 与 side state，reparent 保持同 Runtime 身份 | partial | D4.3 已闭合 dispose/reparent；通用活对象迁移撤回，`removeAll` convenience 延后 |
| `figure.tree` | `getChildren()` | 已验证 `FigureNode::children_count` 直接读取；`FigureTree::child_order/descendant_ids` 返回受检 Result | verified | 不暴露可修改 children 引用；`p2_tree_query_identity` 覆盖 foreign/unknown/retired、合法空集合和保存 ID 再查询 |
| `figure.tree` | `parts.Thumbnail.setSource` 的跨视图依赖 | `scene::SceneBindingGroup`、typed view dependency policy 与 Runtime 结构提交准入 | verified | K07-2：完整捕获子树含 hidden/rect 外/pending view；直接、deferred、typed reparent、子树替换和图候选交错均受检；目标快照安装由 K07-3 另验收 |
| `figure.lifecycle` | `addNotify()`, `removeNotify()` | `FigureLifecycle::{on_attached,on_detached}`、parent-first activation、descendant-first disposal、旧 visual damage 与 side-state 清理 | verified | D4.3 自动契约覆盖 10,000 层 dispose 与 panic/fault 边界 |
| `figure.geometry.bounds` | `getBounds/setBounds/getLocation/getSize/setSize/translate` | `NodeState` 是运行时几何真源；`FigureTree::figure_bounds` 返回受检 Result，`FigureMut::{set_bounds,translate}` update-aware 修改；Figure callback 使用 `EventContext::set_bounds_later` 延迟提交 | verified | 合法零 bounds 与身份错误分离；UML probe 覆盖 capture drag、damage 与 Connection 重路由；S08-C 补原始 detached 构造、Bounded 更新与点列／轮廓派生拒绝，见[实施记录](../../verification/reviews/p2-s08-c-implementation-2026-10-29.md) |
| `figure.box.client_area` | `getClientArea()`, `getClientArea(Rectangle)`, `getInsets()` | 已验证 node 的 client area getter；`FigureTree::insets` 与 `LayoutSceneQuery::container_bounds` 受检查询 | verified | M5/M8 合法盒模型保持；S07 身份与派生 overflow 按领域错误传播 |
| `figure.visibility.enabled` | `isVisible/setVisible/isShowing/isEnabled/setEnabled` | `FigureTree::{is_visible,is_enabled,is_effectively_visible,is_effectively_enabled}` 返回受检 Result；`FigureMut::{set_visible,set_enabled}` 提交 mutation | verified | `p2_tree_query_identity` 验证合法 false 与无效身份分离，短路前先校验目标 |
| `hit_test.search` | `containsPoint`, `intersects`, `findFigureAt`, `findMouseEventTargetAt` | `Bounded::{contains_point,intersects}`, `FigureTree::{hit_test,hit_test_simple,find_mouse_event_target_at}` | verified | 保持逆序命中和 visible/enabled probes |
| `hit_test.search` | `findFigureAtExcluding`, `TreeSearch.accept/prune` | `TreeSearch`、`TreeSearchContext`、`ExclusionSearch`、`FigureTree::{hit_test_with,hit_test_excluding,find_in_subtree,ancestor_ids,descendant_ids,is_ancestor_of}` | verified | D1.5a：共享 hit-test traversal、prune 子树与稳定结构查询已有契约测试 |
| `figure.properties` | `foreground/background/font/cursor/opaque` | `FigureStyle`、`ResolvedStyle`、Runtime update-aware style/opaque mutation 与 cursor 查询 | verified | D1.4：继承、局部覆盖、通知、绘制应用与 macOS 人工验收已完成；S08-A 使用 Opacity／FontDescriptor，构造拒绝非法输入并保持最近祖先覆盖，见[实施记录](../../verification/reviews/p2-s08-a-implementation-2026-10-29.md) |
| `figure.properties`, `event.input_listeners` | Figure 事件期样式与 cursor replacement | `EventSceneQuery::figure_style` 返回 committed 副本；`EventEffects::set_style_later` 经同一 Runtime style 提交，None 恢复继承 | verified | K01 外部 `p2_deferred_style` 四项测试与 InternalFrame 真实光标事件测试通过 |
| `figure.tree`, `runtime.identity`, `layout.manager`, `resource.lifecycle` | detached branch 构造后整体挂载 | `FigureSubtree`、`SubtreeNodeId`、`FigureMut::add_subtree` 与 `EventEffects::add_subtree_later` | partial | constraint、typed resource、配对 Connection binding 预检、身份退休、owned Anchor 释放、结果回调与 FIFO/panic 已验证；旧单节点/批量/keyed Layer 插入复用资源准入，Builder → Runtime 受检构造与 attached 资源 effect 整批拒绝已验证；同一 dispatch 前缀及另一 Runtime 嵌套隔离已验证；官方 More Children / ConnectionAndAnchor / Grid Add 消费同一路径；其他 Canvas 消费与事件验收待补，Java 验证流程已撤销 |
| `figure.tree`, `figure.lifecycle`, `resource.lifecycle` | LightweightSystem / Viewport 完整 contents 替换 | Runtime / RuntimeViewports 的 `set_contents_subtree`；EventEffects 的 Runtime / Viewport 延迟替换入口 | partial | 整树预检拒绝保留旧场景、Single policy、资源发布、释放/挂载时序与事件 FIFO 已有外部测试；graph / ShapeStyles 官方场景验收仍随 K06/K08 推进 |
| `figure.properties` | `tooltip` | FigureStyle tooltip 三态继承；Runtime-owned waiting/visible/hidden、单调 deadline、Show/Replace/Hide update 与共享边界 placement | verified | `m10_tooltip_contract`、Native overlay 截图与 Web DOM hover 验证 |

Draw2D 证据入口：`IFigure.java`、`Figure.java`。

### M3 Paint / Clip / Border

| Family ID | Draw2D 方法级 API | Novadraw 实际 / 目标 API | 状态 | 后续跟踪 |
|---|---|---|---|---|
| `paint.protocol` | `IFigure.paint(Graphics)` | `runtime.frames().prepare_submission` 驱动 crate 内部递归 traversal；local style 通过 Graphics state 栈继承，self/children/border 与兄弟隔离保持固定 | verified | D4.5 关闭 ancestor style O(N²)；TC-01 移除未出版帧旁路 |
| `paint.protocol` | `Figure.paintFigure/paintClientArea/paintBorder` 扩展点 | `Figure::{paint,paint_border}` 接收受限 `PaintContext` 并返回 `GraphicsError`；client-area 与 child traversal 只由递归 renderer固定执行 | verified | 不开放绕过树遍历、坐标和 clip 协议的 child paint |
| `paint.protocol` | `parts.Thumbnail` source 子树捕获 | `scene::RuntimeScenes::capture` 复用稳定化和递归绘制，独立 root-local clip/transform、继承 style、受检资源闭包；目标 `SceneViewFigure` 通过普通 preparation 与 Graphics 回放 | verified | `p2_scene_capture`、`p2_scene_group` 与 `p2_scene_view` 提供捕获、结构准入及安装反例；K07-4 官方 Thumbnail Native 消费已验收 |
| `layout.manager` | `parts.Thumbnail.getPreferredSize/adjustToAspectRatio` | typed `SceneViewPolicy` 的 content measurement 与 client placement；默认 `ASPECT_FIT_VIEW` 保持源比例，Core 统一应用 Border insets | verified | K07-3：无提示、单轴/双轴提示、显式 preferred、minimum/零尺寸与普通 Border；外部策略错误和恢复共用通道 |
| `clipping.strategy` | `getClippingStrategy/setClippingStrategy` | Figure capability 提供默认值；`NodeState` 保存 Runtime override；`ContainerMut::set_child_clipping_strategy` 受控替换三种核心策略 | partial | Core 1.0 replacement 已验证；任意多矩形 provider 延后到真实需求 |
| `border.protocol` | `Border.getInsets/paint` | `Border::{get_insets,paint,get_color,get_width}`；`paint` 显式接收 owner bounds 与 `PaintContext` | verified | Rust trait 不复制 Draw2D owner object 参数；绘制失败进入帧错误通道 |
| `border.protocol` | `Border.getPreferredSize/isOpaque` | `Border::{preferred_size,is_opaque}`，FigureTree 将 owner-scoped metrics 合并进盒模型与 opaque 判断 | verified | Compound 递归快照与共享 TitleBar 多 owner 契约已覆盖 |
| `border.protocol` | concrete border implementations | `LineBorder`、`MarginBorder`、`RectangleBorder`、`CompoundBorder`、`EtchedBorder`、`BevelBorder`、`TitleBarBorder` | verified | `border-app` 与 M10 border/text 契约测试；动态子 Border 可位于任意组合深度 |
| `border.protocol` | Novadraw 原始 Border 输入边界 | ADR-056：Result 构造、私有 StrokeStyle／Insets、builder 等价、静态／owner 指标与捕获候选准入 | verified | `p2_s08_border_input_contract`、`p2_s08_admission_contract` 与独立消费者验证构造失败、动态输出、共享 owner、旧状态与有效重试；历史 DashDot 继续映射 Dash；[S08 完成记录](../../verification/reviews/p2-s08-d-completion-2026-10-29.md)含 Native GPU 与成本 |
| `border.protocol` | `SchemeBorder.Scheme` highlight/shadow color bands | `SchemeBorder` 经普通 Border/CompoundBorder 接入；不对称色带和空层独立占位 | verified | `scheme_border_contract` 外部消费者覆盖累计 inset、色带顺序、透明性和小矩形；Path/Zoom 消费 scrollbar scheme |
| `graphics.context` | font-derived underline metrics | ADR-050：`MeasureContext::prepare_underlines` 按实际 run metrics、baseline 和逻辑范围生成不可变片段，Graphics 绘制 | partial | `text.underlines` 覆盖实际 fallback 字体、字号、行、RTL、组合字符、字体替换、外部指标拒绝与 GPU Partial/Full；上游和跨平台栅格验收仍保留 |
| `graphics.context` | ICO image resources in `PrintExample` | `ImageData::decode` 识别 ICO，经统一资源请求完成和 RGBA 输出 | verified | `font_decoration_image_contract` 覆盖原始 brazil.ico、截断数据、无效 scale；不新增 Core 文件 I/O |
| `graphics.context`, `resource.lifecycle` | Zoom 原始 SVG 在缩放和 DPI 变化后保持自然尺寸 | `render::SvgImageSource` 保存解析源；`SvgRasterOptions` 校验整数密度与像素预算；普通 ImageData/token 替换 | verified | `svg_raster_density_contract`、Zoom 共享图标 revision/布局回归和 Native GPU 替换/恢复像素已验证；跨显示器系统 DPI 验收仍待完成 |
| `damage.repaint` | `erase()`, `repaint()`, `repaint(Rectangle)` | `FigureMut::repaint`、`Runtime::request_full_redraw`、old/new visual erase 与内部 `UpdateManager` damage 聚合 | verified | `erase` 与树级 repaint primitive 保持 crate 内部；dirty merge、parent-chain 投影和 partial repair 已验证 |

Draw2D 证据入口：`Figure.java`、`Border.java`、`AbstractBorder.java`、`LabeledBorder.java`。

### M4 Coordinates / Event Point Reduction

| Family ID | Draw2D 方法级 API | Novadraw 实际 / 目标 API | 状态 | 后续跟踪 |
|---|---|---|---|---|
| `coordinate.conversion` | `translateToAbsolute(Translatable)`, `translateToRelative(Translatable)` | `FigureTree::{local_to_surface_transform,surface_to_local_transform}` 返回 `Result<Affine2D, CoordinateQueryError>` / `Result<Option<Affine2D>, CoordinateQueryError>` | verified | M4 合法输入基线保持；`p2_coordinate_query_failure` 补充 foreign/retired、精确奇异、逆范围与组合溢出 |
| `coordinate.conversion` | `translateToParent(Translatable)`, `translateFromParent(Translatable)` | `FigureTree::{local_to_parent_transform,parent_to_local_transform}` | verified | 坐标转换为纯查询，调用方显式应用变换；Viewport 扩展仍归 M8 |
| `coordinate.conversion` | `isCoordinateSystem()` | 无对应模式开关；所有树边统一使用 parent-local bounds，容器通过 `FigureContainer::child_transform` 提供额外 Affine2D | verified | 坐标根语义由显式变换边表达；移动 ancestor 不改写 descendant bounds |
| `coordinate.conversion` | `isMirrored()` | 暂无 public 等价 API | deferred | 可延后，当前不阻塞 M4 |
| `event.point_reduction` | MouseEvent target point 转为 target local 域 | `MouseEvent::with_target_point`, `MouseEvent::entry_point`, `EventDispatcher` dispatch 路径 | verified | M4 contract 验证 hit-test、entry point 与 target-domain callback 同源 |

Draw2D 证据入口：`IFigure.java`、`Figure.java`、`Viewport.java`。
Novadraw 验证入口：`crates/novadraw/tests/m4_coordinate_contract.rs`、`crates/novadraw/examples/native/transform-app`。

### M5 Layout / Validation / UpdateManager

| Family ID | Draw2D 方法级 API | Novadraw 实际 / 目标 API | 状态 | 后续跟踪 |
|---|---|---|---|---|
| `layout.manager` | `LayoutManager.getConstraint/setConstraint/remove` | parent-owned typed constraint；`FigureMut::{set_layout_constraint,remove_layout_constraint}` 与 callback deferred mutation 在提交前校验 manager compatibility | verified | D3.2 原子失败、FIFO 与 validation queue 契约测试通过 |
| `layout.manager` | `getPreferredSize(IFigure,wHint,hHint)`, `getMinimumSize(...)` | `LayoutManager::{preferred_measurement,minimum_size}` 使用结构化 constraints 与 Result；Tree owner 校验选中分支、Border/insets 和 projection 后写成功缓存；Node 非权威尺寸 getter 已退出公开 API | verified | `p2_query_failure_semantics` 与内部 `s07_` 测试覆盖身份错误、非法 callback Ok 值、prepared/Border、投影/inset 溢出、正常失效重试与候选隔离 |
| `layout.manager` | `LayoutManager.invalidate(IFigure)`, `layout(IFigure)` | 图级 invalid path 与 generation 驱动缓存失效；外部与内置 `layout` 共用受检 `LayoutSceneQuery`，完整 Output 在提交前准入 | verified | `p2_query_failure_semantics` 与内部 `s07_` 测试覆盖查询失败后丢弃 bounds/repaint 候选，候选通知/damage 不出版、stable epoch 不晋升；M5 原子 placement 回归保持 |
| `layout.manager` | concrete layout implementations | 六类布局算法、构建期配置与 `ContainerMut` 动态 replacement 已验证；新 manager 提交前校验已有 constraints | verified | `m5_layout_contract` 覆盖 child-content client area、inset 单次应用与 Border 非对称区域分配；P2-S05 覆盖两层 Toolbar + inset container + Label；`d3_runtime_mutation` 与 `layout-app` |
| `layout.manager` | GridLayout grab、等宽、span/hint 的 Canvas 契约 | grab 无 hint 时允许轨道收缩；整数分配、span/indent/hint、minimum=preferred；列宽分配后重测无 height hint 的宽度依赖 child，再求解行高；测量与放置共用阶段 | partial | `p2_grid_measurement_contract` 与 [K02 消费者核验](../../verification/reviews/k02-layout-consumers-evidence-2026-10-23.md)保留既有证据；[新增核验](../../verification/reviews/official-layout-caret-consumers-2026-10-27.md)覆盖真实文字窄宽/恢复、span/indent/height hint、受约束父高度及实际 retained 隐藏/恢复像素；连续窗口事件、真实字体和跨平台保留 |
| `layout.manager` | Flow/Toolbar 的轴向 hint、minimum 与整数排列 | Flow 主轴 hint 且 minimum=preferred；Toolbar 次轴 hint/二次测量、逐项整数收缩；overflow 对齐保留负偏移 | partial | `p2_layout_measurement_contract` 与 [K02 消费者核验](../../verification/reviews/k02-layout-consumers-evidence-2026-10-23.md)保留既有证据；[新增核验](../../verification/reviews/official-layout-caret-consumers-2026-10-27.md)覆盖实际 Label/FlowPage、zero/窄宽/恢复及真实 retained 隐藏/恢复；连续窗口事件、真实字体和跨平台保留 |
| `validation.protocol` | `IFigure.invalidate`, `invalidateTree`, `revalidate`, `validate`, `setValid` | `FigureMut::revalidate` 与内部 validation cycle，`FigureTree::is_valid` 提供查询 | verified | validation 驱动不再从 FigureTree 公开；hidden/disabled 子树恢复时经 update-aware setter 重新入队 |
| `update_manager.two_phase` | `addInvalidFigure`, `performValidation`, `performUpdate`, `runWithUpdate` | `UpdateManager` 串联 Validation -> Damage Repair；支持非重入、panic 恢复、周期快照和因果通知 | verified | `runWithUpdate` 由组合根事务表达 |
| `damage.repaint` | `UpdateManager.addDirtyRegion`, `performUpdate(Rectangle exposed)` | dirty 合并、根域传播、`DamageMode::{None,Full,Partial}` 与 retained frame 提交已闭合 | verified | exposed-rect overload 作为 P1 扩展 |

Draw2D 证据入口：`LayoutManager.java`、`UpdateManager.java`、`DeferredUpdateManager.java`。

2026-10-22 BorderLayout 回归：显式 Center 且没有边区 child 时占满完整 client area，
不为不存在的 North/South/East/West 预留默认尺寸。`m5_layout_contract` 验证该反例；
旧无约束布局的 fallback 区域保持兼容。官方 Path 已使用默认 BorderLayout 消费。
P2-L01 按已接受的 [ADR-043](../../adr/adr-043-directed-compound-graph-layout.md)
实施：`layout::graph` 纯请求/受检结果、通用候选验证和实例级开放 registry
已通过 18 项外部非分层协议测试。Directed 默认算法已完成消环、加权 rank、
virtual nodes、排序/放置与完整路由，16 fixture 双方向 32 组合和独立反例通过。
Compound 默认算法已完成，10 fixture 双方向 20 组合与嵌套/反馈端点反例通过。
Core 新增 `PreparationScene::measure_figure` 和 `FigurePreparation::measure_scene`，
在显式约束下独立分派 preferred/minimum 的权威来源，结构化保留失败主体和原因。
外部消费者反例位于 `p2_preparation_measurement_contract`。Core 已增加 Runtime 签发的
候选快照、路由快照观察、稳定结果版本和必需组发布检查，外部消费者反例位于
`p2_prepared_scene_routing_contract`。快照计算观察已参与路由结构环检测，
必需组准入拒绝路由/Locator 输出的反向读取。同源失败恢复成功记录中的 resolved
metadata；改源或改绑定后失败不能恢复旧 resolution，首帧失败仍可修正后重试。
LayoutManager 子查询已按显式约束重测，preferred/minimum 分别选择，
缓存命中保留传递观察，嵌套错误保留实际测量主体与原始原因。
`FigureMeasurementSource` 区分受约束测量源版本与已提交 metrics 代数；
同源失败后的重试不替换快照或重算路由。
候选准入与身份复用逐项核对源输入及字体版本；字体替换或移除后，
显式路由在重新准备前拒绝旧快照。
资源依赖身份及状态进入源前缀和 `FigureMeasurementSource`，派生恢复不撤销
资源变化；图片更新、移除、失败恢复及无关资源隔离反例通过。
候选依赖校验、共享预算、约束 Flow 测量与统一 Figure/Connection 投影均已完成。
图容器受约束测量复用纯 producer，tracked viewport 滚动保持图 identity 和路由次数；
普通 Runtime 布局使用同一文字服务，冻结源前缀由后代共享不可变切片。
两个官方图入口通过 52 个源码输入方向组合、真实菜单切换、旧身份与注册退休、
resize 后字体资源检查和 Native 四幅代表性截图。最终 workspace 与公开 API
门禁、五个应用探针及 Web backend 编译通过。
`CAP-GRAPH-LAYOUT` 为 adapted；P2-L01 为 complete，见
[实施证据](../../verification/evidence/adr043/implementation.md)。

### M6 Event Dispatcher / Focus / Capture

| Family ID | Draw2D 方法级 API | Novadraw 实际 / 目标 API | 状态 | 后续跟踪 |
|---|---|---|---|---|
| `event.dispatcher` | `dispatchMousePressed/Released/Moved` | `EventDispatcher::{receive,dispatch_mouse_pressed,dispatch_mouse_released,dispatch_mouse_moved}`，`Event::Mouse`, `MouseEventKind` | verified | target-domain callback 与 capture 状态测试 |
| `event.dispatcher` | dispatcher consumed / capture result | `DispatchOutcome::{target,is_handled,capture}` 从 Runtime 返回平台无关的分发结果 | verified | Editor G3 P2 delta；不改变既有 Figure callback 或 capture 状态机 |
| `event.dispatcher` | `dispatchMouseDragged/Entered/Exited/Hover/DoubleClicked` | entered/exited 与 hover callback 由 `mouseTarget` 路由；`hoverSource` 专用于 tooltip source；pointer leave 清理 capture/pressed | verified | 交互父 + 非交互子、capture release/leave、mouse/cursor/tooltip target 分轨 |
| `event.dispatcher` | `setRoot`, `setControl` | `Runtime::set_contents` 管理 root；`PlatformHost` 注入平台服务，避免 dispatcher 持有原生 control | verified | 接受组合根 + host adapter 变体，examples 只做平台输入适配 |
| `event.focus` | `requestFocus`, `requestRemoveFocus`, `getFocusOwner`, `hasFocus`, `isFocusTraversable` | `Runtime::{request_focus,clear_focus,traverse_focus}`、`InteractionState::focus_owner`、`FocusTraversalPolicy`、`FocusEvent` | verified | D1.5b 引擎 focus model 与 D1.5c Native/Web Tab traversal 已通过自动验证及 macOS/Web 人工验收 |
| `event.dispatcher` | `setCapture`, `releaseCapture`, `isCaptured` | handled press 自动 capture，release/leave 自动释放；`DispatchOutcome::capture` 暴露本次结果，capture 状态由 Runtime interaction state 内部维护 | verified | captured target 与 hoverSource 独立，不公开任意 capture mutator |
| `event.input_listeners` | `MouseWheelListener`, `KeyListener`, `FocusListener` | `WheelEvent`、`ZoomEvent`、`KeyEvent`、`FocusEvent` 与 Figure callback 端口；scroll/zoom session 固定 target | verified | Winit 只在 `novadraw-example-support` 适配单位、DPI 与 phase；pointer capture 与 gesture session 分轨 |
| `event.dispatcher` | `updateCursor`, `getAccessibilityDispatcher` | cursor 与 Tooltip 经 PlatformHost effect；Runtime 从 stable scene 发布 accessibility Snapshot/Delta，Host 只做平台映射 | verified | M10.5 保留 engine semantics / platform adapter 分层 |

Draw2D 证据入口：`EventDispatcher.java`、`SWTEventDispatcher.java`、`MouseEvent.java`、listener 接口。

### M7 Notification / Listener Semantics

| Family ID | Draw2D 方法级 API | Novadraw 实际 / 目标 API | 状态 | 后续跟踪 |
|---|---|---|---|---|
| `notification.figure` | `add/removeFigureListener`; figure moved / bounds changed | `Runtime::add_figure_listener` + 统一 `remove_listener`；typed committed-state event | verified | D3.3 Runtime 注册、触发、注销与 self-removal 已验证 |
| `notification.ancestor` | `add/removeAncestorListener` | `Runtime::add_ancestor_listener`；Added/Moved/Removed typed event | verified | D3.3 Runtime 公共路径已验证 |
| `notification.coordinate` | `add/removeCoordinateListener` | `Runtime::add_coordinate_listener`；`CoordinateSystemChanged` typed event | verified | D3.3 Runtime 公共路径已验证 |
| `notification.property` | `add/removePropertyChangeListener`, 按 property name 监听 | `PropertyKey<V>` + `TypedPropertyChange<V>`；Runtime journal 保存 erased identity 与结构化诊断值；Toggle selected 与 editor selection 分离 | verified | ADR-028 / TC-04 验证 typed key、外部值类型、coalescing、Behavior 与 Listener |
| `notification.action` | `ActionListener.actionPerformed` | `Runtime::add_action_listener` + `ActionEvent { figure_id, revision }`；与 property change 进入同一 effect queue | verified | M10.4 顺序与 D3.3 self-removal 契约测试通过 |
| `notification.layout_update` | `add/removeLayoutListener`, validating/painting | typed listener + `NotificationRecord { source_epoch, sequence }`；`StableSceneQuery` 只读 flush 时最新稳定场景 | verified | D4.4 验证历史事件 FIFO 与最新 stable query 不混淆；阶段记录不是事前 hook |

Draw2D 证据入口：`IFigure.java`、`Figure.java`、`UpdateManager.java`、listener 接口。

### M8 Viewport / Scroll / Zoom

| Family ID | Draw2D 方法级 API | Novadraw 实际 / 目标 API | 状态 | 后续跟踪 |
|---|---|---|---|---|
| `viewport.scroll_zoom` | `Viewport.getContents/setContents` | `ViewportHandle::contents` 只读查询；`ViewportMut::set_contents` 提交替换；`ChildPolicy::Single` 在 add/reparent 入口强制单 contents | verified | `m8_viewport_contract` 覆盖替换与原子拒绝 |
| `viewport.scroll_zoom` | `get/setHorizontalRangeModel`, `get/setVerticalRangeModel` | `RangeModel` / `DefaultRangeModel`；Viewport 与 ScrollBar 在私有 runtime 中共享模型，公开 handle 提供 snapshot | verified | ViewportLayout 通过 sealed typed effect 在完整 LayoutOutput 校验后提交 range/content scale |
| `viewport.scroll_zoom` | `getViewLocation`, `setViewLocation`, `setHorizontalLocation`, `setVerticalLocation` | `ViewportHandle::view_location` 只读查询；`ViewportMut::{set_view_location,set_horizontal_location,set_vertical_location,scroll_by}` 提交 mutation | verified | clamp、property/coordinate effect 与 repaint 已覆盖 |
| `viewport.scroll_zoom` | `ScalableFigure`、`AbstractZoomManager`、`IZoomScrollPolicy`、zoom levels、fit | typed `SCALE` / `ScaleCapability`、`ScaleModel`、`ScaleHandle`、`ZoomManager`、`ZoomScrollPolicy`、`DefaultScrollPolicy`、`MouseLocationZoomScrollPolicy` | verified | capability 不依赖具体 Figure downcast；`setScale` 只失效；manager 在写入前校验 policy location，再执行 scale → validate → scroll；Viewport 不保存 zoom |
| `viewport.scroll_zoom` | `get/setContentsTracksWidth/Height` | `ViewportHandle::{contents_tracks_width,contents_tracks_height}` 只读查询；`ViewportMut::{set_tracks_width,set_tracks_height}` + `ViewportLayout` | verified | minimum/preferred size 与 range extent 已覆盖 |
| `viewport.scroll_zoom` | `ScrollPane.getViewport/setViewport`, `setContents`, `scrollTo`, scrollbar visibility | `ScrollPaneHandle::viewport` 只读查询；`ScrollPaneMut::{set_contents,scroll_to,set_scroll_bar_visibility}` + `ScrollPaneLayout` | verified | 标准组合固定持有一个 viewport，不开放破坏组合不变量的 setViewport |
| `border.protocol`, `viewport.scroll_zoom` | `ScrollPane.setBorder` 与 client area 布局 | `ScrollPaneFigure` 注册通用 `BORDER` capability，使用 `ReplaceFigureBorder`；`ScrollPaneLayout` 消费扣除 border insets 后的容器区域 | verified | 官方示例外部 crate 挂载 GroupBoxBorder，并验证缩小后自动显示滚动条、增高后隐藏；不增加特殊容器节点 |
| `viewport.scroll_zoom` | `ScrollBar.get/setRangeModel`, `get/setValue`, `stepUp/stepDown`, increments, replaceable parts, `REPEAT_FIRING` | 独立 `ScrollBarFigure`、五个普通 child、typed part constraint、可替换 RangeModel/custom thumb；250ms/40ms 连发与取消通过开放 FigureActivity；Zoom 和 ScrollPane 共用 | verified | ADR-041、`p2_scroll_bar`、`m8_viewport_contract`、Zoom 原公式与 Native 截图；Lines/LogicalPixels 与祖先 wheel fallback 保留 |
| `layer.freeform` | `Layer.containsPoint/findFigureAt`, `LayeredPane.add/getLayer/removeLayer`, `FreeformLayer.getFreeformExtent/setFreeformBounds`, `ScalableFreeformLayeredPane` | Layer、keyed pane、Freeform 类型、派生 extent、nested 映射、OverflowVisible、`FreeformLayout` 与 content-domain Viewport/Zoom 集成 | verified | D2.1-D2.5 自动契约与 Native/Web 人工验收通过；不递归改写普通 child bounds |

连续缩放回归：`LayoutSceneQuery::container_bounds` 与 measurement 共用容器的
`layout_constraints`，扣除物理 insets 后反算逻辑可用尺寸；外部缩放容器通过同一
协议验证。ScrollBarLayout 的 minimum 与 preferred 一致，对齐 Draw2D
AbstractLayout。`zoom_example` 的连续按钮测试和 `zoom_verification` 四阶段
Native 截图覆盖最小、最大、再次最小，缩小时两个类完整可见，滚动条厚度保持不变。

Draw2D 证据入口：`Viewport.java`、`ScrollPane.java`、`RangeModel.java`、`ScrollBar.java`、`ScrollBarLayout.java`、`AbstractLayout.java`、`ScalableFigure.java`、`Layer.java`、`FreeformLayer.java`。

### Runtime / Resource / Submission 横切契约

| Family ID | Draw2D 方法级 API / 合理变体 | Novadraw 实际 / 目标 API | 状态 | 后续跟踪 |
|---|---|---|---|---|
| `runtime.identity` | LightweightSystem/Figure 所属图实例隔离；跨图引用不得命中 | Figure/Resource/Listener/Router/Anchor/BackendSession handle 均携带 Runtime namespace，跨 Runtime mutation 结构化拒绝 | verified | D4.3 已移除 `Runtime::into_tree` 有损重包装并验证完整 Runtime move |
| `resource.lifecycle` | 图像/字体状态变化必须按提交因果顺序到达 renderer | ResourceRegistry revision + ordered `ResourceOp`；delta retry 恢复精确前缀，Ready -> Failed -> Ready 顺序闭合 | verified | D4.2 自动契约与 Vello cache 测试 |
| `resource.lifecycle` | `parts.Thumbnail` 的独立视图资源与释放 | 来源 revision 映射为不同目标不可变 ID；`InstalledScene`、prepared drawing、in-flight 与 recovery 前缀保留 CPU lease | verified | K07-3：font/image 共存、同键去重、闭包失败不安装、最后 lease 回收、reset 后 Snapshot 及 Retry；公开修改导入 ID 返回 `ImmutableImport` |
| `render.backend_session` | 新 Graphics/backend 必须能恢复当前资源与完整场景 | Host 串行接管以 Snapshot + Full 建立基线；拒绝缺基线 Delta 与同域 stale generation | verified | D4.2/D4.4 已验证；并发 producer activation token 不在 Core 1.0 范围 |
| `frame.preparation` | validate -> derived state -> damage repair 的稳定更新边界 | Runtime typed worklist 在 stable epoch 前收敛；公开 Ready/Idle/Suspended/AwaitingCompletion/Error，失败不提交 frame | verified | D4.1/D4.4 自动契约 |
| `frame.preparation` | `FigureCanvas` 透明 root 继承宿主背景 | Host typed provider 输出 owned snapshot；RuntimeFrames 检查 request、surface/位置/DPI 后统一冻结背景、Canvas、清屏值及资源；背景参与时完整修复 | verified | K07-5：`p2_host_background` 验证独立变化、pending/失败、移除/迟到、stale/conflict、版本拒绝、Retry/reset 与 capability；K07-6 的 `example.inherit-background` 验证官方双 Canvas、滚动/移动、DPI、暂停恢复与 repair 的 macOS Native 像素 |

### P2 Animation / Presentation

| Family ID | Draw2D 方法级 API / 合理变体 | Novadraw 实际 / 目标 API | 状态 | 后续跟踪 |
|---|---|---|---|---|
| `animation.timeline` | `Animation.markBegin/run`、Animator playback 与共享 session | Runtime-owned typed channel、Tween/Keyframes/Spring/Decay、Parallel/Sequence/Stagger/Repeat、模式、cancel/retarget 与单调时间 | partial | M01-A/B 已验证；ADR-046 新增 S/E、真实 bounds 与 Tree viewport 跟踪，证据入口 `animation.tree`；route/continuous consumer 仍待实现 |
| `animation.presentation` | LayoutAnimator/RoutingAnimator 的 before/after 表现过渡 | committed truth + Runtime presentation override/temporary visual；typed bounds/visibility/origin、冻结内容、派生 drawing 与容量预留 | partial | ADR-046 的统一绘制读取和外部 typed 扩展由 `animation.tree` 覆盖；不逐帧修改 source bounds、Lines、通知或 history；未关闭全部 M01-C 能力 |

### M9 Connection / Anchor / Router / Locator

| Family ID | Draw2D 方法级 API | Novadraw 实际 / 目标 API | 状态 | 后续跟踪 |
|---|---|---|---|---|
| `connection.figure` | `Connection.get/setSourceAnchor`, `get/setTargetAnchor` | `ConnectionRuntime` 持有 optional AnchorId、tracked dependencies 和 unresolved/rebind；route batch 先完成 Figure geometry/Locator preflight，再原子提交 geometry 与 resolution | verified | 非有限 geometry 不得形成伪 Resolved |
| `connection.figure` | `get/setConnectionRouter`, `get/setRoutingConstraint` | `RouterRegistry` + `RouterId` + inherited/explicit binding 已实现；typed constraint 归 Connection | verified | reparent 前迁移内置 absolute bendpoint；无迁移协议的自定义 constraint 原子拒绝 |
| `connection.figure` | `getPoints/setPoints` | `RouteOutput` 经 Runtime 规范化为 ConnectionFigure local points，并同步 NodeState path bounds、paint、hit-test 与 damage | verified | 外部 setPoints 不开放；route truth 与 child visual envelope 分离 |
| `connection.anchor` | `ConnectionAnchor.getLocation`, `getOwner`, `getReferencePoint`, `add/removeAnchorListener` | 只读 Anchor 协议、5 个内置 Anchor、TrackedRouteSceneQuery dependency tokens 已实现 | verified | S07 内置/外部 adapter 保留失败观测；`p2_route_dependency_recovery` 和 `m9_connection_contract` 验证删除依赖、新绑定恢复与旧 ID 拒绝，见 [核验记录](../../verification/reviews/p2-s07-query-identity-completion-2026-10-16.md)；[S09-C](../../verification/reviews/p2-s09-c-implementation-2026-11-02.md)验证单一 fallible 注册、fault 无登记及新 owner 隔离 |
| `connection.router` | `ConnectionRouter.route`, `invalidate`, `remove`, `get/setConstraint` | Direct/Bendpoint/Fan、shared Manhattan 与 obstacle-aware ShortestPath 均使用 Runtime-owned stable group snapshot 和 atomic batch commit；ShortestPath 追踪 obstacle geometry/visibility/topology/transform，并提供确定性正交搜索与工作计数 | verified | `core.p2-c02-shortest-path-routing` 覆盖单/多障碍、不可达恢复、增量失效及 64×64 snapshot 复用；[S09-C](../../verification/reviews/p2-s09-c-implementation-2026-11-02.md)验证单一 fallible 注册、引用保护与已提交前缀保留，路由语义保持 |
| `connection.router` | `graph.ShortestPathRouter.solve` / `Path` used by ObstructionExample | VisibilityGraphConnectionRouter 使用欧氏 visibility graph、两次增长、共享 corner 排序、inversion/split/bend/recombine，spacing=4；局部 right/bottom 减一，不改变连续 Rectangle；P2-C02 正交 Router 保持独立 | verified | 2026-10-21 ADR-040 实现，Rust 不变量、外部组 solver 与 Native 四阶段截图已验证；workspace 最终门禁通过。等距路径采用稳定插入顺序，不宣称 Java HashSet 的逐点唯一结果；省略 oval 搜索裁剪与跨帧缓存 |
| `clipping.strategy` | nested viewport connection clipping / unsupported topology | Core 1.0 严格比较 connection parent 与两端 owner 的 viewport chain；divergent chain 返回 `UnsupportedViewportTopology` 并清除旧 route | verified | nearest-common-viewport 多矩形 clipping 明确延后 |
| `connection.locator` | `Locator.relocate`, `ConnectionLocator`, `EndpointLocator`, `MidpointLocator` | Runtime-owned direct-child binding 消费 prepared local route；实现 endpoint、middle、indexed midpoint、path fraction、terminal tangent/normal 与 u/v offset；polygon/polyline decoration 作为普通 child 原子提交已旋转 geometry | verified | P2-C01 覆盖重复 terminal point、AnchorSite normal fallback、退化 route 与 decoration preflight |
| `connection.locator` | `ConnectionEndpointLocator.relocate(IFigure)` owner-side / child-size placement | ADR-039 的 LocatorInput 与 ChildLocatorPlacement 共用于内置/外部策略；Runtime 收集 tracked owner 边界和受检 preferred size；ConnectionEndpointLocator 实现四侧、转置、斜率限制与 v 符号，保留 EndpointLocator 原行为 | verified | `p2_owner_locator_contract` 覆盖 source/target 四侧、corner tie、v 正/零/负、半像素、无 owner、normal fallback、外部 bounds 错尺寸拒绝、owner 删除重绑和嵌套缩放/旋转 envelope；`m9_connection_runtime` 覆盖测量变更恢复；UML u=8/v=4 已接入并核验 Native 截图。保留 f64 连续坐标，不复制 Java 整数截断 |

规范 Rust 契约、坐标域和错误模型见
[`design/architecture/connection-routing.md`](../../design/architecture/connection-routing.md)；
由 ADR-005 接受。

Draw2D 证据入口：`Connection.java`、`PolylineConnection.java`、`ConnectionAnchor.java`、
`ConnectionRouter.java`、`Locator.java`、`AbstractRouter.java`；方法级分析见
[`reference/draw2d/figure/connection-routing.md`](../../reference/draw2d/figure/connection-routing.md)。

### M10 Reusable Figures / Text / Widgets

| Family ID | Draw2D 方法级 API | Novadraw 实际 / 目标 API | 状态 | 后续跟踪 |
|---|---|---|---|---|
| `builtin.figures` | `RectangleFigure` | `RectangleFigure::{new,from_bounds,new_with_color,with_stroke,with_local_coordinates,with_child_clipping_strategy,with_border,translate,set_bounds}` | verified | Rectangle 是 active core baseline，不属于 deferred |
| `builtin.figures` | `Shape.setFill/setOutline/setLineWidth/setLineWidthFloat` | `Shape` trait 暴露只读能力；颜色走 Runtime FigureStyle，几何 stroke 参数由 concrete builders/mutation 提供 | partial | Core 1.0 接受具体类型入口；统一 Shape mutation 明确延后到跨 Figure 需求成立 |
| `builtin.figures` | `Ellipse` | `EllipseFigure` + Runtime FigureStyle；optimized fill/outline bounds、精确椭圆命中 | verified | `m10_reusable_shape_border_contract` |
| `builtin.figures` | rounded rectangle | `RoundedRectangleFigure::{set_corner_dimensions,corner_dimensions}` + `FigureMut::set_corner_dimensions`；二维圆角 path 与精确命中 | verified | 单值 radius 仅为等宽高 convenience |
| `builtin.figures`, `border.protocol` | Novadraw 扩展：逐角圆角与分边颜色 | `ShapeContour`、`RectangleCorners`、`RectangleEdges`；RoundedRectangle/Polygon/Triangle 与 RectangleShapeBorder 消费同一轮廓；typed component updates | verified | P2-F03；旧 corner dimensions 单位不变，不宣称 Draw2D 原 API 对等；Native 像素与 WASM 编译分别取证 |
| `border.protocol` | Novadraw 扩展：关闭邻边后的自由端 | RectangleBorderGeometry 按边存在性区分接角与 Butt 自由端，直线切点截断，零圆角齐到矩形顶点 | verified | [自由端修订证据](../../verification/reviews/shape-free-end-butt-2026-10-27.md)，16 种开关组合与 native GPU 末行全线宽检查 |
| `builtin.figures` | point-list shape mutators | `FigureMut::{replace_points,insert_point,set_point,remove_point,clear_points}`；parent-domain 输入原子规范化为 local points + NodeState bounds | verified | 非有限输入与非法 index 无 partial commit |
| `builtin.figures` | `Polyline.containsPoint`, `Polygon.containsPoint`, paint | segment tolerance、closed polygon interior/edge、退化点数和 local point paint 已闭合 | verified | `m10_reusable_shape_border_contract` |
| `builtin.figures` | PointList stroke envelope | Polyline、Polygon 与 Connection 共享 line join/stroke width visual outset；Runtime stroke style mutation 原子重建 bounds | verified | P2-C01；锐角 miter 与 Round/Bevel 定向测试 |
| `builtin.figures` | `ScalablePolygonShape.setTemplate`, bounds-driven scaled points | `ScalablePolygonFigure` 保存 template，按当前 NodeState bounds 以 Stretch/PreserveAspect 和双轴 alignment 派生同源 paint/hit geometry | verified | `core.p2-f01-scalable-polygon` 覆盖退化模板、resize、stroke/miter、precise hit、typed mutation 与示例 |
| `builtin.figures` | triangle figure | Draw2D client-box/resize/居中顶点语义、精确三角形命中、`FigureMut::set_triangle_direction` | verified | 精确命中是 Novadraw 合理增强 |
| `border.protocol` | concrete border implementations | `LineBorder`, `MarginBorder`, `CompoundBorder`, `EtchedBorder`, `BevelBorder`；preferred size、ring opacity、累计 inset 与 Runtime replacement | verified | `TitleBarBorder` 留在 M10.2 |
| `border.protocol` | `LabeledBorder`, `TitleBarBorder` | TitleBarBorder 消费统一 `TextLayout` 与 resolved style；owner-scoped `BorderSnapshot` 按 Compound 结构递归组合并隔离共享实例 | verified | inner/outer/nested Compound 与 shared Compound 双 owner 字体指标契约测试 |
| `builtin.figures` | `Label` text/icon constructors, alignment, gap, preferred size, truncate, paint | `LabelFigure` 支持 backend-neutral text/image resource snapshot、alignment、gap、ellipsis、Border 盒模型和 icon named geometry | verified | 四方向 placement 的 glyph/image/gap 与 named geometry、cache/shaping、资源事务及 `text-app` 截图 |
| `builtin.figures` | `ImageFigure.getImage/setImage/getPreferredSize/setAlignment/paintFigure` | `ImageFigure` + `ImageId`；Runtime typed replacement/alignment；PNG/SVG decode；Pending/Ready/Failed/Unavailable；resource-referenced Image command | verified | Ready resource 删除会清除所有 dependent 的旧引用；Vello revision cache、`m10_label_contract` 与 Image_Resources 截图 |
| `text.flow` | `TextFlow.getText/setText`, fragment paint, truncate, leading word width | `TextFlowFigure` 以 FlowPage/Paragraph/InlineTextFragment 表达只读文本流，复用 Runtime-owned TextLayoutEngine 完成 hard/soft wrap、行数 truncate、bidi、测量与 Glyph IR | verified | `core.p2-t01-text-flow`；fragment 样式、caret/selection/editing 明确后置 |
| `text.interaction` | `TextFlow.getOffset/getCaretPlacement/getNextOffset/getFirstOffsetForLine/getLastOffsetForLine/setSelection` | immutable `TextInteractionMap` 提供 paragraph-local UTF-8 position、affinity、hit-test、caret、selection quad、movement 与相邻完整 grapheme 范围查询；mutable selection 属于 Editor session | verified | `core.p2-t02-text-interaction`；stale revision、truncate、grapheme、bidi 与 surface transform；[Caret 消费者](../../verification/reviews/official-layout-caret-consumers-2026-10-27.md)覆盖外部 provider、组合/ZWJ/emoji、边缘与真实 retained 鼠标更新 |
| `text.flow` / `figure.properties` / `viewport.scroll_zoom` | `Figure.isMirrored`、`BlockFlowLayout` alignment、`LineRoot` fragment commit | ADR-048：普通 FigureStyle 的继承方向、冻结 styled request、片段位置与交互共同映射；ScrollPane 换侧并共享纵向 range | partial | `text.layout-direction`：两种段落方向×五种 alignment、外部引擎、方向 mutation、caret affinity/视觉移动、窄宽与 GPU Partial/Full；上游与跨平台栅格验收保留 |
| `widgets.basic` | `Clickable.doClick`, action/change listener, model, selected, rollover, pressed/focus paint | `ClickableFigure` + `ClickableModel`；Runtime 唯一拥有 pointer/keyboard pressed、hover、focus、capture，Figure 仅消费派生 visual snapshot | verified | release-inside、drag-out/back、Enter/Space、disabled 与 typed action 契约测试 |
| `widgets.basic` | `Button` text/image constructors and default button style | `ButtonFigure` / `ToggleFigure` 组合 `ClickableModel + LabelFigure`；bevel、pressed offset、selected/focus/disabled visual | verified | `widgets-app` 三场景截图；repeat firing 与 ButtonGroup 不进入 M10.4 |
| `accessibility.bridge` | `Accessible`、AccessibilityDispatcher、focus/default action | namespaced node identity、name/description/value/role/state/bounds/children/focus、Snapshot/Delta 与受控 focus/default action | verified | `m10_accessibility_contract` 覆盖 stable publish、层级提升、Toggle action、dispose 与 10,000 层；完整原生 AT provider 延后 |

建议首批 Rust 契约草案：

```rust
pub struct LabelFigure {
    text: String,
    icon: Option<ImageId>,
    text_alignment: Alignment,
    icon_text_gap: f64,
}

pub struct ImageFigure {
    image: ImageId,
    alignment: Alignment,
}

pub trait ClickableBehavior {
    fn clickable_model(&self) -> &ClickableModel;
    fn clickable_model_mut(&mut self) -> &mut ClickableModel;
}
```

Draw2D 证据入口：`Shape.java`、`RectangleFigure.java`、`Ellipse.java`、`Polyline.java`、`Polygon.java`、`AbstractPointListShape.java`、`Label.java`、`ImageFigure.java`、`Clickable.java`、`Button.java`、`Toggle.java`、`ButtonModel.java`、`ToggleModel.java`、`ClickableEventHandler.java`、`text/TextFlow.java`、`text/FlowFigure.java`。M10.2 文本细节见 [`../../reference/draw2d/figure/text-label.md`](../../reference/draw2d/figure/text-label.md)，Novadraw 契约见 [`../../design/architecture/text-layout.md`](../../design/architecture/text-layout.md) 与 [`../../design/architecture/basic-widgets.md`](../../design/architecture/basic-widgets.md)。

## Milestone 推进检查规则

每次推进 M1-M10 相关功能或架构改动时，必须执行以下检查：

1. 列出受影响的 API family ID。
2. 对照本文件确认 draw2d 语义契约是否仍完整。
3. 如果契约不完整，必须新增 probe、测试、demo 断言或后续债务记录，不能只更新状态描述。
4. milestone 进入 `behavior_verified` 前，必须检查其主 API 语义已经有可重复验证证据。
5. milestone 进入 `complete` 前，必须确认主 API 语义、次级关联、文档和债务记录已对齐。
6. M1-M5 的完成判定只覆盖 active core Figure surface；M8/M10 才能把 Viewport 或 deferred builtin Figure 计入自身完成度。

## P0 核心契约分组

### Figure 树结构

代表 API：

- `IFigure.add(...)`
- `IFigure.remove(IFigure)`
- `IFigure.getChildren()`
- `IFigure.getParent()`
- `IFigure.setParent(IFigure)`

语义契约：

- Figure 是有序树节点，child 顺序同时影响绘制顺序和命中优先级。
- 子节点重挂载必须维护 parent 反向关系。
- 删除节点必须切断 parent/child 关系，并触发必要的 layout、paint、事件生命周期更新。
- 根节点深度为 0；add/reparent 后的最大深度不得超过 10,000，失败必须无副作用。

Novadraw 对照：

- 使用 `FigureTree` 承载拓扑。
- 使用 `FigureId` 引用节点，避免 Java 引用树。
- Figure 属性、运行时状态、拓扑保持分离：`Figure` / `FigureNode` / `FigureTree`。

建议 probes：

- `child_order_controls_paint_and_hit_test_priority`
- `remove_child_detaches_parent_relation`
- `reparent_child_updates_old_and_new_parent`
- `tree_depth_limit_rejects_add_and_reparent_atomically`

### Bounds 几何

代表 API：

- `IFigure.getBounds()`
- `IFigure.setBounds(Rectangle)`
- `IFigure.getLocation()`
- `IFigure.setLocation(Point)`
- `IFigure.getSize()`
- `IFigure.setSize(Dimension)`
- `IFigure.translate(int, int)`

语义契约：

- bounds 是 Figure 在 parent 坐标域中的外框。
- bounds 改变影响 paint、hit-test、layout、dirty region 和子节点绝对位置。
- 位置变化和尺寸变化都可能触发布局失效，但影响范围不同。

Novadraw 对照：

- bounds 通过 `Bounded` trait 和 `FigureTree` API 访问与修改。
- `FigureNode` 提供 `figure_bounds()` 等只读运行时视图，不是对外可变状态入口。
- 对外通过图 API 或 command 修改，避免直接可变引用穿透。

建议 probes：

- `bounds_change_invalidates_old_and_new_damage`
- `parent_move_changes_child_absolute_position`
- `resize_preserves_local_child_coordinates`

### ClientArea / Insets / Border

代表 API：

- `IFigure.getClientArea()`
- `IFigure.getInsets()`
- `IFigure.getBorder()`
- `IFigure.setBorder(Border)`
- `Border.getInsets(IFigure)`
- `Border.paint(IFigure, Graphics, Insets)`
- `Border.isOpaque()`

语义契约：

- border 不是纯装饰；它参与 Figure 盒模型。
- client area = bounds 去掉 border insets 后的内容区域。
- paint、layout 和 hit-test descent 必须共享同一套 inset/client area 逻辑。

Novadraw 对照：

- Border 应作为独立 trait 或 figure 装饰协议。
- client area 计算应集中在引擎层，避免 paint 和 hit-test 各自实现。

建议 probes：

- `border_inset_reduces_client_area`
- `paint_client_area_clip_matches_hit_test_descent`
- `opaque_border_affects_background_paint_order`

### Paint / Graphics

代表 API：

- `IFigure.paint(Graphics)`
- `Graphics.pushState()`
- `Graphics.popState()`
- `Graphics.translate(...)`
- `Graphics.clipRect(...)`
- `Graphics.draw*`
- `Graphics.fill*`

语义契约：

- Figure paint 是递归绘制协议，不只是单个节点 draw call。
- Graphics 维护绘制状态栈，包含 clip、transform、颜色、线宽、字体等状态。
- child paint 进入子坐标域，退出时恢复父级 Graphics 状态。

Novadraw 对照：

- `Graphics` / `PaintContext` 承载 Draw2D Graphics 语义，内部 recorder 只负责 lowering。
- Vello 后端只做渲染实现，不承载 Figure 树语义。
- 当前主线保护 `render_recursive.rs`，问题应优先定位 Figure 协议、坐标转换、canvas 命令或后端。

建议 probes：

- `graphics_state_restored_after_child_paint`
- `nested_translate_affects_child_commands`
- `clip_limits_child_paint_commands`

### Layout / Validation / Update

代表 API：

- `IFigure.setLayoutManager(LayoutManager)`
- `IFigure.setConstraint(IFigure, Object)`
- `IFigure.invalidate()`
- `IFigure.invalidateTree()`
- `IFigure.revalidate()`
- `IFigure.validate()`
- `UpdateManager.addInvalidFigure(IFigure)`
- `UpdateManager.performValidation()`
- `UpdateManager.performUpdate()`

语义契约：

- draw2d 的更新模型是两阶段：Validation -> Damage Repair。
- layout manager 负责在 validation 阶段设置 child bounds。
- repaint 只描述脏区，validate 负责结构和布局正确性，两者不能混为一次即时绘制。

Novadraw 对照：

- 引擎层需要显式承载 update pipeline。
- apps 不能直接手写通用 layout/validation 规则。

建议 probes：

- `invalidate_parent_schedules_validation_once`
- `validate_runs_layout_before_paint`
- `repaint_dirty_region_is_merged_before_render`

### 坐标转换

代表 API：

- `IFigure.translateToAbsolute(Translatable)`
- `IFigure.translateToRelative(Translatable)`
- `IFigure.translateToParent(Translatable)`
- `IFigure.translateFromParent(Translatable)`
- `IFigure.isCoordinateSystem()`
- `IFigure.isMirrored()`

语义契约：

- Figure 层的坐标转换是树结构语义，不是渲染后端细节。
- MouseEvent 进入 target Figure 时，事件点应从 root / absolute 域转换到 target local 域。
- parent bounds、coordinate root、mirroring 或 scale 都会改变转换链路。

Novadraw 对照：

- 坐标转换 API 应位于 `novadraw` Core。
- app 只负责平台输入点进入引擎前的最外层适配。

建议 probes：

- `nested_child_absolute_to_local_roundtrip`
- `mouse_event_point_is_relative_to_target`
- `clip_and_hit_test_use_same_coordinate_domain`

### Hit-test / Event Target

代表 API：

- `IFigure.containsPoint(...)`
- `IFigure.findFigureAt(...)`
- `IFigure.findFigureAtExcluding(...)`
- `IFigure.findMouseEventTargetAt(...)`
- `TreeSearch.accept/prune`

语义契约：

- 普通 Figure 搜索和鼠标事件目标搜索不是同一件事。
- 命中搜索按 child 逆序下降，使后绘制的 child 优先命中。
- invisible child 不参与绘制和命中；disabled child 的事件策略必须明确。

Novadraw 对照：

- hit-test traversal 是引擎通用机制。
- event target/source 点转换不能下放到应用层。

建议 probes：

- `topmost_child_wins_hit_test`
- `hidden_child_is_not_hit`
- `mouse_event_target_differs_from_generic_find_when_disabled`

## P1 能力补齐分组

### 输入事件与 EventDispatcher

代表 API：

- `EventDispatcher`
- `SWTEventDispatcher`
- `MouseEvent`
- `MouseListener`
- `MouseMotionListener`
- `MouseWheelListener`
- `KeyListener`
- `FocusListener`

语义契约：

- 平台事件先进入 dispatcher，再由 root Figure 命中 target。
- target Figure 接收相对自身坐标的事件点。
- dispatcher 还负责 capture、focus owner、entered/exited、drag、hover 等状态机。

Novadraw 对照：

- apps 只负责 winit / 平台事件适配。
- 引擎层负责 target 查找、事件点降域、listener/handler 派发。

### Layout 实现族

代表 API：

- `XYLayout`
- `StackLayout`
- `BorderLayout`
- `GridLayout`
- `FlowLayout`
- `ToolbarLayout`
- `DelegatingLayout`

语义契约：

- LayoutManager 是可替换策略，不是 Figure 的继承分支。
- constraint 是 parent layout 对 child 的私有协议。
- preferred/minimum size 计算必须纳入 border/client area。

Novadraw 对照：

- 先保证 `LayoutManager` trait 与 validation 语义，再逐个落地具体布局。

### Connection / Anchor / Router / Locator

代表 API：

- `Connection`
- `PolylineConnection`
- `ConnectionAnchor`
- `ChopboxAnchor`
- `EllipseAnchor`
- `ConnectionRouter`
- `ManhattanConnectionRouter`
- `BendpointConnectionRouter`
- `Locator`
- `ConnectionLocator`

语义契约：

- Connection 本身也是 Figure。
- Anchor 根据 owner bounds 和 reference point 计算连接端点。
- Router 根据 anchors、constraints 和已有路径生成 `PointList`。
- Locator 用于连接线标签、端点装饰、箭头等 child placement。

Novadraw 对照：

- Connection 可以作为 P1 能力，但不应抢在 Figure 核心契约之前。
- Anchor moved 应触发 connection revalidate 或 reroute。

## P2 与 GEF 层边界

P2 能力通过 `doc/roadmap/p2-delta-backlog.md` 独立跟踪，不改变已完成的 M1-M10
状态。当前 Core 增强批次已纳入 connection decoration/ShortestPath、
ScalablePolygonFigure 与 TextFlow 第一阶段；下一批已规划 P2-T02 文本交互几何与
P2-E02 Editor direct edit。其余能力继续只作后续对照：

- widget：`ButtonGroup`、radio/checkbox、repeat firing、`Slider`
- 图布局：`DirectedGraphLayout`、`CompoundDirectedGraphLayout`
- 后端适配：`PrinterGraphics`、`ScaledGraphics`
- GEF 交互层：`EditPartViewer`、`Request`、`Tool`、`EditPolicy`、`Command`

这些能力可以在核心 draw2d 语义稳定后，以独立 milestone 或 GEF-like layer 形式设计。

## 后续落地方式

本文档保持为人工可读的 draw2d 语义覆盖账本。后续功能迭代应从这里选取受影响的 API family，补齐对应的运行时代码、测试、demo 或视觉验证；产品交付与 demo 验证矩阵继续放在 `doc/roadmap/` 下维护。
