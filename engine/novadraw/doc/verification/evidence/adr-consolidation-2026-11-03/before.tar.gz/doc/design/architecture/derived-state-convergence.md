# 派生状态收敛事务

类型：`normative-design`

状态：`approved`

范围：D4.1

2026-09-10 修订：ADR-014 的约束测量与扩展发布边界已由 D4.4 独立实现和验证，
不由旧 D4.1 验证报告自动覆盖。

2026-10-12 修订：统一阶段版本与发布合同，区分固定调度和开放算法。
新增要求的验证边界见
[修订记录](../../verification/reviews/framework-architecture-contract-revision-2026-10-12.md)。

## 1. 目标

Runtime 接受一次 source mutation 后，应在同一次 frame preparation 中得到一致的：

- Figure bounds 与布局；
- intrinsic text/border metrics；
- Connection route、locator 与 decoration placement；
- Freeform extent、Viewport range 与 coordinate transform；
- constrained text/image presentation snapshot；
- damage、RenderCommand 与提交后通知。

应用不需要手工调用 route resolve，也不需要请求第二次 full redraw 才得到正确结果。

## 2. Draw2D 基线与 Novadraw 变体

Draw2D 的 DeferredUpdateManager 固定执行：

```text
performValidation
-> repairDamage
```

Figure validation 内同步执行 layout；ConnectionRouter 由 Connection validation 路径消费；
绘制只发生在 Figure 均已 valid 后。

Novadraw 保留“validation 先于 damage repair”的因果顺序，但不复制 Figure 主动修改
Connection 或访问 UpdateManager 的对象网络。Route、text shaping、resource snapshot 等
派生服务仍由 Runtime 拥有，通过只读输入计算，再由 Runtime 原子提交。

## 3. 状态分层

### 3.1 Source state

Source state 只由用户、平台输入或已排队 callback mutation 改变：

- Figure topology、style、content 与显式 size/constraint；
- Resource Pending/Ready/Failed 输入；
- Anchor、Router 与 routing constraint 绑定；
- Viewport/Zoom 的显式用户输入。

### 3.2 Pre-layout derived state

Pre-layout state 不依赖最终 container width：

- Label 完整文本和图标的 natural metrics；
- TitleBarBorder 的 intrinsic title metrics；
- Image ready 状态与 natural dimensions；
- 由 source/resource revision 决定的 measurement cache key。

这些值可以改变 preferred/minimum size，因此变化必须进入 validation。

### 3.3 Geometry derived state

Geometry state 由 LayoutSceneQuery/LayoutOutput 与规范坐标链得到：

- 依赖父级宽度约束的文本/组件测量高度、baseline 与布局快照；
- NodeState bounds；
- Freeform extent；
- Viewport range、view location 与 child transform；
- 依赖最终 owner geometry 的 named anchor region。

### 3.4 Route derived state

Route 只读取已提交 geometry snapshot。成功结果按 routing group 原子提交 Connection
points 与 bounds；失败结果将受影响 group 转为 unresolved 并清除旧 route。

### 3.5 Presentation derived state

Presentation snapshot 只依赖已经稳定的 geometry：

- 与布局所用约束一致的 glyph snapshot、单行 ellipsis；
- glyph origin 与 alignment；
- ImageResourceRef 与最终 destination rectangle；
- owner-scoped Border paint snapshot。

Presentation refresh 只能产生 repaint，不能反向改变 intrinsic size、NodeState bounds、
constraint 或 parent layout。违反该约束属于引擎 invariant error。

## 4. 静态依赖层级与 typed worklist

Runtime 使用单一 stabilization 入口，供产品 submission 与低层 frame 入口复用：

```text
ApplyPendingMutations
-> DrainCommittedChanges
-> drain typed work by fixed priority
   -> IntrinsicMetrics
   -> LayoutRoot
   -> GeometryChangePropagation
   -> RoutingGroup
   -> PostRouteGeometry
   -> stop when every work queue is empty
-> FinalizePresentationSnapshots
-> RepairDamageAndRecord
-> FreezeSubmission
-> FlushCommittedNotifications
```

依赖方向固定为：

```text
source/resource
  -> intrinsic metrics
  -> layout geometry
  -> route
  -> locator / visual envelope / freeform extent / viewport range
  -> presentation
```

Viewport 的 view/scale 投影变化在相同有效 viewport chain 内不得反向触发 content-domain
route。Connection 的 route-derived bounds 不得反向成为 owner layout 的 intrinsic
contribution。Anchor/Locator 的结构依赖环继续在注册或计算时拒绝。

Connection capability 的 bounds 由 points 决定；父 LayoutOutput 对该 child 的
Bounds placement 不得覆盖它。带 UpdateManager 和不带 UpdateManager 的布局提交
遵循同一规则，普通 child placement 与 Connection 的其他 layout effects 仍照常提交。

每类 work item 至少包含：

```text
kind
subject
source_revision
observed_generation
```

队列按树顺序或 routing group 稳定顺序处理，并按
`(kind, subject, source_revision, observed_generation)` 去重。处理后置工作时如果提交
事实产生更高优先级工作，调度器回到该优先级继续排空；不重新扫描无 dirty work 的阶段。

阶段不可由 app 重排。Runtime 不能在 worklist 排空前记录 command，也不能在稳定化
中途 flush listener。固定优先级是内部静态依赖图，不是插件可注册的通用 DAG。

### 4.1 统一版本与阶段发布

所有阶段遵循同一 `read inputs → prepare owned output → validate → publish work state`
合同。以下是语义字段，不要求新增一个承载全部字段的公共结构体：

| 阶段 | 必须观察的版本或输入 | 可提交输出 |
|---|---|---|
| intrinsic/constrained measurement | source/component、解析 style/font、资源 revision、constraints | metrics、baseline、不可变布局快照 |
| layout | snapshot generation、child measurement、content constraints 与容器投影 | 完整 child placements、受限领域 effect |
| route | endpoint/binding、routing domain、已提交 geometry generation | 同一 routing group 完整 route/unresolved |
| post-route geometry | route 与 owner/ancestor geometry generation | locator、envelope、freeform/range |
| final presentation | 最终 bounds/client clip/transform、已使用 TextLayout 与资源版本 | immutable presentation 与 visual envelope |

输出须绑定 subject、derivation epoch 和实际依赖版本。过期候选不能覆盖较新的工作状态；
依赖变化时重新入队相应阶段，不能以 source revision 相同推断几何或约束仍有效。
缓存只复用依赖键一致的结果；未变化结果不产生新的 committed fact 或反向 invalidation。
Route group 原子性不扩张为整棵树回滚。

工作状态可分阶段提交，但 stable epoch 必须在 worklist 排空且 final presentation
成功后晋升。录制和公开稳定观察只消费这次晋升的结果；录制失败时不出版 submission，
保留重绘工作。一次 frame preparation 可以包含多个内部计算批次，不能要求应用再次
prepare 才补齐后代文字。

所有阶段按领域保留错误原因；失败不发布该阶段的不完整候选。source commit 与此前
合法工作提交不回滚，最终帧、通知和查询不得冒充新稳定结果。

## 5. Committed facts 与三类日志

直接 Runtime API、callback mutation、LayoutOutput commit、route commit 与资源完成必须
产出同一种 committed fact。最小 fact 类型包括：

```text
GeometryChanged
TopologyChanged
CoordinateSystemChanged
NamedAnchorRegionChanged
StyleOrContentChanged
ResourceDependencyChanged
```

committed fact 是已提交事实，不是可拦截回调。它按用途投影为三个彼此独立的容器：

1. `DerivedWorkSet`
   - 内部调度使用；
   - 按 subject、dirty reason 与 generation 合并；
   - 驱动 Connection dependency、intrinsic/presentation cache、freeform 与 viewport。
2. `NotificationJournal`
   - 外部观察使用；
   - 保持 committed mutation 的因果 FIFO；
   - 只在 stable epoch 晋升后 flush。
3. `DamageAccumulator`
   - 保存 old/new visual envelope；
   - 可以空间合并，但不得承担派生状态调度。

同一事实不能由每个 Runtime API 各自手写一套 invalidation。Layout commit 绕过
Runtime public setter 仍会产出相同 committed fact。

## 6. Layout 原子提交

Layout calculation 只能读取 immutable snapshot，并产出待校验 output。它不得直接：

- 写共享 RangeModel/ViewportRuntime；
- 同步调用 RangeListener；
- 修改 FigureTree；
- flush notification。

容器需要更新 range/view state 时，必须通过 Runtime 的受检领域提交协议。
现有 crate-private layout effect 是内部实现细节，不能成为内置容器独有的语义权限。
提交顺序为：

```text
calculate child bounds + authorized typed effects
-> validate complete output
-> capture old geometry/state
-> commit child bounds and effects atomically
-> append committed facts
-> enqueue notifications
```

第三方 LayoutManager 不获得任意副作用 callback；相同容器能力必须能经公开
descriptor/prepared output 获得对等效果。新 effect 只有形成稳定领域契约、scope 和
失败语义后才能公开，不能直接暴露可写共享 RangeModel。

## 7. 自动路由

- Connection 的规范 routing space 由其 parent child-content domain 推导；
- 正常动态更新不要求应用传入 routing space；
- dirty connections 按 RouterId、routing domain 与 router-specific group key 形成稳定组；
- 每组先用当前 derivation epoch 内冻结的已提交几何快照计算完整 batch，再原子提交；
  这是内部计算快照，不要求整个 epoch 已经晋升 stable，否则会形成调度循环；
- geometry/topology fact 由 `DerivedWorkSet` 命中 dependency reverse index；
- route commit 可能使 locator/freeform/viewport 再次 invalid，因此将对应 typed work
  按固定优先级入队；
- explicit resolve 仅保留为诊断/同步工具，不是产品正确性的前置步骤。

一个 route group 失败不会回滚无关 group；失败 group 清除旧 geometry，进入稳定
unresolved 状态并保留用于恢复的 dependencies。

## 8. 文本测量与呈现

文本 API 按依赖分为：

1. `measure_intrinsic`：不使用最终 client width，产出 parent layout 所需 natural
   metrics；
2. `measure(constraints)`：在 Layout 阶段使用父级约束，产出换行后的高度、baseline
   和不可变 TextLayout；约束改变可以使布局贡献改变；
3. `layout_presentation`：使用已经 arrange 的 geometry 与同约束快照，产出
   ellipsis/alignment 和 glyph placement，不再改变布局贡献。

单行 Label/TitleBar preferred size 读取自然尺寸。presentation cache key 可以包含
最终 width/height，但纯表现刷新不 revalidate。通用 TextFlow 的约束测量不得受此限制。

这不要求本轮实现完整 TextFlow；先以外部受约束测量用例验证扩展边界。父级提供约束、
子级返回尺寸、再 arrange，不通过 presentation 后多次 full redraw 修补高度。

## 9. Stable epoch、预算与错误

每次真实 source transaction 分配单调 `derivation_epoch`；NoChange 不制造新派生工作。
Runtime 可以在该 epoch 内提交工作状态，但只有所有 typed work queue 排空且 final
presentation 完成后才将其晋升为 `stable_epoch`。
RenderSubmission、listener 和 Accessibility snapshot 只能消费 stable epoch。

预算至少同时覆盖：

- 本次 epoch 的 state-changing commit 总数；
- 同一 `(kind, subject, source_revision)` 的重复计算次数；
- 最终 feedback/epoch 次数上限。

`DERIVED_STATE_FEEDBACK_LIMIT = 16` 可以保留为最终 feedback 保险，但不得把“正常在
4 round 内稳定”作为算法正确性的依据。正常支持链路应沿静态依赖方向完成；已知结构环
必须提前拒绝，预算用于捕获 invariant 破坏、第三方策略不稳定或未知动态反馈。

达到预算仍有工作时：

- 不生成基于部分状态的新 submission；
- 保留 pending work 与 full redraw 请求；
- 不晋升 stable epoch；
- 记录结构化 `DerivationDidNotConverge`，包含阶段、subject、source revision、
  observed generation、state-changing commit 数和剩余 dirty categories；
- 不 flush 本次未形成稳定 frame 的 committed notification；
- 不在渲染热路径打印日志。

Source mutation 已经提交，不因派生失败回滚。后端继续保留上一 stable frame；当前
epoch 的派生查询返回明确的 `NotStable`/preparation error，而不是伪装成新稳定结果。
这不要求 Runtime 复制整棵旧场景。修复输入或策略后，Runtime 从保留的 dirty work
重试。

D4.1 形成内部 checked stabilization 结果；D4.4 再把 Idle、Suspended、
AwaitingCompletion 与全部 preparation error 收敛为最终公共 outcome。

## 10. Pending work

`runtime.frames().has_pending_update()` 至少合并：

- pending callback mutations；
- 非空 typed derived work queues；
- resource delta；
- damage/full redraw；
- in-flight retry work。

只存在 Dirty Connection 时也必须请求 host 下一次 frame。

## 11. 通知顺序

- 通知描述 committed facts；
- 同一 source mutation 产生的 effects 保持因果 FIFO；
- 同一 epoch 中产生的 effects 暂存，stable epoch 晋升后一次 flush；
- listener 不能观察 route 已 dirty 但 geometry 尚未提交等中间状态；
- unresolved route 是可观察的稳定结果，不属于部分提交。

## 12. 扩展点

### 新 LayoutManager

只消费 LayoutSceneQuery 并返回 LayoutOutput；不能获得 Runtime 或共享模型可变引用。
容器 effect 在完整 output 校验后由 Runtime 提交，不能自行读取可变 Runtime、
重入 mutation 或同步通知。内置与外部容器使用相同能力和权限合同；内部 sealed
实现不构成外部无法获得的特权路径。

第三方组件允许返回拥有候选值的私有派生快照，经统一 prepare/validate/publish 提交。
不能只有内置类型能更新测量状态；但不得借此执行任意共享模型 mutation。

### 新 Router

只消费 RouteSceneQuery/RouteRequest 并返回 RouteOutput；group scope 和 constraint compatibility
由 Router trait 声明，提交仍归 Runtime。Router 可以维护计算所需的私有 scratch state，
但不能修改 ConnectionFigure 或 FigureTree。

### 新文本引擎

分别支持 natural/constrained measurement 与 presentation；相同输入和约束复用
不可变 TextLayout/GlyphRun IR。D4.4 已补齐外部非空构造器与约束测量验证。

## 13. 验证

- direct set_bounds 后，正常 submission 自动 reroute；
- LayoutManager、callback、reparent 与 layer reorder 触发同一自动 invalidation；
- endpoint remove 同帧清除旧 route 并稳定 unresolved；
- shared Manhattan group 在自动路径保持完整 batch；
- Label 首次 submission 使用最终 width，不需要第二次 full redraw；
- ellipsis/alignment 使用最终 client area，presentation refresh 不 revalidate；
- freeform + viewport + connection 组合在预算内稳定；
- 非法 LayoutOutput 不修改 RangeModel，也不发 listener；
- synthetic feedback cycle 命中预算且不提交 partial frame；
- 同一 generation 的重复 work item 被合并；
- route-only dirty work 使 `has_pending_update` 为 true；
- 收敛失败时 render/listener 仍停留在上一 stable epoch；
- 唯一公开出版入口 `runtime.frames().prepare_submission(...)` 复用同一 stabilization 内核；测试级完整录制
  不形成第二套公开帧协议。

新增定向要求：连续 source 更新、布局约束变化、资源 revision 变化及过期候选拒绝；
外部 measurement/layout/presentation 共用版本合同；final presentation 失败不晋升
stable epoch。P2-S05 已证明嵌套布局盒模型和首帧 glyph/clip/damage 组合，不能据此推断
全部版本竞争和第三方失败场景已验收。

## 14. 共享场景捕获

[ADR-044](../../adr/adr-044-shared-scene-capture-and-view.md)允许
`Runtime::scenes().capture` 复用 `stabilize_for_query`，在 source 的稳定状态上独立录制。
该出口只返回受检 `SceneSnapshot`，不准备、推进或确认 surface frame，也不消费
damage、资源 pending log 和在途提交。

K07-1 使用通知队列的单调输入 serial 与宿主活动时间判断是否需要再次稳定化。
配置改变只重录当前稳定子树，不伪造 source mutation 或递增 source epoch。
队列克隆随原有派生事务保存和恢复，serial 耗尽时拒绝捕获；stable epoch 改为受检递增。

捕获配置、录制或资源闭包失败只拒绝该订阅的候选，并保留其他订阅的独立出口。
主窗口遇到同一 Figure 绘制错误仍拒绝自己的帧；第三方回调 panic 仍使 Runtime faulted。
失败输入不会自动无限重试，宿主需要新输入、配置变更或显式捕获驱动。
结构循环准入与目标端安装按 K07-2/K07-3 验收，不能从捕获通过推断已经完成。

## 15. 非目标

- 运行时可注册任意节点、任意边和任意 callback 的通用依赖 DAG scheduler；
- 多线程/worker layout；
- ShortestPath routing；
- 完整 TextFlow/富文本编辑；
- backend session、dispose/identity 与递归渲染性能修复，它们分别属于 D4.2-D4.5。
