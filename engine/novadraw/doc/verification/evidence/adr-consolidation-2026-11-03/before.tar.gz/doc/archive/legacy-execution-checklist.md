# Novadraw 执行清单

类型：`archive`

> **Legacy 文档**
>
> 本文记录 2026 年早期实现阶段的历史任务，不再表示当前项目进度，其中的
> Phase 编号和旧 M1-M9 编号均不得用于提交、设计或验收。
> 当前 M1-M10 的唯一入口是 `doc/roadmap/00-index.md`。

## 项目目标

实现类似 Eclipse Draw2D/GEF 的矢量图绘图引擎，参考 draw2d 架构设计，具有良好的扩展性。

---

## 当前架构

```
┌─────────────────────────────────────────────────────────────┐
│                      novadraw (workspace)                    │
├─────────────────────────────────────────────────────────────┤
│ Level 1: 核心库（无运行时依赖）                              │
│   ├── novadraw-math/  - Vec2, Vec3, Mat3, Rect, Transform  │
│   └── novadraw-core/  - Color, Id                          │
├─────────────────────────────────────────────────────────────┤
│ Level 2: 渲染层                                             │
│   └── novadraw-render/ - RenderCommand, NdCanvas, Vello    │
├─────────────────────────────────────────────────────────────┤
│ Level 3: 场景图（Draw2D 定位）                              │
│   └── novadraw-scene/  - Figure, FigureGraph, Viewport      │
├─────────────────────────────────────────────────────────────┤
│ Level 4: 编辑器（GEF 定位）                                 │
│   └── apps/editor/    - SceneManager, 事件处理              │
└─────────────────────────────────────────────────────────────┘
```

---

## 模块状态

| 模块 | 状态 | 说明 |
|------|------|------|
| novadraw-math | ✅ 完成 | Vec2, Vec3, Mat3, Rect, Transform, Translatable |
| novadraw-core | ✅ 完成 | Color |
| novadraw-render | ✅ 完成 | RenderCommand, NdCanvas, VelloRenderer |
| novadraw-scene | ✅ 完成 | Figure, RectangleFigure, FigureGraph, Viewport |
| apps/editor | ✅ 完成 | SceneManager, 事件处理 |

---

## 演进路线图

### Phase 0: 基础完善（当前）

**目标**：完善基础框架，为后续扩展打基础

| # | 任务 | 优先级 | 状态 |
|---|------|--------|------|
| 0.1 | Clip 裁剪验证 | P0 | ✅ 已验证 |
| 0.2 | Stroke/Fill 属性完善 | P1 | ✅ 已完成 |
| 0.3 | 坐标系统对齐 Draw2D | P1 | 见 `bounds-migration-plan.md` |
| 0.4 | UpdateManager 更新管理 | P0 | ✅ 已完成 |

---

### Phase 1: 基础 Figure 扩展

**目标**：补充常用图形类型（参考 g2 Figure 类型）

**g2 Figure 类型对比分析**：

| g2 图形类型 | 本项目实现 | 说明 |
|-------------|------------|------|
| RectangleFigure | ✅ RectangleFigure | 矩形 |
| Ellipse | ✅ EllipseFigure | 椭圆 |
| LineFigure | ✅ LineFigure | 直线 |
| Polyline | ⏳ | 多段线 |
| Polygon | ⏳ | 多边形（继承 Polyline） |
| RoundedRectangle | ⏳ | 圆角矩形 |
| Triangle | ⏳ | 三角形（可复用 Polygon） |
| Label | ⏳ | 文本标签（需文本渲染） |
| ImageFigure | ⏳ | 图像 |
| Connection | ⏳ | 连接线（需 ConnectionRouter） |

| # | 任务 | 优先级 | 状态 |
|---|------|--------|------|
| 1.1 | EllipseFigure（椭圆） | P1 | ✅ 已完成 |
| 1.2 | LineFigure（直线） | P1 | ✅ 已完成 |
| 1.3 | PolylineFigure（多段线） | P2 | ✅ 已完成 |
| 1.4 | PolygonFigure（多边形） | P2 | ✅ 已完成 |
| 1.5 | RoundedRectangleFigure（圆角矩形） | P2 | ✅ 已完成 |
| 1.6 | TriangleFigure（三角形） | P2 | ✅ 已完成 |
| 1.7 | PathFigure（贝塞尔路径） | P2 | ✅ 已完成 |

---

### Phase 2: Border 系统

**目标**：为 Figure 添加装饰器支持

| # | 任务 | 优先级 | 状态 |
|---|------|--------|------|
| 2.1 | Border trait | P1 | ⏳ |
| 2.2 | RectangleBorder | P1 | ⏳ |
| 2.3 | LineBorder | P1 | ⏳ |
| 2.4 | MarginBorder | P2 | ⏳ |

---

### Phase 3: 布局系统完善

**目标**：完善布局管理器

| # | 任务 | 优先级 | 状态 |
|---|------|--------|------|
| 3.1 | FlowLayout | P1 | ✅ 已完成 |
| 3.2 | BorderLayout | P2 | ✅ 已完成（已验证） |
| 3.3 | StackLayout | P2 | ⏳ |
| 3.4 | ToolbarLayout | P3 | ⏳ |

---

### Phase 4: 事件系统

**目标**：支持完整的事件处理

| # | 任务 | 优先级 | 状态 |
|---|------|--------|------|
| 4.1 | MouseEvent | P1 | ⏳ |
| 4.2 | KeyEvent | P2 | ⏳ |
| 4.3 | FocusEvent | P3 | ⏳ |
| 4.4 | FigureListener | P2 | ⏳ |

---

### Phase 5: 高级 Figure

**目标**：复杂图形类型

| # | 任务 | 优先级 | 状态 |
|---|------|--------|------|
| 5.1 | PathFigure（贝塞尔路径） | P2 | ⏳ |
| 5.2 | LabelFigure（文本标签） | P2 | ⏳ |
| 5.3 | ImageFigure（图像） | P3 | ⏳ |
| 5.4 | TextFigure | P3 | ⏳ |
| 5.5 | ConnectionFigure（连接线） | P2 | ⏳ |
| 5.6 | PolylineConnectionFigure | P2 | ⏳ |

---

### Phase 6: GEF 框架（编辑域）

**目标**：实现类似 GEF 的编辑框架

| # | 任务 | 优先级 | 状态 |
|---|------|--------|------|
| 6.1 | Command trait | P2 | ⏳ |
| 6.2 | CommandStack | P2 | ⏳ |
| 6.3 | EditPart trait | P2 | ⏳ |
| 6.4 | GraphicalEditPart | P2 | ⏳ |
| 6.5 | EditPolicy | P2 | ⏳ |
| 6.6 | SelectionEditPolicy | P2 | ⏳ |
| 6.7 | DragEditPolicy | P2 | ⏳ |
| 6.8 | Tool trait | P2 | ⏳ |
| 6.9 | SelectionTool | P2 | ⏳ |

---

### Phase 7: 编辑器工具

**目标**：完整的编辑器交互工具

| # | 任务 | 优先级 | 状态 |
|---|------|--------|------|
| 7.1 | RectangleCreationTool | P2 | ⏳ |
| 7.2 | EllipseCreationTool | P2 | ⏳ |
| 7.3 | LineCreationTool | P3 | ⏳ |
| 7.4 | PolylineCreationTool | P3 | ⏳ |
| 7.5 | PolygonCreationTool | P3 | ⏳ |
| 7.6 | MarqueeTool | P2 | ⏳ |

---

### Phase 8: 高级功能（后期）

| # | 任务 | 优先级 | 状态 |
|---|------|--------|------|
| 8.1 | ConnectionEditPart | P3 | ⏳ |
| 8.2 | ConnectionRouter（路径路由器） | P3 | ⏳ |
| 8.3 | BendpointConnectionRouter | P3 | ⏳ |
| 8.4 | ManhattanConnectionRouter | P3 | ⏳ |
| 8.5 | ShortestPathConnectionRouter | P3 | ⏳ |
| 8.6 | ZoomUI | P3 | ⏳ |
| 8.7 | AlignmentSolver | P3 | ⏳ |

---

## 渲染验证结果

验证 Trampoline 渲染循环的正确性。

| 场景 | 验证目标 | 结果 |
|------|----------|------|
| 1 | 嵌套父子：parent.PaintBorder 在子节点后执行 | ✅ |
| 2 | Z-order：后添加的遮挡先添加的 | ✅ |
| 3 | 不可见：hidden 节点不产生命令 | ✅ |
| 4 | 选中高亮：highlight 在 border 之后 | ✅ |
| 5 | Clip 裁剪：子元素超出父边界被正确裁剪 | ✅ 已验证 |

---

### Phase 9: 性能优化

**目标**：优化大规模图形的渲染和交互性能

| # | 任务 | 优先级 | 状态 | 说明 |
|---|------|--------|------|------|
| 9.1 | R-Tree 空间索引 | P2 | ⏳ | hit_test/视锥裁剪加速，O(n) → O(log n) |
| 9.2 | 脏区域跟踪 | P2 | ⏳ | 增量渲染，只重绘变化区域 |
| 9.3 | DisplayList 缓存 | P3 | ⏳ | 保留模式下缓存渲染指令 |

---

### Phase 9 详解

#### 9.1 R-Tree 空间索引

**背景**：当前 `hit_test` 使用全量遍历 O(n)，大量图形时性能差

**实现方案**：

- 在 `FigureGraph` 中添加 `spatial_index` 字段
- 存储 Figure 的 bounds（相对最近坐标根的绝对值）
- 查询时：平台输入 → 入口域逻辑坐标 → 按父链降域/索引查询 → contains_point 精确检测

**增量添加，不影响现有 API**：

```rust
// 添加到 FigureGraph
pub struct FigureGraph {
    // ... 现有字段
    spatial_index: Option<RTree<SpatialEntry>>,  // 新增
}

// 修改 hit_test 实现
pub fn hit_test(&self, point: (f64, f64)) -> Option<BlockId> {
    // 1. R-Tree 快速初筛（返回候选）
    // 2. contains_point 精确确认
}
```

**更新时机**：

| 操作 | R-Tree 变化 |
|------|-------------|
| add_child_to | 插入 |
| prim_translate | 更新 |
| set_bounds | 更新 |
| delete | 删除 |
| viewport 变化 | **不需要** |

**推荐 crate**：`rstar`（Pure Rust）

---

## 已删除功能

以下功能已移除或延后：

| 功能 | 原因 |
|------|------|
| novadraw-gef crate | 需评估是否独立，或合并到 novadraw-scene |
| Region 数据结构 | Vello 内置区域处理 |
| 脏矩形跟踪 | Vello 增量渲染支持 |
| QuadTree | 当前规模不需要 |
| LOD 细节层次 | 后期优化 |
| Tile 纹理缓存 | 后期优化 |
| SVG/PDF 导出 | 后期实现 |
| image crate 图像 | 后期实现 |

---

## 技术选型

| 模块 | 技术选型 |
|------|----------|
| 窗口管理 | winit |
| 渲染引擎 | Vello |
| 数学库 | glam |
| 渲染目标 | WebGPU |

---

## 快速开始

```bash
# 运行编辑器
cargo run -p editor

# 运行测试
cargo test --workspace
```

---

## 里程碑

| 里程碑 | 状态 | 说明 |
|--------|------|------|
| M1 | ✅ | 基础框架：math, core, render, scene |
| M2 | ✅ | 渲染管线：Vello, NdCanvas |
| M3 | ✅ | 场景图：Figure, FigureGraph, Viewport |
| M4 | ✅ | Clip 裁剪：paintChildren 实现 |
| M5 | ✅ | 基础 Figure：Ellipse, Line |
| M6 | ⏳ | Border 系统 |
| M7 | ✅ | 布局系统：FlowLayout, BorderLayout |
| M8 | ⏳ | GEF 框架：Command, EditPart |
| M9 | ⏳ | 编辑器工具 |
