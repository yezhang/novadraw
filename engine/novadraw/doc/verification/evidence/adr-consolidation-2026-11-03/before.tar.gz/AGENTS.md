# AGENTS.md

## 角色定位

本文件是本仓库的启动宪法（bootstrap contract），用于所有 Agent 的首次进入与快速对齐。

- `AGENTS.md`：启动门禁、关键事实镜像、跨 Agent 最小约束。
- `CLAUDE.md`：完整规则手册与项目级唯一真源（SSOT）。
- `project_memory.md`：跨会话兜底记忆，保存高价值项目事实与长期约定。

如使用 Claude Code、Cursor、OpenCode、Zed 等任何 Agent 工具，均应先遵循本文件，再继续读取 `CLAUDE.md`。

## 启动门禁

首次进入仓库或开始新任务时，必须按以下顺序执行：

1. 先读取 `AGENTS.md`。
2. 若仓库根目录存在 `CLAUDE.md`，必须继续读取 `CLAUDE.md`，再开始分析、设计或实现。
3. 若任务涉及架构、g2/GEF 对标、第三方源码分析或历史决策，必须补充读取项目记忆（如 `project_memory.md`）。

未完成上述启动步骤前，不应假定自己已经掌握项目上下文。

## 启动检查清单

- [ ] 已读取 `AGENTS.md`
- [ ] 已读取 `CLAUDE.md`
- [ ] 已确认本次任务是否允许扫描本项目现状实现
- [ ] 已确认第三方参考源码路径
- [ ] 已确认本次任务的 SSOT 文档或代码入口

## 关键事实镜像

以下信息同时属于启动阶段必须掌握的关键事实，即使完整定义在 `CLAUDE.md` 中，也在此镜像一份，避免遗漏：

### 参考源码路径

- draw2d/GEF: `/Users/bytedance/Documents/code/GitHub/gef-classic`
- 可运行的 Draw2D 参考样例：`third_party/draw2d-examples/`；仅用于行为核验，不属于
  Novadraw 一方示例或实现源码
- 对标范围严格限定为该仓库中的 `org.eclipse.draw2d` 与 `org.eclipse.gef` 包；
  `org.eclipse.zest` 是基于 Draw2D 的上层扩展，不得作为 Novadraw 的需求语义、
  架构设计或实现逻辑参考
- SWT GC: `/Users/bytedance/Documents/code/GitHub/eclipse.platform.swt`
- vello: `/Users/bytedance/Documents/code/GitHub/vello`
- Parley 0.7.0 生产补丁：`dependencies/parley-0.7.0/`；独立第三方依赖，
  不属于一方 workspace，来源和本地修改见 `dependencies/README.md`。
- xilem: `/Users/bytedance/Documents/code/GitHub/xilem`
- Zed: `/Users/bytedance/Documents/code/GitHub/zed`

### 文档入口

- 目录归属与构建入口：`README.md`；库源码统一位于 `crates/`，
  跨包测试位于 `tests/`，脚本位于 `tools/scripts/`。
- 样例按能力归属维护：Core 在 `crates/novadraw/examples/`，Editor 在
  `crates/novadraw-editor/examples/`；跨层集成、后端样例与共享宿主工具在根
  `examples/`。完整应用保留独立 Cargo package，导航见 `examples/README.md`。
- 历史证据：`doc/verification/evidence/`；独立字体比较报告及原始 GPU demos：
  `doc/reference/fonts/reports/`。内部历史路径与原始字节保持不变。
- 文本性能验证中间产物（日志、样本、收据、生成快照）放在
  `target/verification/text-*/`，不纳入 Git；`doc` 只保留报告和本地产物指引。
- 项目文档总入口：`doc/00-index.md`
- 文档知识归属、替代与原始证据保护：`doc/knowledge-maintenance.md`
- 完整项目规则：`CLAUDE.md`
- **Draw2D API 语义覆盖账本**：`doc/parity/draw2d/api-coverage.md`
- **产品交付清单 / Demo 矩阵**：`doc/roadmap/`
  - M1-M10 编号与状态入口：`doc/roadmap/00-index.md`
- **Editor / GEF 路线图**：`doc/roadmap/editor/00-index.md`
- **Editor 架构 SSOT**：`doc/design/editor/architecture.md`
- **Core 公开 API 边界**：`doc/adr/adr-017-core-public-api-boundary.md`
- **Runtime 驱动与结构化测量 API**：
  `doc/adr/adr-018-runtime-driving-and-measurement-api.md`
- **公开 Facade 与 Feature 边界**：
  `doc/adr/adr-021-public-facade-and-feature-boundary.md`
- **第三方类型与渲染依赖边界**：
  `doc/adr/adr-022-third-party-type-and-render-dependency-boundary.md`
- **Crate 收口与扩展边界**：
  `doc/adr/adr-023-crate-consolidation-and-extension-boundaries.md`
- **统一 Graphics 与 glyph 预处理边界**：
  `doc/adr/adr-025-unified-graphics-and-glyph-preparation.md`；
  字体指标、文字测量与图文绘制统一 API，布局后曲线预处理与片段着色器数据归后端；
  已接受并完成 P2-G02 Core API 与默认/可替换轮廓链路；自研后端算法不属于当前交付
- **类型化属性身份与异构通知日志**：
  `doc/adr/adr-028-typed-property-identity.md`；属性行为身份使用
  `PropertyKey<V>` / `ErasedPropertyKey`，字符串只用于诊断显示
- **Core 公开 API 审计**：`doc/verification/reviews/core-public-api-audit-2026-09-22.md`
- **语义审计整改状态**：`doc/verification/reviews/draw2d-gef-semantic-remediation-2026-09-16.md`
- **可执行验证入口**：`tests/README.md` 与 `cargo xtask list`
> 推进 M1-M10 的 architecture/parity delta 时，必须检查对应 `api_semantics` 的 Draw2D API 语义是否完整；语义账本见 `doc/parity/draw2d/api-coverage.md`。

### 当前执行门禁

- 2026-10-02 起优先推进框架核心架构与 API 的灵活、扩展和稳定；以已完成的
  GA-1/GA-4 为基础，已完成 S01–S08 的既定切片；S08-A／B／C／D 已完成，
  输入不变量审计项已关闭；ADR-057 修订 3 已于 2026-10-30 接受，S09-A Core
  Animation、S09-B Observations／Inspector 与 S09-C Core Connections 已完成，
  S09-D Editor 扩展错误与 panic 诊断已实现并通过定向验证，最终门禁因磁盘
  空间不足待补验，S09 整批保持未关闭；Inspector 成本证据覆盖容量
  64／4096，不代表引擎最大容量验收。Editor 开放吸附
  ADR-058 修订 2 已于 2026-11-02 复核通过并获用户条件授权，移动／创建／单源
  resize 已实现并通过定向验证；六组无窗口成本采样完成，校验成本整改提案待评审，
  10000 sibling 的完整 release 受默认 validation 预算阻塞，E04 保持未关闭。
  当前执行队列只在 `doc/roadmap/p2-delta-backlog.md` 维护。
  WindowServer/Chrome 性能采证及 Windows/Linux 原生 runner 验收后置到发布准备，
  保留未完成状态，不阻塞平台无关 Core 开发；当前顺序以
  `doc/roadmap/goal-alignment-adjustment-plan-2026-09-30.md` 为准。
- M1-M10、D3.1-D3.4 与 D4.1-D4.6 已完成；最近一次长期架构审计的 A01-A08 已关闭。
- 2026-09-13 macOS/Web/Headless 总审计与 R9.4 capability 消融复查通过，Draw2D
  Core 1.0 完成。Editor framework 已按 ADR-015 完成独立 G0-G5 roadmap，G0 架构启动与
  G1 Model Adapter/CommandStack、G2 EditPart Tree/Viewer 投影、G3
  Selection/Targeting/Input Arbitration、G4 Tool/Request/EditPolicy、G5.1
  Connection Projection、G5.2 Connection Creation 与 G5.3 Connection Reconnect
  已完成，G5.4 Connection Bendpoint 与 G5.5 Viewport/Auto-expose 自动门禁已完成；
  检查点 B 与检查点 C 已通过人工验收。
  Draw2D 后续能力必须进入明确的 P2 delta。
- Core 公开 API 的 P0 Batch A/B 已按 ADR-017 完成；Runtime 驱动、坐标查询和
  Layout measurement 已按 ADR-018 收口；detached 构造与挂载后 scoped editor
  调用面已按 ADR-019 收口；Color、Render IR 与 Geometry 基础值已按 ADR-020 收口；
  公开 API 分层已按 ADR-021 收口；Core、Editor、Inspector、Vello backend 与平台
  adapter 的 package 边界已按 ADR-023 收口。Graphics 已按 ADR-025/031 统一，
  Figure capability 已按 ADR-027 收口；公开路径、统一 mutation 和查询失败分别由
  ADR-033/035/038 细化。P2-R02 image source rectangle 已完成。
  原 G6 的 schema、serializer 和产品级 Native/Web 场景已移交独立产品包，不再作为
  本仓库引擎门禁。
- 2026-09-16 全量 Draw2D/GEF 语义审计及 2026-09-20 后续批次的 22 条 P1
  已全部关闭；18 条次级候选保留待定向验证，状态以
  `doc/verification/reviews/draw2d-gef-semantic-remediation-2026-09-16.md` 为准。
- 2026-09-10 架构修订以 `doc/adr/adr-014-extensibility-and-lifecycle-boundaries.md`
  为准；ADR-013 已替换。D4.3-D4.6 门禁已完成，新设计不等于已实现。
- 默认架构检索排除 `doc/archive/`；旧 ADR 全文只供显式历史追溯，不能用于当前设计。
  审计入口：`doc/verification/reviews/adr-audit-2026-09-10.md`。

### 架构分析边界

- 普通设计方案默认放在 `doc/design/`，按主题命名，不分配 ADR 编号；
  方案可以独立评审、接受，评审通过不要求配套 ADR。只有影响长期架构边界的
  重要选择才单独记录 ADR，说明理由、替代方案与代价；设计与 ADR 无需一一对应。
  修改公开 API、新增能力、性能优化或篇幅较大本身均不构成创建 ADR 的理由。
  完整规则见 `CLAUDE.md` 的“设计方案与 ADR 的使用边界”。
- 规划、ADR、方案及验证文档必须在开头明确 Core／Editor／其他 owner；
  跨层方案逐项区分能力、API／状态归属、依赖、改动与验收。
  Editor 使用 Core 基础协议不改变能力归属；新增 Core 能力单列 delta。
  用户指定 Editor／GEF 范围时，只推进该范围；Core 整改与应用功能不计为
  新增 GEF 能力。完整规则见 `CLAUDE.md` 的“规划与方案必须明确能力归属”。
- Editor 是否缺失必要 Core 依赖，必须以 GEF 对 Draw2D 对等契约的实际依赖为依据，
  记录 GEF 行为／源码 → Draw2D 契约 → Core 等价能力与缺口的证据链。
  确认缺失后停止增加 Editor 能力，先给出独立 Core 增补建议与恢复条件；
  不在 Editor／应用层复制基础机制绕过依赖，不把测试注入或平台采证缺口
  当作 Core 能力缺失。完整规则见 `CLAUDE.md` 的“Editor 缺失 Core 依赖时停止新增”。
- 官方示例迭代只建设 Canvas / LightweightSystem 内的 Draw2D 能力。Java 源码仅供
  只读参考，不编写、修改、编译或运行 Java 验证代码；不建设 SWT 原生控件的
  Novadraw 替代体系。示例临时控制面板允许用于过渡/验证，不作为 Core 演进目标。
  Canvas 内真正的 Draw2D Figure 组件仍在范围内。当前计划见
  `doc/verification/plans/draw2d-official-examples-core-plan.md`。
- 架构设计优先从需求、第一性原理、draw2d/GEF 参考源码出发。
- 第三方源码分析仅对标 `org.eclipse.draw2d` 与 `org.eclipse.gef`；不得用
  `org.eclipse.zest` 的源码或行为作为 Novadraw 的需求、语义、架构或实现依据。
  扩展能力必须直接从 Draw2D/GEF 的基础契约和扩展点确认。
- 若任务是“理想架构设计”，禁止先扫描本项目实现，以避免现状偏差。
- 若任务是“实现修复或落地”，必须先明确目标契约，再审阅本项目代码。
- 架构设计保持扩展性与稳定性优先，同时评估性能。性能是项目核心竞争力，
  渲染、布局、命中和交互响应成本必须进入方案，不能等实现完成后才考虑。
- 只有用户明确要求对比产物体积时，才执行产物体积分析、测量和比较。
  日常功能补充不自动构建体积探针、比较 Native／Wasm 或原始／压缩大小，
  不把体积采证作为功能迭代门禁。此约定覆盖既有 ADR、计划和验收清单中的
  自动体积比较要求；完整规则见 `CLAUDE.md` 的“包体积与性能要求”。

## 核心规则

| 规则 | 说明 |
|------|------|
| 树遍历 | 递归深度限制 10,000 层；性能专项开始前不得重新引入迭代渲染主线 |
| 禁止临时方案 | 问题必须从根因解决 |
| 禁止全局状态 | 不使用 Singleton |
| 渲染热路径 | 不打印日志 |
| 渲染主循环保护 | 当前主线只保护 `crates/novadraw/src/graph/render_recursive.rs`；`render_iterative.rs` 已归档到 tag `archive/render-iterative-poc-20260617` |
| 硬编码 | 业务代码中不使用 magic numbers |
| 通用机制分层 | 事件分发、坐标转换、事件点适配、通用上下文必须放在引擎层，examples 只做平台输入适配与示例编排 |
| 第三方类型边界 | backend-neutral 公共签名不得暴露 Kurbo、Vello 或 Winit 类型 |
| 内置与扩展同模型 | 内置能力只是"提前实现的代码"，不是特权路径；Request/Tool/Handle/Capability/Binding/Layout/Figure 等必须统一走 typed identity + payload trait + registry，禁止为内置能力保留闭合枚举、typed-only hook 或 fast path；涉及扩展能力的设计需说明"外部消费者证据"，不要求为此新增 ADR |
| Git 提交 | 标题统一为 `type(scope): 中文摘要`；type/scope 必填且使用小写英文，半角冒号后一个空格；按主题保持原子化，详见 `CLAUDE.md` 的 Git 提交规范 |

## 项目特性

- **语言**: Rust (Edition 2024)
- **渲染**: Vello (WebGPU)
- **构建**: `cargo build && cargo test`
- **分层门禁**: 修改内环使用 crate `--lib` 或单个 `--test` 的 check/Clippy/精确测试，
  不使用 `--tests`、`--all-targets` 扫描无关目标；跨工具功能切片运行对应 xtask
  suite。同类整改批次直接运行 workspace fmt/check，最终边界直接运行 workspace
  fmt、Clippy 与 test，不再通过 xtask 包装标准 Cargo 命令
- **公开包**: `novadraw` Core、`novadraw-editor`、`novadraw-inspector`、
  `novadraw-backend-vello`、`novadraw-platform-winit`、`novadraw-platform-web`
- **独立 UI 组件**：`winit-canvas` 不依赖 Novadraw/Vello，使用 winit 类型与可选
  WGPU 实现窗口内 Canvas；不属于 backend-neutral Core。
  接入与验证入口见 `crates/winit-canvas/README.md`，Novadraw 离屏接入在
  `novadraw-backend-vello::texture`。
- **Canvas 宿主桥接**：`novadraw-platform-winit` 的可选 `canvas` feature 提供
  `canvas::WinitCanvasHost` 与 `WinitCanvasCoordinator`，按区域协调 Host 服务；
  原 `WinitPlatformHost` 保留整窗语义，接入见 `crates/novadraw-platform-winit/README.md`。
- **3D 边界**: 保留独立 Scene3D / Projective3D 扩展契约；真实用例出现前不建设空 crate

## 交互方式原则（摘要）

> 详细版见 `CLAUDE.md` 的“交互方式”章节；此处为跨 Agent 的关键摘要，确保不同工具保持一致行为。

### 思维原则

- 使用第一性原理推导；不盲从经验与路径依赖。
- 可以采用苏格拉底提问法和奥卡姆剃刀原理。
- 需求不明确时先澄清，再执行；目标清晰但路径低效时提出更优方案。

### 交互模式

- 默认直接推进用户目标：读取必要上下文、定位问题、实现修改、运行验证，并给出清晰结果。
- 不要求每次回复固定拆分为“直接执行 / 深度交互”。
- 深度交互仅在能降低误解、架构偏移或长期维护风险时主动展开。
- 简单问答 / 小修改直接完成；Bug 修复先定位根因再修复验证；新功能先定义契约再测试实现；架构设计先澄清目标与约束。
- 大范围或高风险修改遵循 Explore → Plan → Gate → Execute → Verify → Review。
- 验证成本随风险逐级提升；不得在每个小修改后重复运行 workspace 全量门禁。

### 深度交互触发条件

- 用户目标不清晰，可能存在 XY 问题。
- 当前做法会破坏项目长期架构。
- 存在多条路径且代价差异明显。
- 修改超过单一模块或超过 50 行。
- 涉及渲染主循环、坐标协议、事件分发、UpdateManager 等核心契约。

### 行为准则

- 重大架构变更：先评审方案，获批后实施。
- Bug 修复：先定位根因并说明，再提交修复。
- 代码改动：超过 50 行应分步提交，保持粒度清晰。
- 新增功能：先定义接口契约，再迭代实现细节。
- 性能优化：提供基准数据或统计支撑（前后对比）。

### 核心禁止事项（复述）

- 递归遍历深度上限 10,000 层；性能专项开始前不得重新引入迭代渲染主线。
- 禁止临时方案与“先糊后修”，必须从根因解决。
- 禁止全局状态（Singleton）。
- 渲染热路径禁止打印日志。
- `render_recursive.rs` 是当前渲染主循环保护区，通常不应改主循环逻辑；`render_iterative.rs` 为历史 POC，已从主线删除并归档到 tag `archive/render-iterative-poc-20260617`。
- 递归渲染在 M1-M10 核心契约完备前，不得恢复迭代渲染入口、I 键切换或递归/迭代等价门禁。
- 禁止 magic numbers（硬编码）。
- 禁止把内置能力建成特权路径：Request/Tool/Handle/Capability/Binding/Layout/Figure 等必须内置与扩展共用同一 typed identity + payload trait + registry，不得为内置保留闭合枚举、typed-only hook 或 fast path。
- Git 提交标题统一为 `type(scope): 中文摘要`，不得使用纯中文标题、
  `文档：…`、省略 scope 或全英文摘要；type/scope 必填且使用小写英文，
  分隔符为半角冒号加一个空格，按主题保持原子化。完整规则以
  `CLAUDE.md` 的“Git 提交规范”为准。

## 三层信息分工

为避免关键信息只存在于单一文档，约定如下：

### AGENTS.md 负责什么

- 启动门禁
- 必读文件顺序
- 关键事实镜像
- 跨 Agent 最小行为约束

### CLAUDE.md 负责什么

- 完整规则说明
- 详细开发流程
- 架构设计原则
- 提交、调试、实现细则

### project_memory.md 负责什么

- 跨会话仍需保留的高价值事实
- 容易遗漏但会显著影响判断的路径、约束与长期决策
- 不适合塞进启动摘要、但又不能依赖短期会话记忆的项目背景

## 维护规则

- 若某条信息会影响“搜索范围、源码定位、设计结论、任务边界”，则不得只存在于 `CLAUDE.md`。
- 这类信息至少应在 `AGENTS.md` 中保留摘要镜像，并在需要时同步到 `project_memory.md`。
- 若 `AGENTS.md` 与 `CLAUDE.md` 存在冲突，以 `CLAUDE.md` 为唯一真源（SSOT）。
- 若 `AGENTS.md` 未明确要求读取 `CLAUDE.md`，应视为配置缺陷而非可忽略项。
