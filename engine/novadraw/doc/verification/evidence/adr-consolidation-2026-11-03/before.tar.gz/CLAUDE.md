# Novadraw 图形工具包

## 项目概述

使用 Rust + WebGPU 技术栈实现的高性能绘图引擎工具包，参考 eclipse draw2d/GEF 架构设计，目标是扩展为通用图形框架。

### 技术栈

- **渲染后端**: vello (WebGPU)
- **窗口/事件**: winit
- **文本布局**: Parley
- **文本渲染**: Vello glyph runs
- **构建工具**: cargo

### 模块结构

```text
crates/novadraw/                 - 平台无关 Core、几何、Render 协议、Figure/Runtime
crates/novadraw-backend-vello/   - Vello 渲染后端
crates/novadraw-platform-winit/  - Winit 平台适配
crates/novadraw-platform-web/    - Web 平台适配
crates/novadraw-editor/          - GEF 风格模型、命令历史、EditPart 与 Viewer 投影
crates/novadraw-inspector/       - 只读诊断与观测
crates/winit-canvas/             - 独立 winit Canvas UI 组件，不依赖 Novadraw/Vello
crates/novadraw/examples/native/ - Core 桌面示例，保留独立 Cargo package
crates/novadraw/examples/scenes/ - Core Native/Web 共用的无平台场景
crates/novadraw-editor/examples/ - Editor 示例，保留独立 Cargo package
examples/integration/           - Core/Editor/平台等跨层集成示例
examples/backend/               - 渲染后端示例
examples/support/               - 示例共享宿主与工具
benchmarks/                     - 无窗口性能基线
tests/                          - 跨包消费者、oracle 资料与公开 API 快照
tools/xtask/                    - 专项验收与文档门禁
tools/scripts/                  - 构建、浏览器验收和性能采样脚本
doc/verification/evidence/      - 保持原始内容的历史证据
doc/reference/fonts/reports/    - 独立字体报告及原始 GPU demos
target/                         - 构建产物、日志、截图与本地采样输出
dependencies/                   - 经批准的生产第三方依赖补丁，不属于一方 workspace
```

完整目录归属见 [README.md](README.md)。库包名与 Cargo 命令不因目录迁移改变。
样例按主要展示的能力归属到对应 crate，平台作为第二层分类；跨层集成和共享宿主
工具留在根 `examples/`。完整应用保留独立 workspace package，不将 GUI 依赖
加入 Core／Editor 的 `dev-dependencies`；全仓库入口见 [样例导航](examples/README.md)。
原始证据和独立报告整体迁移时核对 SHA-256，内部历史路径不作改写。
文本性能验证的日志、样本、收据和生成快照属于本地中间产物，统一放在
`target/verification/text-*/`，不纳入 Git。`doc` 只保留报告和本地产物指引；
迁移时核对 SHA-256，冻结收据中的历史路径不作改写。

`winit-canvas` 使用 winit 类型与可选 WGPU，不属于 backend-neutral Core。
Novadraw 渲染通过 `novadraw-backend-vello::texture` 在消费者侧接入，
不得将 Novadraw 或 Vello 依赖加回 Canvas 库。契约与验证入口见
`crates/winit-canvas/README.md`。
`novadraw-platform-winit` 的可选 `canvas` feature 单向依赖 `winit-canvas`，
提供 `canvas::WinitCanvasHost` 与 `WinitCanvasCoordinator`。原 WinitPlatformHost
保留整窗语义；子 Canvas 接入见 `crates/novadraw-platform-winit/README.md`。

## 核心禁止事项

- **递归深度限制**：树遍历允许使用递归，深度上限 10,000 层；性能专项开始前不得重新引入迭代渲染主线
- **禁止临时方案**：问题必须从根因解决
- **禁止全局状态**：不使用 Singleton
- **禁止热路径日志**：渲染循环中不打印日志
- **禁止 magic numbers**：业务代码中不使用硬编码数字
- **迭代渲染归档**：`render_iterative.rs`、`use_iterative_render` 和 I 键切换已从主线移除；历史 POC 归档在 git tag `archive/render-iterative-poc-20260617`
- **保护渲染主循环**：`crates/novadraw/src/graph/render_recursive.rs` 是当前 Draw2D 渲染主流程承载点，通常不应修改主循环逻辑；除非已对标 draw2d 证明当前主流程与 draw2d 不符，否则问题应优先定位到 Figure 协议、坐标转换、NdCanvas 命令、Vello 后端或调用路径
- **禁止提前恢复迭代渲染**：递归渲染在 M1-M10 核心契约完备前，不得把迭代渲染重新接入代码主线；未来仅能作为性能专项 delta 从归档 tag 恢复并重新设计
- **通用机制下沉引擎层**：事件分发、坐标转换、target/source Figure 事件点适配、通用上下文等机制必须位于 `novadraw` Core，`examples/*` 只做平台输入适配与示例编排
- **第三方类型不得穿透公共契约**：backend-neutral 公共签名不得暴露 Kurbo、Vello 或 Winit 类型；Kurbo 只按 Geometry 私有实现、Render IR 私有算法和 Vello lowering 三类归属

## 分层验证与提交门禁

验证成本必须随变更风险逐级提升，不得在每个小修改后重复执行 workspace 全量门禁：

1. **修改内环**：先运行受影响 crate 的 `cargo check -p <crate> --lib`；涉及单个
   integration target 时使用 `cargo check -p <crate> --test <target>` 或直接运行该
   精确定向测试。内环不得使用 `--tests` 或 `--all-targets` 扫描无关测试目标。
   Clippy 同样先限定为 `--lib` 或受影响的 `--test <target>`。
2. **功能切片完成**：先运行 `cargo xtask verify <suite-id>` 对应的契约或应用门禁；
   只有修改共享行为、跨多个 integration target 或定向 suite 覆盖不足时，再运行受影响
   crate 的完整测试。suite 已包含的相同命令不得紧接着手工重复执行。
3. **同类整改批次完成**：运行 `cargo fmt --all -- --check` 和
   `cargo check --workspace`。
4. **最终提交、推送、合并或里程碑关闭前**：运行一次 workspace fmt、
   `cargo clippy --workspace -- -D warnings` 和 `cargo test --workspace`。

`cargo fmt --all` 成本较低，但只在一个连贯编辑批次结束或提交前运行一次；不要在每个
小补丁后重复格式化并触发后续目标重编译。多个验证命令应从低成本到高成本顺序执行，
前一层失败时先修复，不继续启动更宽的门禁。

若精确定向 `cargo check` 长时间处于低 CPU 等待，先用
`cargo clean -p <crate> --dry-run` 检查包级缓存；只有确认出现异常数量或体积的增量
产物时，才执行一次 `cargo clean -p <crate>`。不得把 clean 放入常规验证脚本。

纯文档变更默认只运行：

```bash
cargo xtask docs
git diff --check
```

修改 workspace/Cargo 配置、feature、公共跨 crate API、build script 或其他高扩散边界时，
应提前提升到 workspace quick gate；只有在最终交付边界或定向验证无法覆盖风险时才提前
运行 full gate。不得连续组合 `cargo test -p <crate> --lib` 与
`cargo test -p <crate> --tests` 造成重复执行；需要完整 crate 验证时直接运行
`cargo test -p <crate>`。

跨工具 suite 由 xtask 维护，当前入口见 `tests/README.md` 和
`cargo xtask list`。`cargo xtask docs` 只检查 Markdown 类型、本地链接、当前命令引用、
设计索引与 parity 状态，不编译 Rust。普通 Cargo 命令直接执行，不在 xtask 中建立别名。
`cargo fmt --all` 会递归扫描 path 依赖。生产第三方补丁在 `dependencies/`
保留上游格式；新增本地 Rust 模块另用 `rustfmt --config disable_all_formatting=false`
定向检查，不将第三方格式重写混入功能补丁。维护入口为 `dependencies/README.md`。

## Git 提交规范

所有 Agent 新建的提交标题统一采用 Conventional Commits 格式：

```text
type(scope): 中文摘要
```

- `type` 与 `scope` 必填，使用小写英文；摘要必须用中文，源码标识符和产品名可保留英文。
- 分隔符必须为半角冒号和一个空格 `: `。不得混用纯中文标题、
  `文档：…`、省略 scope 的 `feat: …` 或全英文摘要。
- `type` 按变更性质选择：`feat` 新增功能、`fix` 修复问题、`refactor` 重构、
  `perf` 性能优化、`docs` 文档、`test` 测试、`build` 构建与依赖、
  `ci` 自动化流程、`chore` 其他维护、`revert` 回退。
- `scope` 表示主要影响的领域或模块，例如 `core`、`layout`、`input`、
  `render`、`winit-canvas`、`platform-winit`、`examples`、`architecture`、
  `adr`、`review`、`book`、`config`；新增作用域沿用小写英文与连字符命名。
- 摘要直接说明具体改动，不写“更新代码”“一些修改”等泛化描述。
- 提交按主题拆分，保持原子化；不得为满足一个 scope 而把无关改动合并。
  同一主题跨模块时，选择主要职责的 scope，其他影响在正文中说明。
- 需要正文时，标题后空一行，按实际需要说明原因、关键边界和验证结果。
  破坏兼容性的变更使用 `type(scope)!: 中文摘要`，
  并在正文末尾以 `BREAKING CHANGE: 中文说明` 写明迁移要求。
- 每次提交前核对暂存文件与主题、标题格式、摘要语言及对应验证结果。
  提交后读取 Git 中实际保存的标题；不得因历史提交格式不一致而沿用旧格式。

有效示例：

```text
feat(platform-winit): 新增 WinitCanvasHost 与多画布服务协调
fix(examples): 修复双 Canvas 样例窗口缩放抖动
docs(architecture): 记录 TextFlow 性能优化提案
test(winit-canvas): 覆盖跨画布捕获与焦点切换
```

## Skills 与文档

### 可用 Skills

- `/analyzing-gef-code` - 分析 draw2d/GEF 源码
- `/analyzing-xilem-code` - 参考 xilem GUI 框架
- `/analyzing-swt-code` - 分析 SWT GC 底层 API
- `/novadraw-impl` - 项目实现指导
- `/code-review` - 代码审查
- `/simplify` - 代码简化审查

### 详细文档

完整文档见 [doc/00-index.md](doc/00-index.md)。
知识归属、替代、链接维护与原始证据保护见
[文档知识维护](doc/knowledge-maintenance.md)。

| 场景 | 文档 |
|------|------|
| Draw2D 参考 | [doc/reference/draw2d/00-index.md](doc/reference/draw2d/00-index.md) |
| Novadraw 架构设计 | [doc/design/architecture/00-index.md](doc/design/architecture/00-index.md) |
| Novadraw 坐标契约 | [doc/design/coordinates/coordinate-system.md](doc/design/coordinates/coordinate-system.md) |
| 路线图（Core + Editor） | [doc/roadmap/00-index.md](doc/roadmap/00-index.md) |
| Editor / GEF 架构 | [doc/design/editor/architecture.md](doc/design/editor/architecture.md) |
| Editor / GEF 路线图 | [doc/roadmap/editor/00-index.md](doc/roadmap/editor/00-index.md) |
| Core 公开 API 边界 | [doc/adr/adr-017-core-public-api-boundary.md](doc/adr/adr-017-core-public-api-boundary.md) |
| Runtime 驱动与结构化测量 API | [doc/adr/adr-018-runtime-driving-and-measurement-api.md](doc/adr/adr-018-runtime-driving-and-measurement-api.md) |
| 公开 Facade 与 Feature 边界 | [doc/adr/adr-021-public-facade-and-feature-boundary.md](doc/adr/adr-021-public-facade-and-feature-boundary.md) |
| 第三方类型与渲染依赖边界 | [doc/adr/adr-022-third-party-type-and-render-dependency-boundary.md](doc/adr/adr-022-third-party-type-and-render-dependency-boundary.md) |
| Crate 收口与扩展边界 | [doc/adr/adr-023-crate-consolidation-and-extension-boundaries.md](doc/adr/adr-023-crate-consolidation-and-extension-boundaries.md) |
| 统一 Graphics 与 glyph 预处理边界 | [ADR-025](doc/adr/adr-025-unified-graphics-and-glyph-preparation.md) |
| 类型化属性身份与异构通知日志 | [ADR-028](doc/adr/adr-028-typed-property-identity.md) |
| Core 公开 API 审计 | [doc/verification/reviews/core-public-api-audit-2026-09-22.md](doc/verification/reviews/core-public-api-audit-2026-09-22.md) |

### Milestone 与路线图

2026-10-02 起优先推进框架核心架构与 API 的灵活、扩展和稳定；以已完成的
GA-1/GA-4 为基础，S01–S08 的既定切片已完成；S08-A／B／C／D 已完成，
输入不变量审计项已关闭；ADR-057 修订 3 已于 2026-10-30 接受，S09-A Core
Animation、S09-B Observations／Inspector 与 S09-C Core Connections 已完成，
S09-D Editor 扩展错误与 panic 诊断已实现并通过定向验证，最终门禁因磁盘
空间不足待补验，S09 整批保持未关闭；Inspector 成本证据覆盖容量
64／4096，不代表引擎最大容量验收。Editor 开放吸附
ADR-058 修订 2 已于 2026-11-02 复核通过并获用户条件授权，移动／创建／单源
resize 已实现并通过定向验证；六组无窗口成本采样完成，校验成本整改提案待评审，
10000 sibling 的完整 release 受默认 validation 预算阻塞，E04 保持未关闭。当前执行队列只在
[P2 backlog](doc/roadmap/p2-delta-backlog.md)维护。
WindowServer/Chrome 性能采证及 Windows/Linux 原生 runner 验收后置到发布准备，
保留未完成状态，不阻塞平台无关 Core 开发；当前顺序以
`doc/roadmap/goal-alignment-adjustment-plan-2026-09-30.md` 为准。

2026-10-05 已接受 ADR-025：同一 Graphics API 集合提供字体指标、文字测量与图文绘制；
布局后 glyph 轮廓、位置与后端专有预处理数据分离，支持未来片段着色器字体引擎。
P2-G02 Core API 与默认/可替换轮廓链路已实现；预处理网格/GPU 格式归具体后端，不进入 Core 布局结果，
不将未来自研 shader 算法列为当前必须交付的功能。

- **Draw2D API 语义覆盖账本**：`doc/parity/draw2d/api-coverage.md`（API family、语义契约、Novadraw 合理变体、M1-M10 映射）
- **产品交付清单**：`doc/roadmap/product-deliverables.md`（5 图元 / 6 布局 / 6 边框 等策略层清单）
- **Demo + 验证矩阵**：`doc/roadmap/demo-matrix.md`（每个 milestone 配套 demo + 截图断言策略 + GEF 层探索附录）

> 任何 delta、PR、commit、文档引用 `M{n}` 一律指
> `doc/roadmap/00-index.md` 定义的 M{n}，禁止在其他文档发明独立编号。
> 节点编辑器等 GEF 层能力不在 draw2d 核心 milestone 内，详见 `demo-matrix.md` 附录 A。
> 推进 M1-M10 的 architecture/parity delta 时，必须检查对应 `api_semantics` 的 Draw2D API 语义是否完整；受影响 family ID 记录在 delta 的 `api_semantics` 字段，语义来源见 `doc/parity/draw2d/api-coverage.md`。

当前执行顺序已在 2026-09-13 M10 Web 等价验收后再次校准：M1-M10、
D3.1-D3.4 与 D4.1-D4.6 已完成，最近一次长期架构审计的 A01-A08 已关闭。
macOS/Web/Headless 总审计与 R9.4 capability 消融复查已通过，Draw2D Core 1.0
完成。Editor framework 已按 ADR-015 完成独立 G0-G5 roadmap，G0 架构启动、G1 Model
Adapter/CommandStack、G2 EditPart Tree/Viewer 投影、G3
Selection/Targeting/Input Arbitration、G4 Tool/Request/EditPolicy、G5.1
Connection Projection、G5.2 Connection Creation 与 G5.3 Connection Reconnect 已完成，
G5.4 Connection Bendpoint 与 G5.5 Viewport/Auto-expose 自动门禁已完成；检查点 B
与检查点 C 已通过人工验收。
Draw2D 后续能力必须进入明确的 P2 delta。
Core 公开 API 的 P0 Batch A/B 已按 ADR-017 完成；Runtime 驱动、坐标查询和
Layout measurement 已按 ADR-018 收口；detached 构造与挂载后 scoped editor
调用面已按 ADR-019 收口；Color、Render IR 与 Geometry 基础值已按 ADR-020 收口；
公开 API 分层已按 ADR-021 收口；Core、Editor、Inspector、Vello backend 与平台
adapter 的 package 边界已按 ADR-023 收口。Graphics 已按 ADR-025/031 统一，
Figure capability 已按 ADR-027 收口；公开路径、统一 mutation 和查询失败分别由
ADR-033/035/038 细化。P2-R02 image source rectangle 已完成。
原 G6 的 schema、serializer 和产品级 Native/Web 场景已移交独立产品包，不再作为
本仓库引擎门禁。
2026-09-16 全量 Draw2D/GEF 语义审计及 2026-09-20 后续批次的 22 条 P1
已全部关闭；18 条次级候选保留待定向验证，状态以
`doc/verification/reviews/draw2d-gef-semantic-remediation-2026-09-16.md` 为准。

2026-09-10 的架构修订以 `doc/adr/adr-014-extensibility-and-lifecycle-boundaries.md`
为准，旧 ADR-013 已替换。D4.3-D4.6 的组件接口、引用归属、生命周期、测量、
稳定通知、递归性能与最终回归门禁已完成验证；新设计仍必须以实现证据为准。
默认架构检索排除 `doc/archive/`；只有显式历史追溯才读取旧全文。
完整审计入口：`doc/verification/reviews/adr-audit-2026-09-10.md`。

## 架构设计原则

### 设计方案与 ADR 的使用边界

普通设计方案默认放在 `doc/design/`，使用小写 kebab-case 的主题文件名，
不分配 ADR 编号。功能方案、接口细节、算法、缓存失效、组件组合、平台适配和
性能优化由对应设计专题维护，正文说明问题、目标、机制、取舍与验证方法。
候选标为 `proposal`，接受后按内容标为 `normative-design`，记录接受范围与依据。
设计可以独立评审、接受；文档先行和方案评审不要求配套 ADR。

只有存在影响长期架构边界的重要选择时，才单独创建 ADR，例如改变层间依赖、
状态所有权、公开扩展模型或既有关键契约。ADR 说明选择、理由、实质替代方案、
代价及对已有决策的效力；具体机制仍由 design 负责。
修改公开 API、新增能力、性能优化、经过评审或篇幅较大本身均不构成创建 ADR 的理由。

设计与 ADR 无需一一对应；设计可引用已有 ADR，一项设计也可涉及多个独立决策。
开始设计任务时先判断文档归属，再决定是否需要新增 ADR，不以 ADR 编号组织所有方案。
执行状态由 roadmap 维护，验证方法和结果由 verification 维护。
设计接受、实施完成与生产启用分别记录；重大架构变更仍须按既有规则获批后实施。
文档归属与替代细则见 [文档知识维护](doc/knowledge-maintenance.md#adr-与具体设计分开维护)。

### 规划与方案必须明确能力归属

后续规划、ADR、方案、验证矩阵和完成记录必须在开头声明能力归属：
Core（`novadraw`）、Editor（`novadraw-editor`），或其他明确的包／宿主。
“引擎能力”“框架核心能力”等名称不能代替归属说明。

- Core 承担 Figure、布局、绘制、命中、坐标、资源与 Runtime 基础协议。
- Editor 承担模型编辑、Command／历史、EditPart／Viewer、Tool／Request／Policy、
  选择、容器编辑、吸附及编辑导航；对应 GEF 框架能力。
- Inspector、渲染后端、平台适配和应用能力按各自 owner 列出，不归并进 Core 或 Editor。
- 跨层方案必须逐项列明能力、API／状态 owner、依赖、实际改动和验收。
  Editor 使用现有 Core API，属于 Editor 能力对 Core 的依赖；
  若需新增 Core 能力，须列为独立 Core delta，分别评审和记录完成状态。
- roadmap 表按能力归属区分队列；用户指定 Editor／GEF 范围时，只推进该范围，
  不自动转入 Core、Inspector 或其他队列。
- 验收分别统计 Core 基础契约、Editor 编辑行为、平台输入与应用消费者；
  Core 整改或 Shapes 的应用功能不能计为新增 GEF 框架能力。

### Editor 缺失 Core 依赖时停止新增

判断 Editor 是否必须依赖某项 Core 能力，依据是 GEF 框架对 Draw2D
对等能力的实际依赖。先确认上游契约，再核对 Novadraw Core 是否具备等价行为；
不按 Java 类名、Rust 接口形状或现有实现方式要求逐项照搬。

每项依赖判断必须记录以下证据链：

1. GEF 的编辑行为、源码提交及 class／method。
2. 该行为直接或间接依赖的 Draw2D API／行为契约，以及缺失时无法保证的结果。
3. 对应的 Draw2D parity family、Novadraw Core 公开契约和现有验证证据。
4. 已具备的等价机制，或尚缺的最小 Core 能力与可验证反例。

仅参考 `org.eclipse.gef` 与 `org.eclipse.draw2d`；Zest、产品示例的业务需求、
平台环境缺失和测试注入困难不能单独证明 Core 能力缺失。
证据不足时标为待确认，不以猜测建设新 Core 能力或绕过未确认的基础契约。

证据确认必要 Core 契约缺失时，立即停止增加 Editor 能力：
在 P2 backlog 记录阻塞关系，先交付明确归属为 Core 的增补建议方案。
建议必须说明上游依赖依据、最小增量、状态／API owner、失败语义、
外部消费者、性能与依赖成本、Core 验收及 Editor 恢复条件。
产物体积分析仅在用户明确要求对比产物体积时执行。
不得在 Editor 或应用层复制该缺失的 Draw2D 基础机制以绕过依赖。

Core 建议完成不等于批准 Core 实施。依赖补齐并通过对应验收后，
才按已有授权与路线图恢复 Editor 推进；Core 完成与 GEF 能力完成分别记录。

### 官方示例实施范围

只建设官方示例 Canvas / LightweightSystem 内的 Draw2D 能力。Java 源码仅作
只读语义参考，不编写、修改、编译或运行 Java 验证代码；不建设 SWT 原生控件的
Novadraw 替代体系。Canvas 外的临时控制工具可用于过渡或验证，不作为 Core
演进目标或对等毕业条件。Draw2D Figure 组件（如 ScrollBar、MultiLineLabel）
仍须按统一扩展模型实现，不能与 SWT 原生控件混淆。

### 基本准则

架构设计时遵循以下优先级：

1. **扩展性与稳定性优先，性能同步评估**：保持开放扩展与稳定契约，同时在架构设计阶段充分考虑渲染和交互响应成本。性能是项目的核心竞争力，不能推迟到实现完成后才考虑；取舍需说明收益与成本，并以测量验证。产物体积分析按下文的显式请求规则执行。
2. **参考 g2 设计理念**：draw2d/GEF 经过 20+ 年生产验证，核心设计决策优先对标 g2
3. **不考虑当前代码状态**：架构讨论独立于实现，代码应追随架构而非反之
4. **契约与实现分离**：只在存在真实替换需求的边界使用 trait；核心算法可用具体类型和内部策略保持契约稳定
5. **引擎层承载通用机制**：draw2d 风格的事件链路、坐标域切换和 Figure 回调上下文属于引擎语义，不属于应用层便利逻辑
6. **严格限定对标范围**：只以 `org.eclipse.draw2d` 与 `org.eclipse.gef` 包为
   框架语义和实现参考；`org.eclipse.zest` 是使用 Draw2D 扩展能力构建的上层产品，
   不得用其源码、行为或扩展逻辑定义 Novadraw 的需求语义、架构或实现；
   Novadraw 的扩展契约必须直接从 Draw2D/GEF 源码推导
7. **内置与扩展同模型**：请不要区分"内置的功能"与"未来扩展的功能"，二者必须采用
   同一套设计方案和 API。内置功能只是"提前实现的代码"，不是特权路径。
   具体表现为：
   - 不为内置能力保留闭合 `enum`、`Role`、`Kind` 或仅内部可见的 struct 字段；
   - 不为内置能力增设"typed hook"的同时让扩展能力只能走"erased hook"；
   - 不为内置能力建立 fast path 使外部实现者无法达到相同性能或语义；
   - 新 Request / Tool / Handle / Capability / Binding / Layout / Figure 都
     使用相同的 typed identity + payload trait + registry/envelope；
   - 若内置实现为 ergonomics 需要 typed 入口，外部实现也必须能用同样的 typed 入口；
     常用做法：抽出 `Key<T>` + `Payload: Trait`，内置用预定义 Key，外部用自定义 Key；
   - 任何对内置能力做 `match concrete_variant` 的位置都是债务，必须以第三方
     也能注册同 identity 的方式重写；
   - 验证形式：涉及扩展能力的设计必须说明"外部消费者证据"，证明同一能力由
     第三方 crate 不改 Core 即可实现，且与内置实现共用全部语义与错误通道。
     设计阶段说明接口与消费者可行性依据，实施完成时提供可执行验证；
     证据的要求不构成新增 ADR 的理由，相关 ADR 可链接设计与验证记录。

### 包体积与性能要求

2026-10-30 用户明确调整执行规则：只有用户明确要求对比产物体积时，才执行
产物体积分析、测量和比较。日常功能补充不自动构建体积探针、准备基线 worktree、
比较 Native／Wasm 或原始／压缩大小，也不把体积采证作为功能迭代门禁。
此约定覆盖既有 ADR、计划及验收清单中的自动体积比较要求；一般的“继续推进”
或批准功能方案不视为要求执行体积分析。

- **明确请求后的产物比较**：按用户指定范围，比较相同 release 配置和消费场景下
  的产物；Web 按需记录 Wasm、JavaScript、字体、图片等资源，区分原始体积、
  传输压缩体积和首次加载所需资源。源码行数和 crate 拆分不能代替产物测量。
- **评估依赖与加载边界**：说明新增依赖、默认 feature 和内置资源的成本，检查未使用
  能力能否裁剪，以及可选能力是否适合按需加载。模块或 crate 拆分本身不证明包体缩小。
- **性能进入架构方案**：评估渲染、布局、命中、事件分发和交互响应的复杂度、
  内存分配、数据复制、缓存与失效范围，并考虑大场景、连续输入和动画中的成本。
  性能优化必须继续遵守内置与扩展同模型、状态所有权和错误处理契约。
- **以证据完成取舍**：设计记录预期成本、测量场景及尚未验证的假设；实施后用代表性
  场景验证初始化时间、帧耗时和输入响应延迟，按受影响路径选择指标。
  说明构建配置、环境和数据规模，不用单一平均帧率代替全部性能结论。

明确请求体积比较时，具体体积预算由特性和消费场景确定。延迟预算同样按场景确定，
不预设未经测量的统一阈值。发布准备阶段的平台性能采证可以按路线图后置，
架构阶段的性能评估与受影响路径验证仍按任务风险执行。

### 架构设计执行规则

**在做理想架构设计时，禁止扫描本项目的 rust 代码。**

- 架构设计应从需求、第一性原理、g2/GEF 参考文档出发
- 可以参考 g2 源码（`/Users/bytedance/Documents/code/GitHub/gef-classic`）中的
  `org.eclipse.draw2d`、`org.eclipse.gef` 包和已有分析文档
- 不得参考同仓库中 `org.eclipse.zest` 包的上层扩展逻辑；需要研究某项扩展能力时，
  应追溯到 Draw2D/GEF 提供的基础契约与扩展点
- 不扫描本项目代码是为了避免"现状偏差"，确保架构设计独立于当前实现

### g2 设计哲学

draw2d/GEF 的核心设计哲学：

| 原则 | 说明 | Novadraw 对应 |
|------|------|---------------|
| **轻量 Figure 树** | Figure 树统一承载组合、Z-order、绘制、命中和坐标传播 | `FigureTree` + `FigureNode` |
| **行为语义内聚** | IFigure 让每个 Figure 参与统一协议，但其 Java 接口本身很宽 | Rust 小 trait/capability + Runtime facade |
| **节点状态与具体行为分离** | 这是 Novadraw 对 Draw2D 行为语义的 Rust 迁移，不是 Draw2D 的源码结构 | `NodeState` + `Box<dyn Figure>` |
| **委托优于继承** | 布局、更新等通过组合实现 | LayoutManager trait |
| **两阶段更新** | Validation → Damage Repair 分离 | UpdateManager 两阶段 |
| **ID 引用树** | 这是 Novadraw 为 Rust 所有权采用的迁移策略 | `SlotMap<FigureId, FigureNode>` |
| **平台与引擎隔离** | LightweightSystem 桥接 SWT 与 Figure 世界 | `PlatformHost` + `Runtime` |

### 架构审查清单

讨论架构时，必须明确：
- [ ] 扩展点在哪里？（新 Figure 类型、新 LayoutManager、新平台后端）
- [ ] 稳定性：接口是否稳定？会不会频繁 breaking change？
- [ ] 与 g2 的对应关系？为何与 g2 不同或相同？
- [ ] 错误处理：失败模式是什么？
- [ ] 依赖与加载边界：可选能力能否裁剪或按需加载？
- [ ] 性能：渲染与交互关键路径的成本是什么？如何用代表性场景验证？
- [ ] 产物体积（仅用户明确要求时）：同配置产物和必要加载资源的体积变化是什么？

## 交互方式

### 思维原则

运用第一性原理思考，拒绝经验主义和路径盲从。不要假设我完全清楚目标，保持审慎。若目标模糊请停下讨论，若目标清晰但路径非最优，请直接建议更短、更低成本的办法。可以采用苏格拉底提问法和奥卡姆剃刀原理。

### 默认行为

优先直接推进用户目标：读取必要上下文、定位问题、实现修改、运行验证，并给出清晰结果。

不要求每次回复都固定拆分为“直接执行 / 深度交互”。只有当深度交互能降低误解、架构偏移或长期维护风险时，才主动展开。

### 工作流分级

1. **简单问答 / 小修改**
   - 直接给结论或完成修改。
   - 不强制输出深度交互。

2. **Bug 修复**
   - 先定位根因。
   - 再修复。
   - 最后验证。
   - 若根因涉及架构契约，说明影响面。

3. **新功能**
   - 先定义接口契约或行为契约。
   - 再补测试。
   - 再实现。
   - 最后验证并更新相关文档。

4. **架构设计**
   - 先澄清目标和约束。
   - 对标 Draw2D/GEF 与项目长期原则。
   - 给出方案、取舍和风险。
   - 重大架构变更需用户确认后再实现。

5. **大范围或高风险修改**
   - Explore：先读文档与相关代码。
   - Plan：给出执行计划。
   - Gate：等待用户确认关键取舍。
   - Execute：分步修改。
   - Verify：运行测试 / 检查。
   - Review：总结风险与后续事项。

### 深度交互触发条件

仅在以下情况主动展开：

- 用户目标不清晰，可能存在 XY 问题。
- 当前做法会破坏项目长期架构。
- 存在多条路径且代价差异明显。
- 修改超过单一模块或超过 50 行。
- 涉及渲染主循环、坐标协议、事件分发、UpdateManager 等核心契约。
- 需要在“快速落地”和“架构正确”之间取舍。

### 行为准则

- **重大架构变更**：先讨论方案，确认后再实现
- **Bug 修复**：先理解根因，解释后再修复
- **代码改动**：超过 50 行分步提交
- **新增功能**：先定义接口，再迭代实现
- **性能优化**：提供基准数据佐证

## 调试技巧

- 使用 `--screenshot` 参数保存渲染结果
- 使用 `mcp__MiniMax__understand_image` 分析截图
- `render_iterative.rs` 已归档；除非执行性能专项恢复，否则不要把归档代码纳入当前实现分析
- 背景色 RGB(238, 238, 238)，图形颜色应避免与此重复

## 参考代码

- draw2d/GEF: `/Users/bytedance/Documents/code/GitHub/gef-classic`
  - 可运行参考样例：`third_party/draw2d-examples/`，仅用于行为核验
  - 允许：`org.eclipse.draw2d`、`org.eclipse.gef`
  - 排除：`org.eclipse.zest` 上层扩展逻辑
- SWT GC: `/Users/bytedance/Documents/code/GitHub/eclipse.platform.swt`
- vello: `/Users/bytedance/Documents/code/GitHub/vello`
- xilem: `/Users/bytedance/Documents/code/GitHub/xilem`
- Zed: `/Users/bytedance/Documents/code/GitHub/zed`
