# 贡献者指南维护规则

本页约束《Novadraw 贡献者指南》的后续更新。

## 事实边界

更新前必须读取 `AGENTS.md`、`CLAUDE.md` 和任务相关项目记忆。事实优先级为：

1. 已接受 ADR；
2. 范围更窄的规范性设计；
3. Draw2D/GEF 语义账本；
4. 当前路线图状态；
5. 当前实现与验证；
6. 本书解释。

默认排除 `doc/archive/`。只允许使用 `org.eclipse.draw2d` 与 `org.eclipse.gef` 作为外部
语义参考，不使用 `org.eclipse.zest` 定义需求。

## 内容边界

本书只承担：

- 把核心原理映射到当前源码、规范和验证入口；
- 指导贡献者定位代码与规范；
- 说明修改内部协议的正确步骤；
- 连接实现、测试、suite、性能和评审门禁。

以下内容属于用户指南：

- 使用公开 API 构建应用；
- 通过现有公开扩展点增加 Figure、布局、连接或编辑行为；
- 产品应用的 Native/Web 组合与发布。

不依赖当前源码结构的架构原理、状态模型和算法推导属于《深入理解 Novadraw》。本书
引用这些原理，不复制一套平行叙述。

不得把 roadmap 计划写成已实现行为。若设计已接受但尚未完成，必须明确要求读者同时
核对当前代码与路线图。

## 章节写法

每章按以下顺序组织：

1. 本章要保护的架构边界；
2. 权威状态及其所有者；
3. 执行或提交的因果顺序；
4. 允许的扩展与禁止的捷径；
5. 失败模式；
6. 规范、代码和验证入口；
7. 评审问题。

正文不复制完整 ADR、路线图状态表或大段源码。引用代码时优先链接模块、类型或函数，
并解释为什么该入口与本章边界相关。

模型到视图使用“视图派生”或具体的构建、同步、重建动作；几何跨域使用“坐标变换”
或“表面包围盒”。`projection.rs` 等真实源码路径和标识符保持原名，并在首次出现时
说明其中文语义。

Runtime 直接状态使用“场景源状态”，提交后的前缀使用“已提交场景状态”，stable epoch
的一致读边界使用“稳定场景状态”，Query 读取的具体值使用“场景数据项”或“查询依赖
项”。源码注释和 ADR 中的 `scene facts` 保持原词，普通叙述不使用未限定的“场景事实”。

运行时帧协议使用以下固定名称：`prepare_submission` 是“帧提交准备”，
`FramePreparation::Ready` 表示“渲染提交包已就绪”，`RenderBackend::submit` 是 Host
“提交后端”，`RenderDisposition::Presented` 表示“帧已呈现”，
`SubmissionAcknowledgement` 表示 Runtime 已形成完成确认结果。真实代码标识符保持
原名，普通叙述不使用“帧出版”。

动画相关说明必须区分：`FigurePresentation` 是图形准备结果，
`PresentationSnapshot` 是稀疏表现覆盖快照，`TemporaryVisual` 是 Runtime 管理的树外
动画临时绘制项。Viewer 的 Overlay、Handle 和 Feedback 进入 Figure 树，不属于表现
状态层。普通叙述不使用“表现平面”。

## 同步规则

发生以下变化时必须检查贡献者指南：

- crate 或公开 facade 边界变化；
- Figure、Runtime、UpdateManager 或 RenderSubmission 协议变化；
- Capability 分类或 registry 合同变化；
- Editor Tool、Request、Policy、Command 或视图同步事务变化；
- 平台输入、资源、后端失败合同变化；
- 验证命令、suite 或贡献门禁变化。

若变化只影响公开用法，还应同步用户指南；若变化影响长期核心模型，还应同步深入理解
书。三本书不能对同一行为给出不同结论。

## 验证

纯书稿修改至少运行：

```bash
cargo xtask docs
git diff --check
./tools/scripts/build_book.sh
```

最后检查三本书的 `SUMMARY.md` 覆盖全部读者可见页面，并确认跨书链接均存在。
