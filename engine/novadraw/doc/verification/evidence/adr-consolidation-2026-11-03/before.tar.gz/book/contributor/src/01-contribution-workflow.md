# 1. 贡献工作流与事实层级

> **本章解决的问题**：开始修改代码前，如何确认目标契约、影响范围和最低验证证据。

## 1.1 先判断任务属于哪一层

贡献者首先把需求归入一个主要责任域：

| 变化 | 主要责任域 |
|---|---|
| 几何、Figure 树、布局、输入、连接、Runtime | `novadraw` |
| 视图派生、选择、工具、请求、策略、命令 | `novadraw-editor` |
| 只读诊断和观测 | `novadraw-inspector` |
| Vello lowering 与 GPU 提交 | `novadraw-backend-vello` |
| 窗口、浏览器、DPI、输入法桥接 | platform crate |
| 场景编排和产品行为 | 应用或 example crate |

如果需求可以在应用层通过公开契约完成，不应修改框架核心。

## 1.2 确认事实来源

开始分析前依次读取：

1. 仓库根目录的 `AGENTS.md` 和 `CLAUDE.md`；
2. [`doc/00-index.md`](../../../doc/00-index.md)；
3. 相关 ADR 与范围更窄的规范性设计；
4. 对应的 Draw2D/GEF 语义账本；
5. 路线图中的当前交付状态；
6. 实现代码和验证套件。

默认不读取 `doc/archive/`。归档内容只能用于显式历史追溯，不能定义当前行为。

## 1.3 从契约到实现

不同任务采用不同起点：

- **缺陷修复**：先复现和定位违反的现有契约，再做最小根因修复；
- **新增能力**：先定义公开或内部行为契约，再补测试和实现；
- **架构变化**：先形成可评审设计，确认所有权、扩展点和失败模型后再修改代码；
- **性能优化**：先建立基准，证明瓶颈后再改变算法。

推荐顺序：

```text
目标与约束
-> 规范和语义核验
-> 定向代码阅读
-> 设计或修复方案
-> 精确测试
-> 实现
-> 分层验证
-> 差异审查
```

## 1.4 控制修改范围

修改应服从已有 crate 和模块边界：

- 不为局部便利增加全局状态；
- 不把通用机制放进 examples；
- 不让 Kurbo、Vello 或 Winit 类型穿透 backend-neutral 公共签名；
- 不在渲染热路径打印日志；
- 不绕过 Runtime 直接维护失效、重绘或通知；
- 不把一次高风险协议迁移拆成长期并存的双入口。

遇到工作区已有修改时，先判断是否与当前任务相关。无关修改保持不动；相关修改作为
当前事实继续工作，不回退他人的内容。

## 1.5 提交前证据

验证从窄到宽执行：

1. 受影响 crate 的 `cargo check -p <crate> --lib`；
2. 精确 integration test 或 `cargo xtask verify <suite-id>`；
3. 同类整改批次运行 workspace fmt 和 check；
4. 最终提交、推送、合并或里程碑关闭前运行 workspace fmt、Clippy 和 test。

```bash
cargo fmt --all -- --check
cargo check --workspace

cargo clippy --workspace -- -D warnings
cargo test --workspace
```

纯文档变化通常只需要：

```bash
cargo xtask docs
git diff --check
```

提交摘要使用中文，并按主题保持原子化。
