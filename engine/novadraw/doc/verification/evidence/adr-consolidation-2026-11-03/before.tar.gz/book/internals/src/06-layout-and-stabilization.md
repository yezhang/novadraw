# 6. 测量、布局与稳定化

> **本章解决的问题**：内容、约束和容器相互影响时，怎样从失效状态收敛到一组可绘制、
> 可命中、可发布的稳定几何？

布局不是“调用一次函数给 children 赋 bounds”。文本换行会改变高度，父级宽度会改变
文本换行，子节点移动又会改变自由范围容器的内容范围。布局属于派生状态系统。

核心结论是：

> 布局器计算候选几何，Runtime 验证并提交；稳定化结束前，场景不能对外宣称完成。

## 6.1 测量与排列

**测量**回答：在给定约束下，这个节点希望占多大空间？

**排列**回答：父级最终把每个子节点放在哪里？

两者必须分离，因为同一节点可能在不同宽度提示下得到不同高度；父级也可能在多个子
节点偏好之间分配有限空间。

```text
Measure(child, constraints) -> SizeRange / DesiredSize
Arrange(parent, child measurements, relationship constraints) -> placements
```

Figure 提供自身内容的测量语义，LayoutManager 负责父级对子节点的排列策略。

## 6.2 尺寸约束

一个完整测量请求通常包含：

- 最小宽高；
- 最大宽高；
- 可选精确尺寸；
- 宽度或高度提示；
- 当前样式和内容版本；
- 逻辑单位与文本测量环境。

intrinsic size 是内容在无额外拉伸时的自然尺寸，不等于最终 bounds。最小值限制压缩，
最大值限制扩张，父级约束决定最终选择。

约束必须规范化：最小值不得大于最大值，尺寸必须有限，负尺寸要有统一语义。

## 6.3 布局约束属于父子关系

“在网格第几列”“沿主轴占几份”“锚定父级右边”描述的是 child 在特定 parent 中的
角色。它既不属于 child 的内在属性，也不属于布局器的全局表。

概念上可表示为：

```text
Edge(parent, child) {
    order,
    layout_constraint,
}
```

换父时，旧关系约束不能自动被新父解释。结构事务必须验证或重建约束。

## 6.4 LayoutSceneQuery

Runtime 在调用布局器时提供只读 `LayoutSceneQuery`。它不是一次性复制的完整快照，而是
对当前准备视图的受检查询视图：

```rust
struct LayoutSceneQuery<'a> { /* 借用 Runtime 的准备场景 */ }
```

通过它可以读取：

- 容器的直接 children 及其当前 bounds；
- 每个 child 的 layout constraint；
- preferred measurement、minimum size 和 maximum size；
- 容器 bounds、freeform extent 与 content scale。

查询按需发生，调用方不能借此改树、改 bounds 或触发稳定化。布局器看到的是一组受检
数据项，而不是 Runtime 内部可变容器。

## 6.5 LayoutOutput

布局器返回拥有数据的候选结果：

```rust
struct LayoutOutput {
    changes: Vec<LayoutChange>,
}
```

`LayoutChange` 可表达 child bounds、可见性、失效、属性变化、坐标系变化、重绘和
viewport 副作用。Runtime 在应用前验证：

- `Bounds` 目标确实是该容器的直接 child；
- bounds 数值有限，宽高非负；
- 属性变化的目标是当前容器；
- 重绘、坐标系和 viewport 副作用的目标没有越权。

验证不通过时整批拒绝。当前实现没有独立的 epoch 字段，也没有“无重复或遗漏必需
child”的全集检查；布局器只提交它负责的变化，未提到的 child 保持原值。

## 6.6 失效传播

变化不会总是导致整棵树重新布局。失效应描述依赖方向。

例如文本变化：

```text
文字内容变化
-> 自身测量失效
-> 父布局失效
-> 自身 bounds 可能变化
-> 后代可用宽度可能变化
-> 连接与 damage 失效
```

样式颜色变化通常只影响绘制，不影响测量。边框厚度变化则同时影响 client area、布局和
visual bounds。失效类型要比一个笼统 `dirty` 标志更精确。

## 6.7 稳定化工作列表

Runtime 使用工作列表处理待计算派生状态：

1. 收集本次 mutation 产生的失效项；
2. 按依赖顺序选择可计算项；
3. 建立稳定输入快照；
4. 调用纯计算策略；
5. 验证并应用结果；
6. 把新产生的后继失效加入队列；
7. 队列为空且无版本漂移时结束 epoch。

```mermaid
flowchart TD
    Dirty[失效集合] --> Pick[选择下一工作项]
    Pick --> Snapshot[建立快照]
    Snapshot --> Compute[策略计算]
    Compute --> Validate[验证输出]
    Validate --> Apply[原子应用]
    Apply --> More{产生后继失效?}
    More -->|是| Dirty
    More -->|否| Stable[稳定 epoch]
```

稳定化不要求所有算法一次完成，但要求最终达到固定点。

## 6.8 几类布局的共同模型

### 固定坐标

父级尊重 child 提供的位置，只应用约束校验。它仍需要处理 client area、可见性和父级
内容范围。

### 填充布局

父级把可用区域分配给一个或多个 child。测量用于决定父级自然尺寸，排列使用最终尺寸。

### 流式布局

排列依赖可用主轴长度，换行会让宽高相互影响。缓存键必须包含尺寸提示。

### 网格布局

多个 child 共同决定行列尺寸。不能把每个 child 独立布局后简单拼接。

### 自由范围布局

child bounds 可能由外部事实给定，父级派生内容 extent。它看似“不布局”，实际仍维护
容器范围和负坐标策略。

这些算法的差异在快照和计算规则，不在提交协议。

## 6.9 父子测量依赖

典型依赖是自底向上测量、自顶向下排列：

```text
叶节点 intrinsic measure
-> 容器汇总 preferred size
-> 根获得可用尺寸
-> 父级 arrange
-> 子级获得最终约束
```

但文本换行等场景可能需要带宽度提示重新测量。框架应显式表示约束变化，而不是无限
递归“再试一次”。

### preparation 的约束测量

`PreparationScene::measure_figure` 通过 Core 的测量入口分派，不由图布局 adapter
自行测量字体或组合 Border。preferred 与 minimum 独立选择 override、LayoutManager、
preparation 或 intrinsic 来源；只有实际选中 preparation 时才调用
`FigurePreparation::measure_scene`。callback 接收内容约束，可从 scene 查询本次
outer/content 约束；返回内容 metrics，Runtime 校验尺寸和 baseline 后完成物理 Border
组合及容器正投影。override 不经过内容展开。

`FlowLayoutService::measure` 在冻结贡献树上执行排版，只返回内容尺寸，不发布
placement 或 drawing；外部 Flow root 与 `FlowPageFigure` 共用这个入口。
宽度未限定时，文字请求也保持未限定，不构造无限 Rectangle。
内联普通 Figure 通过同一 `measure_figure` 会话测量；当前行剩余宽度不足时，
按完整行宽重新测量。FlowPage 的 minimum 与同约束 preferred 相等，
沿用 Draw2D `FlowPage.getMinimumSize` 契约。
`TextFlowFigure` 的约束测量和绘制 preparation 共用换行、截断排版函数；
候选测量不修改已有文字交互布局。附着源组件不再维护独立布局缓存，
Runtime 的文字查询与绘制共用 presentation 中的不可变 TextFlow 值；
TextFlow 经通用 preparation 更新，专用刷新路径已移除。
Flow 贡献、文字排版与快照分配累计同一预算。
验证入口为 `p2_preparation_measurement_contract`、`p2_t01_text_flow_contract` 和
`p2_t03_structured_flow_contract`。

测量调用栈由同一 preparation scene 共享。重入相同 Figure 时，入口立即返回带有
有序 Figure 路径的 `PreparationDependencyError::MeasurementCycle`，不等待反馈预算。
LayoutManager 的子查询也进入该会话，各自请求 preferred 或 minimum；
未被选中的指标不参与校验。会话缓存记录 Figure、约束、指标和文字资源版本，
同时保留子查询的传递观察，缓存命中不会省略依赖。
受约束查询记录 `FigureMeasurementSource`，其版本来自组件、源 bounds、
显式尺寸、布局约束、样式与 preparation provider；缓存重新验证不改变该版本。
旧 `FigureMeasurement` 仍记录已提交 metrics 的代数。
嵌套失败经 `LayoutError::Preparation` 传播，保留叶节点身份与该节点的约束；
直接测量入口还原原始错误及 `Error::source`。
一次稳定化的全部 preparation 与测量回调共用 `PreparationBudgetHandle`。
子树构建、测量缓存、源前缀、快照观察与依赖可达性检查均累计 work/allocation；
`PreparationScene::budget` 让外部 producer 对私有分配使用同一计数器。
图算法通过 `GraphSolveContext::with_preparation_budget` 继续累计总预算，同时保留局部限制。
预算耗尽是结构化错误，不能用它声称已经证明依赖有环。
回调忽略超限错误也不能发布本批候选；下一次独立稳定化使用新计数器。
嵌套预算错误保留实际失败叶节点及其约束。
宿主通过 `RuntimeFrames::set_preparation_budget` 设置后续完整稳定化的有限额度；
默认额度不变，producer 和 solver 只能累计消耗，不能在反馈轮次之间补充额度。
实现见
[`figure/preparation/budget.rs`](../../../crates/novadraw/src/figure/preparation/budget.rs)。

错误类型位于
[`figure/preparation/measurement.rs`](../../../crates/novadraw/src/figure/preparation/measurement.rs)；
外部消费者反例见
[`p2_preparation_measurement_contract.rs`](../../../crates/novadraw/tests/p2_preparation_measurement_contract.rs)。

### preparation 快照与路由发布

`PreparedFigure` 保存 Runtime 签发的快照身份、冻结源前缀、producer 结果版本与实际
测量/几何观察。`PreparationScene::source_revision` 排除派生 bounds 和布局缓存代数；
组件、拓扑、源 bounds、显式尺寸、布局策略/约束及解析样式仍参与输入验证。
内部源前缀保存逐项输入，用于受检查询与身份复用；诊断 hash 不授予快照权限。
批次写入前再次核对源输入、字体版本及计算观察。资源写入同步最新文字版本，
因此字体替换或移除后的显式路由不能绕过 preparation 读取旧快照。
节点另外保存挂载时的 capability/显式依赖和 component effect 绑定的资源身份与状态，
供源前缀与测量源版本核对。资源更新属于已提交输入，派生检查点不会恢复旧值；
无关图片更新不替换图快照。
不声明结果版本的旧 producer 保留按完整 preparation key 更新的兼容行为。

`TrackedRouteSceneQuery` 自动观察 `DependencySubject::PreparedScene(owner)`。依赖
generation 来自有效快照身份，计算尝试不会单独增加 generation。presentation 阶段
替换快照后重新安排依赖失效检查，避免 bounds 未变时沿用旧路径。

`require_route_group` 的发布条件单独存储。稳定 epoch 晋升前，Runtime 检查完整求解组、
resolved 状态、routing space 和本次快照观察；候选失败走原有派生检查点恢复。
快照保存计算观察，路由环检测展开快照观察；preparation 查询自己直接或传递依赖的
快照时返回有序闭环。必需组准入拒绝读取组成员或其 Locator 子树的几何、测量及原始
Figure/capability 数据，源 children/parent 查询仍然合法。缓存命中核对观察代数，
受检快照查询也核对传递观察。同批准入合并候选、保留快照与成功路线的计算依赖，
在任何布局或 presentation 写入前检查跨 owner 的环与必需组反向读取。
LayoutManager 子查询和缓存保留传递观察，遍历使用同一次稳定化的预算。
必需组连接的恢复记录只在完整稳定化成功后保存；
恢复先核对绑定版本、快照有效性及依赖版本。同源失败恢复旧 resolved generation；
改源或改绑定后保留当前错误和观察，旧路线不能恢复为 resolved。
尚无成功记录的首帧失败保留重试状态，普通路由失败通道保持原有语义。
外部消费者验证见
[`p2_prepared_scene_routing_contract.rs`](../../../crates/novadraw/tests/p2_prepared_scene_routing_contract.rs)。

### 图布局消费同一候选

`GraphProjectionBinding` 明确保存图实体到 Figure、图边到 Connection 的完整一一映射。
adapter 要求它们都是 owner 的直接 child；图 group 的包含关系保留在不可变请求中，
不会变成 FigureTree 的父子关系。未列入动态测量的实体继续使用 fixture 尺寸。

`GraphProjection` 先通过权威测量入口取得动态需求，再求解 placement 和完整路径。
它用候选 outer 宽度重新测量；需求改变时，在同一预算内重建请求并再次求解。
最终测量记录随 `GraphProjectionSnapshot` 保存，重复稳定化观察最终约束并复用受检结果。
缓存同时核对并继承初始需求与各反馈轮次的全部计算观察，不能因只重测最终约束而
遗漏初始需求所读取的依赖。观察版本或集合改变时，重新生成请求并求解。
出现需求振荡时返回 `NonConvergentMeasurement`，不能把最后一次候选当作稳定结果。
纯结果缓存不持有当前路由权限，Runtime presentation 仍是唯一发布权威。

`GraphProjectionAnchor` 从 Runtime 受检快照读取 attachment，核对候选 Figure bounds
与 binding，再通过引擎坐标 API 返回位置和法线。`GraphProjectionRouter` 从同一
快照读取完整 points，核对 Runtime 已准备的端点与法线，交给普通组路由准入通道。
`GraphProjectionFigure` 通过 `SetGraphProjection` 安装 producer；外部容器可以直接
组合同一公开 producer 和路由类型。
图容器的 `measure_scene` 也调用 producer，读取纯结果尺寸并丢弃布局效果。
视口先据此测量内容，随后正常 preparation 才取得候选发布资格。
显式图尺寸保持原请求；视口宽度提示不裁掉图 extent。视口滚动只改变几何映射，
不会改变图请求、快照身份或相同 routing scope 中的完整路径。
普通 Runtime 布局也传入同一文字服务和稳定化预算，按每次查询的约束重新测量；
因此视口缩窄后，Flow 不会继续沿用上一帧的换行尺寸。
LayoutManager 保留调用者的查询范围，preparation 回调则只读取自身子树。
每个 owner 的冻结源前缀和计算观察由后代共享不可变切片，避免为每个后代复制
完整前缀；逐项输入核对和有限预算仍然有效。
文字交互读取同一不可变 presentation；修改文字视口 offset 后，Editor 先完成
Runtime 稳定化，再读取光标和选区几何，避免把新 offset 与旧布局混用。
实现见 [`layout/graph/preparation.rs`](../../../crates/novadraw/src/layout/graph/preparation.rs)
与 [`layout/graph/projection.rs`](../../../crates/novadraw/src/layout/graph/projection.rs)。
验证见 [`graph_projection_contract.rs`](../../../crates/novadraw/tests/graph_projection_contract.rs)，
覆盖 52 个官方输入方向组合、外部非分层算法、动态 EAST 测量、振荡、失败恢复
和 tracked viewport 测量/滚动。真实 Label、边框、箭头与宿主菜单切换见
[`graph_examples.rs`](../../../crates/novadraw/examples/native/draw2d-official-examples/src/examples/graph_examples.rs)。

### 图算法的统一注册

图算法不是一组写死的分支。`GraphLayoutService` 以 `GraphAlgorithmKey<P>`、能力声明
和 `GraphLayoutAlgorithm<P>` 实现注册；内置的 `DIRECTED_GRAPH`、`COMPOUND_GRAPH`
与 `LAYERED` 走的都是同一个 `register` 入口。key 的 `name` 只用于诊断，真正的分派
按 payload 类型的 `TypeId` 进行，因此外部 crate 不修改 Core 也能注册新算法，并获得
同样的请求校验、能力检查、求解上下文和错误通道。

约束和 capability 同样走 typed 注册：`register_constraint` 与 `register_capability`
分别接收 `GraphConstraintKey<P>`、`GraphCapabilityKey<P>`。注册会更换服务的
generation，使依赖“哪些算法可用”的结果失效，而不是依赖调用方手动清缓存。

## 6.10 稳定 epoch

每轮稳定化使用 epoch 标识其输入和发布边界。epoch 完成意味着：

- 所有必需布局工作项已处理；
- 没有待应用的过期输出；
- 连接和容器范围等后继派生状态已闭合；
- 可以计算最终 damage 和生成绘制命令。

epoch 不等于帧号。一次帧准备可能消费多个 mutation 并形成一个稳定 epoch；后端也可能
尚未完成此前帧。

## 6.11 收敛失败

以下情况可能导致不收敛：

- 布局输出每次都改变输入约束；
- 测量包含随机或时变结果；
- 两个容器互相把对方尺寸作为无界依赖；
- 数值误差导致尺寸在两个值之间振荡；
- 扩展在布局回调中继续提交结构变化。

Runtime 需要工作量或迭代上限，并在失败时报告依赖链。不能把最后一次中间结果发布为
“稳定”。

更根本的解决是让算法单调、使用明确固定点规则，或打破循环依赖。

### 派生检查点

失败恢复不能把整棵树深拷贝。Core 的 `DerivedCheckpoint` 只保存源组件不变时可能被
本次稳定化改写的派生数据：节点 bounds、insets、边框快照、可见性、测量代数、
freeform 状态、prepared 结果、路由点和连接装饰几何，另加通知队列与 viewport 效果。
源组件、拓扑、资源输入和 capability 不会被回滚。

只有本次存在 preparation owner 时才建立检查点：`begin_derived_preparation` 在需要
跨反馈轮次保留回滚前缀时返回 true。期间其他反馈轮次可以 `rebase_preparation_sources`
只重定位已提交的活动变化，同时保留更早的前缀。稳定化失败时
`finish_derived_preparation(false)` 把派生值恢复到前缀，并重新标记几何失效，避免缓存
继续服务被拒绝的几何；成功时丢弃检查点，不做额外写入。成功路径不复制源状态，失败
路径也不会让旧 owner 的 prepared 结果复活到已移动或已分离的节点上。

## 6.12 原子应用

布局器返回多个 child changes 时，应先整批验证，再按稳定顺序应用。当前实现先调用
`validate_layout_output` 检查所有变化，随后逐条应用：

1. 验证目标身份、bounds 数值和副作用归属；
2. 按 `LayoutChange` 顺序更新 bounds、可见性和失效标记；
3. 合并属性通知；
4. 标记坐标、连接和 damage 后继；
5. 在稳定化完成后统一发布。

这里没有“先保存整批旧表面包围盒”的独立阶段；每条 bounds 更新走既有 erase→set→
repaint 路径。观察者不会在应用中途读取场景：通知和帧准备都要等稳定化完成后才发布。

移动与 resize 属于一次 bounds 变化，不应拆成互相可见的多个事件。

## 6.13 缓存与重建

测量缓存键至少包含内容版本、样式版本和约束。布局缓存还要包含 child 集合、关系约束
和父级 client size。

缓存命中必须等价于重新计算；缓存缺失只影响性能，不能影响结果。无法说明重建条件的
缓存不应存在。

## 6.14 必须保持的不变量

1. 测量不直接修改场景；
2. 排列输出只作用于快照声明的父子关系；
3. 布局约束属于父子边；
4. 过期 epoch 的结果不得提交；
5. 多 child 布局结果原子应用；
6. 稳定发布前工作列表必须闭合；
7. 收敛失败必须显式暴露。

## 6.15 常见错误设计

### Figure 在 `preferred_size` 中修改自身

查询变成隐式 mutation，测量顺序会改变结果。

### 布局器直接持有 child 可变引用

输出无法整体验证，也无法丢弃过期计算。

### 一个 `dirty` 标记覆盖所有失效

要么过度全量计算，要么漏掉测量、坐标或连接依赖。

### 每改一个 child 都立即发通知

观察者读到半布局状态，且产生通知风暴。

### 达到迭代上限就接受当前值

系统把未证明稳定的几何发布给命中和渲染。

## 6.16 与后续章节的关系

布局稳定化产出最终节点几何。下一章将在稳定 epoch 上计算旧新视觉 damage、录制命令
并构造帧提交。第 11 章的 freeform extent 和连接路由也是同一稳定化系统中的派生工作项。

## 6.17 思考题

1. 为什么文本测量缓存必须包含宽度提示？
2. 换父时，child 的布局约束应自动迁移吗？
3. 一个布局器遗漏了某个 child，Runtime 应如何解释？
4. 哪些样式变化只影响绘制，哪些会继续传播到测量？
5. 如何区分“暂时还有工作项”和“算法永不收敛”？
