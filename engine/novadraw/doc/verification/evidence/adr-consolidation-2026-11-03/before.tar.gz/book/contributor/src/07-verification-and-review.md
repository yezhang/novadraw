# 7. 验证、性能与代码评审

> **本章解决的问题**：如何选择足够而不过度的验证，并在提交前审查语义、架构和性能
> 风险。

## 7.1 从不变量选择证据

测试应证明跨模块承诺，而不是复述函数实现。例如“移动节点后连接与命中同步更新”
同时覆盖：

- 模型或 Runtime mutation；
- 几何和坐标；
- 派生状态收敛；
- 路由失效；
- damage；
- 命中结果。

先写出本次变化可能破坏的不变量，再选择最小测试层。

## 7.2 验证层级

| 层级 | 证明内容 |
|---|---|
| 单元测试 | 几何、值对象和纯算法 |
| 契约测试 | 公开或内部协议的跨类型语义 |
| Headless replay | 多事件、多帧和时间驱动行为 |
| 平台验收 | 窗口、浏览器、输入法、GPU 和视觉结果 |
| 性能基准 | 工作量、耗时、内存和提交规模 |

不要用平台截图代替可自动验证的协议，也不要用单元测试声称证明真实 GPU 或输入法行为。

## 7.3 分层命令

修改内环先运行：

```bash
cargo check -p <crate> --lib
cargo test -p <crate> --test <target>
```

功能切片完成后，从清单选择 suite：

```bash
cargo xtask list
cargo xtask verify <suite-id>
```

同类整改批次运行：

```bash
cargo fmt --all -- --check
cargo check --workspace
```

最终提交、推送、合并或里程碑关闭前运行一次：

```bash
cargo fmt --all -- --check
cargo clippy --workspace -- -D warnings
cargo test --workspace
```

suite 已包含的命令不应紧接着重复手工执行。

## 7.4 负向与故障注入

共享协议变化不能只测成功路径。根据影响面补充：

- stale、foreign 和 unknown identity；
- duplicate registration；
- prepare rejection；
- 扩展回调返回错误或 panic；
- 提交失败与补偿失败；
- platform/backend retry 和 fatal failure；
- 会话取消、对象退休和迟到事件；
- 部分发布前后的结构快照一致性。

## 7.5 性能修改

性能优化必须先给出固定场景、输入规模和统计方法。报告至少包含：

- 优化前后相同 workload；
- CPU 时间或工作量计数；
- 内存和分配变化；
- 最坏深度或节点规模；
- 语义等价测试。

不能为了假设中的性能收益绕过 Runtime、复制状态或提前引入增量缓存。

## 7.6 提交前评审

按以下顺序检查差异：

1. 行为是否符合当前规范与语义账本；
2. 状态所有权是否仍然唯一；
3. 失败是否会留下半发布状态；
4. 公共 API 是否无意扩张；
5. 扩展点是否需要修改中心枚举或私有 match；
6. 第三方类型是否越过 crate 边界；
7. 热路径是否增加日志、分配或无证据复杂度；
8. 测试是否覆盖最重要的负向路径；
9. 文档、suite 和代码是否引用同一合同。

跨工具 suite 和直接 Cargo 门禁见
[`tests/README.md`](../../../tests/README.md)。单测试 target 不建立
xtask 别名。
