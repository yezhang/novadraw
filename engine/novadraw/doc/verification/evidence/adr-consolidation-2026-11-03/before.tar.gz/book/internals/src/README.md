# 深入理解 Novadraw

本书从第一性原理解释一个二维图形编辑框架如何维持一致性、可扩展性和可恢复性。
它不以 API 查询或仓库贡献流程为主，而是回答：

1. 图形、布局、输入、连接和编辑为何必须以同一份已提交场景状态为准？
2. 一次状态变化如何沿固定因果链收敛为稳定帧？
3. 如何在不开放主流程控制权的前提下提供可组合扩展能力？

## 适合谁

- 希望系统理解图形框架核心机制的工程师；
- 需要设计 Figure、布局、事件、连接或编辑器架构的人；
- 在阅读源码前，希望先建立完整心智模型的 Novadraw 贡献者；
- 需要评估类似框架设计取舍的技术负责人。

如果目标是直接开发应用，请阅读
<a href="../../user/html/index.html">《Novadraw 应用开发与扩展指南》</a>。
如果目标是修改当前仓库，请阅读
<a href="../../contributor/html/index.html">《Novadraw 贡献者指南》</a>。

## 写作边界

本书强调长期稳定的概念：

- 权威状态、派生状态与临时状态；
- 身份、所有权与生命周期；
- 坐标、布局、绘制和命中的一致性；
- 固定执行管线与开放扩展点；
- 模型到视图的派生、编辑意图和撤销语义；
- 原子提交、故障隔离和确定性验证。

本书不承担：

- 罗列所有公开 API；
- 提供产品应用配方；
- 记录当前 roadmap 或审计状态；
- 指导读者修改具体文件；
- 复制 ADR、测试命令和仓库维护流程。

类型名可以用于精确表达概念，但章节不能依赖具体源码路径或行号才能成立。

## 阅读方式

前三章建立全局模型。第四至第十一章解释图形核心，第十二、十三章解释编辑框架，第十四章
讨论开放能力模型，第十五章把正确性、失败、线程边界和演进原则统一起来。

章节按因果顺序展开：

```text
源状态
-> 结构与身份
-> 几何和布局
-> 派生状态收敛
-> 绘制、表现与输入
-> 编辑意图
-> 原子提交
-> 可观察结果
```

## 阅读合同

本书不要求读者记住一组彼此孤立的类型。每章都应帮助读者回答同一组问题：

1. 本章要解决的真实矛盾是什么？
2. 哪项状态是权威事实，谁拥有写入权？
3. 输入、候选计算、校验、提交和发布按什么顺序发生？
4. 使用了哪些身份域、坐标域和版本域？
5. 成功后可以观察到什么结果？
6. 拒绝、取消和故障分别保持哪些事实不变？
7. 新扩展能够替换什么，又不能绕过什么？

阅读算法章节时，先找输入和稳定输出，再看中间步骤。阅读对象章节时，先找所有者和
生命周期，再看方法。阅读失败章节时，先判断权威状态是否已经改变，再判断能否重试。

## 全书术语约定

本书在概念首次出现时使用“中文名称（英文原名或代码名）”，后续普通叙述优先使用中文
名称。代码标识符保持源码拼写。

| 首选名称 | 英文或代码名 | 本书中的含义 |
|---|---|---|
| 图形对象、图形行为 | Figure | 场景节点或节点上的具体行为协议，按上下文区分 |
| 场景运行时 | Runtime | 场景事务、派生收敛、帧提交准备和完成确认的权威 |
| 场景源状态 | scene source state | Runtime 直接拥有、由场景事务写入的状态 |
| 已提交场景状态 | committed scene state | Runtime 已经接受并原子写入的场景状态前缀 |
| 稳定场景状态 | stable scene state | stable epoch 中必需派生工作已经闭合的一致读边界 |
| 场景数据项 | scene data item | SceneQuery 读取并用于依赖追踪的具体值 |
| 查看器 | Viewer | 模型、编辑部件和派生视图的当前所有者 |
| 视图派生 | model-to-view derivation | Viewer 根据单一模型 revision 构建或同步 Part/Figure 视图 |
| 视图同步 | view synchronization | 已有 Viewer 消费模型变化并更新稳定视图 |
| 模型适配器 | ModelAdapter | 为 Viewer 提供根身份、revision、children、connections 和事件流的只读模型边界 |
| 模型 revision | ModelRevision | 非零、单调递增的业务变化前缀标识 |
| 模型事件 | ModelEvent | 绑定 revision、subject 与 payload 的一次模型通知 |
| 坐标变换 | coordinate transform | 把几何从一个明确坐标域映射到另一个坐标域 |
| 表面包围盒 | surface bounds | 几何变换到逻辑表面域后的保守轴对齐包围盒 |
| 编辑部件 | EditPart、Part | Viewer 内连接模型身份、编辑行为与稳定视觉的视图控制器 |
| 连接部件 | ConnectionPartId | 包装同一 EditPartId 的连接视图角色，不建立新的身份域 |
| 连接 | Connection | 按上下文指业务关系、ConnectionPartId 或 Core 中的连接 Figure |
| 视觉所有者 | VisualOwner | Viewer 记录 Part、Handle 或 Feedback 对 Figure 子树的所有权与清理关系 |
| 覆盖视觉 | Overlay | Viewer 管理、位于稳定 Part 视觉之上的临时 Figure 子树 |
| 控制柄 | Handle | 具有 HandleId 和类型化动作的可交互 Overlay |
| 反馈图形 | Feedback | 表达当前候选结果、完成或取消后清理的 Overlay |
| 边界矩形 | bounds | 节点在父内容域中的布局位置和尺寸 |
| 客户区 | client area | 父节点提供给子内容的可用区域 |
| 重绘区域 | damage | 表面上可能需要修复的保守像素范围 |
| 校验收敛 | validation | 使布局和其他派生状态达到稳定版本的过程 |
| 表现状态层 | Presentation Plane | Runtime 在稳定场景状态与帧录制之间维护的可丢弃状态边界 |
| 表现覆盖快照 | PresentationSnapshot | 当前帧可选的稀疏覆盖集合；无活动覆盖时不生成 |
| 图形准备结果 | FigurePresentation | 受检测量、视觉边界和不可变绘制数据，不专属于动画 |
| 动画临时绘制项 | TemporaryVisual | Runtime 管理、树外、默认不可交互的绘制项 |
| 帧提交准备 | frame submission preparation | Runtime 从稳定场景状态生成正式渲染提交包的过程 |
| 渲染提交包 | RenderSubmission | Runtime 生成并交给 Host 的一帧拥有数据 |
| 提交包已就绪 | FramePreparation::Ready | Runtime 已建立 in-flight，Host 尚未调用后端 |
| 帧已呈现 | RenderDisposition::Presented | 后端确认目标表面已经呈现该帧 |
| 完成已确认 | SubmissionAcknowledgement | Runtime 已根据后端结果确认资源与恢复状态 |
| 指针捕获 | pointer capture | 把后续指针事件锁定到同一交互会话 |
| 文本布局 | TextLayout | 测量阶段生成、由布局绘制和文本交互共同消费的不可变排版结果 |
| 选择模型 | SelectionModel | Viewer 使用的有序 EditPartId 集合及独立编辑部件焦点，末项为 primary selection |
| 缩放管理器 | ZoomManager | 组合共享缩放句柄、viewport 句柄、离散级别和滚动策略的 Core 对象 |
| 故障锁定状态 | faulted | 无法继续证明一致性，只允许诊断或重建 |

相似词不一定表示同一事实：

- `dirty` 表示引擎内部仍有工作；重绘区域表示表面像素可能失效；
- 模型 revision、稳定 epoch、backend session 和 frame ID 属于不同版本域；
- 已提交场景状态、表现状态和后端状态具有不同所有者；
- 拒绝表示权威状态未变，取消表示会话终止，故障表示一致性已经无法证明。

## 完成标准

读完后，读者应能够：

- 从状态所有权解释一个图形框架，而不是从类名记忆结构；
- 推导绘制、命中、重绘区域和连接为何必须共享坐标事实；
- 解释布局收敛与帧提交为何是不同阶段；
- 解释已提交场景状态、表现状态和后端状态为何不能相互替代；
- 解释模型、EditPart 和 Figure 三个身份域；
- 解释文字、图像、Selection、缩放与连接路由如何进入统一派生和失效协议；
- 说明 Runtime 单一 owner 与平台、异步资源和后端线程边界；
- 判断某项变化属于基础协议、横切能力、共享模型还是具体组件；
- 为新机制定义不变量、失败边界和可验证结果。
